close all; clear all;
r = 150;
sd_range = 0.05; % max spatial frequency in PSD
%rmesh = -2*lmesh:2*lmesh;
[ycoor,xcoor] = meshgrid(-r:r,-r:r);
f = load('./ac_struct.mat');

figpath = './figures/Jacob_Sargolini_across_cells/';
if ~exist(figpath)
    mkdir(figpath);
end
addpath(figpath);

% animal 6
a = 6; idx = [61,62,64]; eid = [1,2,4,5];
figure(1); set(gcf,'Position',[0 0 1100 600]);
figure(2); set(gcf,'Position',[0 0 1100 600]);
figure(3); set(gcf,'Position',[0 0 1100 600]);
figure(4); set(gcf,'Position',[0 0 1100 600]);
figure(10); set(gcf,'Position',[0 0 1100 600]);
figure(20); set(gcf,'Position',[0 0 1100 600]);
% acE0 = zeros(2*r+1,2*r+1); acE30 = zeros(2*r+1,2*r+1); acE60 = zeros(2*r+1,2*r+1); 
% acE90 = zeros(2*r+1,2*r+1); acE120 = zeros(2*r+1,2*r+1); acE150 = zeros(2*r+1,2*r+1);
for e = 1:4 % environment
    a0 = zeros(2*r+1,2*r+1); a30 = zeros(2*r+1,2*r+1); a60 = zeros(2*r+1,2*r+1); 
    a90 = zeros(2*r+1,2*r+1); a120 = zeros(2*r+1,2*r+1); a150 = zeros(2*r+1,2*r+1);
    for i = 1:3    % cell ID
        for k = 0:5 % rotation out of 6
            eval(['ac = f.ac.A',num2str(a),'.E',num2str(eid(e)),'(idx(i)).R',num2str(k*30),';']);
            s = size(ac,1); 
            if s < 2*r+1
                temp = zeros(2*r+1,2*r+1);
                temp((2*r+1-s)/2+1:2*r+1-(2*r+1-s)/2,(2*r+1-s)/2+1:2*r+1-(2*r+1-s)/2) = ac;
                ac = temp;
            else
                ac = ac((s+1)/2-r:(s+1)/2+r,(s+1)/2-r:(s+1)/2+r);   % reshape ac
            end
            eval(['a',num2str(k*30),' = a',num2str(k*30),' + ac;']);
            eval(['t',num2str(k*30),'= ac;']);
        end
        [rad,frad,~,deriv] = max_activity_ring(t0);
        [score,~] = gridness(t0,t30,t60,t90,t120,t150,rad,frad);
        figure(e); subplot(4,5,i); hold on;
        imagesc_env(t0,-r:r,-r:r); axis image; colormap(jet(256)); colorbar; 
        t0(xcoor.^2+ycoor.^2<frad^2) = 0; t0(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0; % extract the ring
        caxis([0 max(max(t0))]); 
        if deriv == 1
            title(['1st: \color{blue}',num2str(frad),'; \color{red}',num2str(rad),'\color{black}; g:',num2str(score,2)]);
        elseif deriv == 2
            title(['2nd: \color{blue}',num2str(frad),'; \color{red}',num2str(rad),'\color{black}; g:',num2str(score,2)]);
        else
            title(['Assigned: \color{blue}',num2str(frad),'; \color{red}',num2str(rad),'\color{black}; g:',num2str(score,2)]);
        end
        plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
        plot(frad*cos(0:0.01:2*pi+0.01),frad*sin(0:0.01:2*pi+0.01),'w');
        plot((2*rad-frad)*cos(0:0.01:2*pi+0.01),(2*rad-frad)*sin(0:0.01:2*pi+0.01),'w');
    end
    sgtitle(['Animal ',num2str(a),'; Environment ',num2str(eid(e))]);
    %for k = 0:5 % rotation out of 6
    %    eval(['ac',num2str(k*30),' = ac',num2str(k*30),' + a',num2str(k*30),';']);
    %end
    if e >= 2
        [rad,frad,a0r,deriv] = max_activity_ring2(a0);
    else
        [rad,frad,a0r,deriv] = max_activity_ring(a0);
    end    
    [score,cor] = gridness(a0,a30,a60,a90,a120,a150,rad,frad);
    % combine E2 & E3
%     if e == 2 || e == 3
%         for k = 0:5 % rotation out of 6
%             eval(['acE',num2str(k*30),' = acE',num2str(k*30),' + a',num2str(k*30),';']);
%         end
%     end
    a0psd = ac2psd(a0); a30psd = ac2psd(a30); a60psd = ac2psd(a60); a90psd = ac2psd(a90); a120psd = ac2psd(a120); a150psd = ac2psd(a150); 
    figure(10); subplot(4,4,4*(e-1)+1); hold on; 
    plot([0,r],[0,0],'k:'); plot(a0r,'k');
    plot(rad*ones(1,2),[0,a0r(rad)],'r'); plot(frad*ones(1,2),[0,a0r(frad)],'b');
    xlabel('radius'); ylabel('mean autocorr'); xlim([0 r]); 
    if deriv == 1
        title(['1st: \color{blue}',num2str(frad),'; \color{red}',num2str(rad)]);
    else
        title(['Assigned: \color{blue}',num2str(frad),'; \color{red}',num2str(rad)]);
    end
    subplot(4,4,4*(e-1)+2); hold on;
    imagesc_env(a0,-r:r,-r:r); axis image; colormap(jet(256)); colorbar; 
    a0(xcoor.^2+ycoor.^2<frad^2) = 0; a0(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0; % extract the ring
    caxis([0 max(max(a0))]); title(['autocorr in E',num2str(eid(e))]);
    plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
    plot(frad*cos(0:0.01:2*pi+0.01),frad*sin(0:0.01:2*pi+0.01),'w');
    plot((2*rad-frad)*cos(0:0.01:2*pi+0.01),(2*rad-frad)*sin(0:0.01:2*pi+0.01),'w');
    subplot(4,4,4*(e-1)+3); hold on;    
    imagesc_env(a0,-r:r,-r:r); axis image; colormap(jet(256)); colorbar; 
    caxis([0 max(max(a0))]); title(['autocorr in E',num2str(eid(e))]);
    plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
    plot(frad*cos(0:0.01:2*pi+0.01),frad*sin(0:0.01:2*pi+0.01),'w');
    plot((2*rad-frad)*cos(0:0.01:2*pi+0.01),(2*rad-frad)*sin(0:0.01:2*pi+0.01),'w');
    subplot(4,4,4*e); hold on;
    plot(0:30:150,cor,'ko-'); title(['gridness = ',num2str(score)]);
    % psd
    [rad,frad,a0r] = max_activity_ring_psd(a0psd);
    [score,cor] = gridness(a0psd,a30psd,a60psd,a90psd,a120psd,a150psd,rad,frad);
    figure(20); subplot(4,4,4*(e-1)+1); hold on;
    plot([0,r],[0,0],'k:'); plot(a0r,'k');
    plot(rad*ones(1,2),[0,a0r(rad)],'r'); plot(frad*ones(1,2),[0,a0r(frad)],'b');
    xlabel('radius'); ylabel('mean PSD'); xlim([0 r]); 
    if deriv == 1
        title(['1st: \color{blue}',num2str(frad),'; \color{red}',num2str(rad)]);
    else
        title(['Assigned: \color{blue}',num2str(frad),'; \color{red}',num2str(rad)]);
    end
    subplot(4,4,4*(e-1)+2); hold on;
    imagesc_env(a0psd,(-r:r)/(2*r),(-r:r)/(2*r));
    axis image; colormap(jet(256)); xlim([-sd_range,sd_range]); ylim([-sd_range,sd_range]);    
    a0psd(xcoor.^2+ycoor.^2<frad^2) = 0; a0psd(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0; % extract the ring
    caxis([0 max(max(a0psd))]); title(['PSD in E',num2str(eid(e))]);
    plot(rad*cos(0:0.01:2*pi+0.01)/(2*r),rad*sin(0:0.01:2*pi+0.01)/(2*r),'w');
    plot(frad*cos(0:0.01:2*pi+0.01)/(2*r),frad*sin(0:0.01:2*pi+0.01)/(2*r),'w');
    plot((2*rad-frad)*cos(0:0.01:2*pi+0.01)/(2*r),(2*rad-frad)*sin(0:0.01:2*pi+0.01)/(2*r),'w');
    subplot(4,4,4*(e-1)+3); hold on;    
    imagesc_env(a0psd,(-r:r)/(2*r),(-r:r)/(2*r)); 
    axis image; colormap(jet(256)); colorbar; xlim([-sd_range,sd_range]); ylim([-sd_range,sd_range]);
    caxis([0 max(max(a0psd))]); title(['PSD in E',num2str(eid(e))]);
    plot(rad*cos(0:0.01:2*pi+0.01)/(2*r),rad*sin(0:0.01:2*pi+0.01)/(2*r),'w');
    plot(frad*cos(0:0.01:2*pi+0.01)/(2*r),frad*sin(0:0.01:2*pi+0.01)/(2*r),'w');
    plot((2*rad-frad)*cos(0:0.01:2*pi+0.01)/(2*r),(2*rad-frad)*sin(0:0.01:2*pi+0.01)/(2*r),'w');
    subplot(4,4,4*e); hold on;
    plot(0:30:150,cor,'ko-'); title(['gridness = ',num2str(score)]);
end

% [rad,frad,ac0r,deriv] = max_activity_ring2(acE0);
% [score,cor] = gridness(acE0,acE30,acE60,acE90,acE120,acE150,rad,frad);
% figure(4); subplot(4,4,13); hold on; 
% plot([0,r],[0,0],'k:'); plot(ac0r,'k');
% plot(rad*ones(1,2),[0,ac0r(rad)],'r'); plot(frad*ones(1,2),[0,ac0r(frad)],'b');
% xlabel('radius'); ylabel('mean autocorr'); xlim([0 r]); 
% if deriv == 1
%     title(['1st: \color{blue}',num2str(frad),'; \color{red}',num2str(rad)]);
% elseif deriv == 2
%     title(['2nd: \color{blue}',num2str(frad),'; \color{red}',num2str(rad)]);
% else
%     title(['Assigned: \color{blue}',num2str(frad),'; \color{red}',num2str(rad)]);
% end
% subplot(4,4,14); hold on;
% imagesc_env(acE0,-r:r,-r:r); axis image; colormap(jet(256)); colorbar; 
% acE0(xcoor.^2+ycoor.^2<frad^2) = 0; acE0(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0;
% caxis([0 max(max(acE0))]); title(['autocorr in all Es']);
% plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
% plot(frad*cos(0:0.01:2*pi+0.01),frad*sin(0:0.01:2*pi+0.01),'w');
% plot((2*rad-frad)*cos(0:0.01:2*pi+0.01),(2*rad-frad)*sin(0:0.01:2*pi+0.01),'w');
% subplot(4,4,15); hold on;
% imagesc_env(acE0,-r:r,-r:r); axis image; colormap(jet(256)); colorbar; 
% caxis([0 max(max(acE0))]); title(['autocorr in all Es']);
% plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
% plot(frad*cos(0:0.01:2*pi+0.01),frad*sin(0:0.01:2*pi+0.01),'w');
% plot((2*rad-frad)*cos(0:0.01:2*pi+0.01),(2*rad-frad)*sin(0:0.01:2*pi+0.01),'w');
% subplot(4,4,16); hold on;
% plot(0:30:150,cor,'ko-'); title(['gridness = ',num2str(score)]);
saveas(1,[figpath,'gridness_a',num2str(a),'e1.png']);
saveas(2,[figpath,'gridness_a',num2str(a),'e2.png']);
saveas(3,[figpath,'gridness_a',num2str(a),'e4.png']);
saveas(4,[figpath,'gridness_a',num2str(a),'e5.png']);
saveas(10,[figpath,'gridness_a',num2str(a),'all.png']);
saveas(20,[figpath,'psdgridness_a',num2str(a),'all.png']);
