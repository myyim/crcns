function [rmap,ac,ac60,ac120,ac30,ac90,ac150,ac0r,rad,fsize,cor,score] = gridscore_shuffled(y,x,lam,psi,seed)
if nargin < 5
    seed = 5;
end
g2d = gridcell(y,x,1,lam,psi,[0,0]);  % from left to right in a matrix is in the direction of increasing the second coordinate, thus (y,x)
dmax = floor(max(size(g2d,1))/2);
xm = floor(size(g2d,1)/2); % the mask matrix is rectangular
ym = floor(size(g2d,2)/2);

% shuffle
thre = 0.2;
g2d_small = g2d(g2d<=thre);
g2d(g2d<=thre) = 0;
rng(seed);
[mp,n] = bwlabel(g2d);  % find the islands and the number
mp(mp~=mode(mp(mp~=0),'all')) = 0; % pick the largest island and we want an intact one  
kern = g2d.*(mp~=0);    % a bump
kern(~any(kern,2),:) = [];  % remove rows with all zeros
kern(:,~any(kern,1)) = [];  % remove columns with all zeros
rkern = size(kern,1);
[ycoor,xcoor] = meshgrid(-ym:ym,-xm:xm);
mask = zeros(size(g2d));
fpts = zeros(n,2);
for j = 1:n   
    fmask = zeros(size(g2d));
    count = 0;    
    while count==0 || sum(sum(fmask.*mask))>0 % ensure all data points in the allowed region
        fpts(j,:) = [-xm+2*xm*rand(1) -ym+2*ym*rand(1)];
        fmask = zeros(size(g2d));
        fmask((xcoor-fpts(j,1)).^2+(ycoor-fpts(j,2)).^2<(rkern/2)^2) = 1;
        count = count + 1;
    end
    mask(fmask==1) = 1; % restrict overlapping clusters  
end
fc = hist3(fpts,'Edges',{-xm:xm,-ym:ym});
rmap = conv2(fc,kern,'same'); % convolve the field centers with the field kernel
rmap(x.^2+y.^2<60^2) = 0; rmap(x.^2+y.^2>75^2) = 0;
ac = xcorr2(rmap);

% Locate the ring in ac0 with max activity
[ycoor,xcoor] = meshgrid(-2*ym:2*ym,-2*xm:2*xm); % coordinates of the autocorrelation grid, y by x
topright = sqrt((xcoor+0.5).^2+(ycoor+0.5).^2);
topleft = sqrt((xcoor-0.5).^2+(ycoor+0.5).^2);
bottomleft = sqrt((xcoor-0.5).^2+(ycoor-0.5).^2);
bottomright = sqrt((xcoor+0.5).^2+(ycoor-0.5).^2);
rtensor(:,:,1) = topright; rtensor(:,:,2) = topleft; rtensor(:,:,3) = bottomleft; rtensor(:,:,4) = bottomright;
rmin = min(rtensor,[],3); rmax = max(rtensor,[],3);
ac0r = zeros(1,dmax);  % average autocorrelation along a circle (index = radius) 
for rad = 1:dmax
    ringon = (rad>=rmin).*(rad<=rmax); % define the bins on the circle
    ac0r(rad) = sum(ac(ringon==1))/sum(sum(ringon==1));
end
dac0r = ac0r(2:end)-ac0r(1:end-1); % difference

% The radius with max average autocorrelation or with min decrease in
% autocorrelation in case of no max
sgn = [0 dac0r(1:end-2)>=0].*(dac0r(1:end-1)>=0).*(dac0r(2:end)<0).*[dac0r(3:end)<0 0];
if sum(sgn) == 0   
    ddac0r = dac0r(2:end)-dac0r(1:end-1); % difference of difference
    sgn = [0 ddac0r(1:end-2)>=0].*(ddac0r(1:end-1)>=0).*(ddac0r(2:end)<0).*[ddac0r(3:end)<0 0];
    if sum(sgn) == 0
        score = nan; rad = nan; fsize = nan; d1 = nan;
        return
    else
        rad = find(sgn==1); rad = rad(1)+2;   % radius of the circle (second order difference)
        fsize = ceil(rad/2);
  
    end
else
    rad = find(sgn==1); rad = rad(1)+1;   % radius of the circle (first order difference)
    sgn = [0 dac0r(1:end-2)<=0].*(dac0r(1:end-1)<=0).*(dac0r(2:end)>0).*[dac0r(3:end)>0 0];
    fsize = find(sgn==1); fsize = fsize(1);   % radius of the circle (first order difference)
end
ac0 = ac; ac0(xcoor.^2+ycoor.^2<fsize^2) = 0; ac0(xcoor.^2+ycoor.^2>(2*rad-fsize)^2) = 0;

fpt = fpts*rotation_matrix(-pi/3);
fc = hist3(fpt,'Edges',{-xm:xm,-ym:ym});
rmap = conv2(fc,kern,'same'); % convolve the field centers with the field kernel
rmap(x.^2+y.^2<60^2) = 0; rmap(x.^2+y.^2>75^2) = 0;
ac60 = xcorr2(rmap); ac60(xcoor.^2+ycoor.^2<fsize^2) = 0; ac60(xcoor.^2+ycoor.^2>(2*rad-fsize)^2) = 0;

fpt = fpts*rotation_matrix(-2*pi/3); 
fc = hist3(fpt,'Edges',{-xm:xm,-ym:ym});
rmap = conv2(fc,kern,'same'); % convolve the field centers with the field kernel
rmap(x.^2+y.^2<60^2) = 0; rmap(x.^2+y.^2>75^2) = 0;
ac120 = xcorr2(rmap); ac120(xcoor.^2+ycoor.^2<fsize^2) = 0; ac120(xcoor.^2+ycoor.^2>(2*rad-fsize)^2) = 0;

fpt = fpts*rotation_matrix(-pi/6); 
fc = hist3(fpt,'Edges',{-xm:xm,-ym:ym});
rmap = conv2(fc,kern,'same'); % convolve the field centers with the field kernel
rmap(x.^2+y.^2<60^2) = 0; rmap(x.^2+y.^2>75^2) = 0;
ac30 = xcorr2(rmap); ac30(xcoor.^2+ycoor.^2<fsize^2) = 0; ac30(xcoor.^2+ycoor.^2>(2*rad-fsize)^2) = 0;

fpt = fpts*rotation_matrix(-pi/2); 
fc = hist3(fpt,'Edges',{-xm:xm,-ym:ym});
rmap = conv2(fc,kern,'same'); % convolve the field centers with the field kernel
rmap(x.^2+y.^2<60^2) = 0; rmap(x.^2+y.^2>75^2) = 0;
ac90 = xcorr2(rmap); ac90(xcoor.^2+ycoor.^2<fsize^2) = 0; ac90(xcoor.^2+ycoor.^2>(2*rad-fsize)^2) = 0;

fpt = fpts*rotation_matrix(-5*pi/6); 
fc = hist3(fpt,'Edges',{-xm:xm,-ym:ym});
rmap = conv2(fc,kern,'same'); % convolve the field centers with the field kernel
rmap(x.^2+y.^2<60^2) = 0; rmap(x.^2+y.^2>75^2) = 0;
ac150 = xcorr2(rmap); ac150(xcoor.^2+ycoor.^2<fsize^2) = 0; ac150(xcoor.^2+ycoor.^2>(2*rad-fsize)^2) = 0;

cor = ones(1,6);
ac0_vec = ac0(logical((xcoor.^2+ycoor.^2>=fsize^2).*(xcoor.^2+ycoor.^2<=(2*rad-fsize)^2)));
for j = 2:6
    ac_vec = eval(['ac',num2str(30*(j-1))]);
    ac_vec = ac_vec(logical((xcoor.^2+ycoor.^2>=fsize^2).*(xcoor.^2+ycoor.^2<=(2*rad-fsize)^2)));
    xcor = corrcoef(ac0_vec,ac_vec);
    cor(j) = xcor(1,2);
end
score = min(cor(3:2:5))-max(cor(2:2:6));

end