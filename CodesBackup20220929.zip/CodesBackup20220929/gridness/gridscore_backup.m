function [score,rad,fsize,dl] = gridscore(trackpos,trackf,sig,mask)
if nargin < 3
    sig = 3;
end
dmax = ceil(max(sqrt(trackpos(:,1).^2+trackpos(:,2).^2)));
if nargin < 4
    mask = ones(2*dmax+1,2*dmax+1); % minimum environment containing all data
end
xm = floor(size(mask,1)/2); % the mask matrix is rectangular
ym = floor(size(mask,2)/2);
[rmap,spk,~] = smoothratemap(trackpos,trackf,sig,mask);
ac = xcorr2(rmap);

% Locate the ring in ac0 with max activity
[ycoor,xcoor] = meshgrid(-2*ym:2*ym,-2*xm:2*xm); % coordinates of the grid, y by x
topright = sqrt((xcoor+0.5).^2+(ycoor+0.5).^2);
topleft = sqrt((xcoor-0.5).^2+(ycoor+0.5).^2);
bottomleft = sqrt((xcoor-0.5).^2+(ycoor-0.5).^2);
bottomright = sqrt((xcoor+0.5).^2+(ycoor-0.5).^2);
rtensor(:,:,1) = topright; rtensor(:,:,2) = topleft; rtensor(:,:,3) = bottomleft; rtensor(:,:,4) = bottomright;
rmin = min(rtensor,[],3); rmax = max(rtensor,[],3);
ac0r = zeros(1,dmax);  % average autocorrelation along a circle (index = radius) 
for rad = 1:dmax
    ringon = (rad>=rmin).*(rad<=rmax); % define the bins on the circle
    ac0r(rad) = sum(ac(ringon==1))/sum(sum(ringon==1));
end
dac0r = ac0r(2:end)-ac0r(1:end-1); % difference

% The radius with max average autocorrelation or with min decrease in
% autocorrelation in case of no max
sgn = [0 dac0r(1:end-2)>=0].*(dac0r(1:end-1)>=0).*(dac0r(2:end)<0).*[dac0r(3:end)<0 0];
% two points with positive slope followed by another two with negative
% slope - this give a local maximum
%sgn = (dac0r(1:end-1)>=0).*(dac0r(2:end)<0); % one point instead of two,
%less strict; more 
if sum(sgn) == 0   
    ddac0r = dac0r(2:end)-dac0r(1:end-1); % difference of difference
    sgn = [0 ddac0r(1:end-2)>=0].*(ddac0r(1:end-1)>=0).*(ddac0r(2:end)<0).*[ddac0r(3:end)<0 0];
    %sgn = (ddac0r(1:end-1)>=0).*(ddac0r(2:end)<0);
    if sum(sgn) == 0
        %score = nan; rad = nan; fsize = nan; d1 = nan;
        %return
        rad = 40;
        fsize = 30;
        d1 = 0;
    else
        rad = find(sgn==1); rad = rad(1)+2;   % radius of the circle (second order difference)
        fsize = rad-10; %ceil(rad/2);         % field size
        d1 = 2;
    end
else
    rad = find(sgn==1); rad = rad(1)+1;   % radius of the circle (first order difference)
    sgn = [0 dac0r(1:end-2)<=0].*(dac0r(1:end-1)<=0).*(dac0r(2:end)>0).*[dac0r(3:end)>0 0];
    if sum(sgn) == 0
        fsize = rad-10; % when there is no local minimum
    else
        fsize = find(sgn==1); fsize = fsize(1);   % local minimum
        if rad-fsize < 10
            fsize = rad-10;
        end
    end
    d1 = 1;
end
if rad < 25
    rad = 40;
    fsize = 30;
    d1 = 0;
end
ac0 = ac; ac0(xcoor.^2+ycoor.^2<fsize^2) = 0; ac0(xcoor.^2+ycoor.^2>(2*rad-fsize)^2) = 0;
[rmap,~,~] = smoothratemap(trackpos,trackf,sig,mask,pi/3);
ac60 = xcorr2(rmap); ac60(xcoor.^2+ycoor.^2<fsize^2) = 0; ac60(xcoor.^2+ycoor.^2>(2*rad-fsize)^2) = 0;
[rmap,~,~] = smoothratemap(trackpos,trackf,sig,mask,2*pi/3);
ac120 = xcorr2(rmap); ac120(xcoor.^2+ycoor.^2<fsize^2) = 0; ac120(xcoor.^2+ycoor.^2>(2*rad-fsize)^2) = 0;
[rmap,~,~] = smoothratemap(trackpos,trackf,sig,mask,pi/6);
ac30 = xcorr2(rmap); ac30(xcoor.^2+ycoor.^2<fsize^2) = 0; ac30(xcoor.^2+ycoor.^2>(2*rad-fsize)^2) = 0;
[rmap,~,~] = smoothratemap(trackpos,trackf,sig,mask,pi/2);
ac90 = xcorr2(rmap); ac90(xcoor.^2+ycoor.^2<fsize^2) = 0; ac90(xcoor.^2+ycoor.^2>(2*rad-fsize)^2) = 0;
[rmap,~,~] = smoothratemap(trackpos,trackf,sig,mask,5*pi/6);
ac150 = xcorr2(rmap); ac150(xcoor.^2+ycoor.^2<fsize^2) = 0; ac150(xcoor.^2+ycoor.^2>(2*rad-fsize)^2) = 0;

cor = ones(1,6);
ac0_vec = ac0(logical((xcoor.^2+ycoor.^2>=fsize^2).*(xcoor.^2+ycoor.^2<=(2*rad-fsize)^2)));
for j = 2:6
    ac_vec = eval(['ac',num2str(30*(j-1))]);
    ac_vec = ac_vec(logical((xcoor.^2+ycoor.^2>=fsize^2).*(xcoor.^2+ycoor.^2<=(2*rad-fsize)^2)));
    xcor = corrcoef(ac0_vec,ac_vec);
    cor(j) = xcor(1,2);
end
score = min(cor(3:2:5))-max(cor(2:2:6));

if 1    % 1 = plot; 0 = no plot
    figure; set(gcf,'Position',[0 0 1100 700]);
    subplot(341); hold on;
    axis image; title('spikes'); % the spikes convolved
    plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20); plot(trackf(:,1),trackf(:,2),'r.');
    subplot(342); hold on;
    imagesc_env(spk,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('convolved spikes'); % the spikes convolved
    subplot(343); hold on;
    %imagesc_env(dur,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('convolved time'); % the time convolved
    imagesc_env(rmap,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('ratemap');
    subplot(344); hold on; 
    plot([0,dmax],[0,0],'k:'); plot(ac0r,'k'); plot(1.5:dmax,dac0r,'Color',[0.8 0.8 0.8]); 
    plot(rad*ones(1,2),[0,ac0r(rad)],'r'); plot(fsize*ones(1,2),[0,ac0r(fsize)],'b');
    xlabel('radius'); ylabel('mean autocorr along a circle'); xlim([0 dmax]); 
    if d1 == 1
        title(['1st: \color{blue}',num2str(fsize),'; \color{red}',num2str(rad)]);
    elseif d1 == 2
        title(['2nd: \color{blue}',num2str(fsize),'; \color{red}',num2str(rad)]);
    else
        title(['Assigned: \color{blue}',num2str(fsize),'; \color{red}',num2str(rad)]);
    end
    subplot(345); hold on;
    imagesc_env(ac,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; caxis([0 max(ac(xcoor.^2+ycoor.^2>=fsize^2))]); title('autocorr at 0^{\circ}'); % the original AC
    plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
    plot(fsize*cos(0:0.01:2*pi+0.01),fsize*sin(0:0.01:2*pi+0.01),'w');
    plot((2*rad-fsize)*cos(0:0.01:2*pi+0.01),(2*rad-fsize)*sin(0:0.01:2*pi+0.01),'w');

    % rings
    subplot(346); hold on; imagesc_env(ac0,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 0^{\circ}'); % the original AC
    subplot(347); hold on; imagesc_env(ac60,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 60^{\circ}');
    subplot(348); hold on; imagesc_env(ac120,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 120^{\circ}'); 
    subplot(349); hold on; imagesc_env(ac30,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 30^{\circ}');
    subplot(3,4,10); hold on; imagesc_env(ac90,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 90^{\circ}'); 
    subplot(3,4,11); hold on; imagesc_env(ac150,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 150^{\circ}'); 
    subplot(3,4,12); plot(0:30:150,cor,'ko-'); title(['gridness = ',num2str(score)]);
end
end