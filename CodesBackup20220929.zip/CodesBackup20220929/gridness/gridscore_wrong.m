function score = gridscore(trackpos,trackf,sig,mask)
%
fsize = 20; % center field in autocorrelation to remove 
if nargin < 3
    sig = 3;
end
dmax = ceil(max(abs(trackpos(:))));
if nargin < 4
    mask = ones(2*dmax+21,2*dmax+1); % minimum environment containing all data
end
addpath('gridness');
xm = floor(size(mask,1)/2); % the mask matrix is rectangular
ym = floor(size(mask,2)/2);
[ycoor,xcoor] = meshgrid(-ym:ym,-xm:xm); % coordinates of the grid. Note g2d is y by x
% testing
spk = zeros(size(mask));
for j = 1:size(trackf,1)
    spk = spk + exp(-((xcoor-trackf(j,1)).^2+(ycoor-trackf(j,2)).^2)/(2*sig^2)).*((xcoor-trackf(j,1)).^2+(ycoor-trackf(j,2)).^2<=25);
end
dur = zeros(size(mask));
for j = 1:size(trackpos,1)
    dur = dur + exp(-((xcoor-trackpos(j,1)).^2+(ycoor-trackpos(j,2)).^2)/(2*sig^2)).*((xcoor-trackpos(j,1)).^2+(ycoor-trackpos(j,2)).^2<=25);
end
% end of testing
f = figure; set(gcf,'Position',[0 0 900 500]);
subplot(231); hold on;
imagesc_env(spk,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('spikes'); % the spikes convolved
plot(trackf(:,1),trackf(:,2),'kx');
subplot(232); hold on;
imagesc_env(spk,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('convolved spikes'); % the spikes convolved
subplot(233); hold on;
imagesc_env(dur,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('convolved time'); % the time convolved
subplot(234); hold on; 
rmap = smoothratemap(trackpos,trackf,sig,mask);
imagesc_env(rmap,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('ratemap');% the original AC
ac = xcorr2(rmap);
subplot(235); hold on;
imagesc_env(ac,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr'); % the original AC
% Search for peaks
[ycoor,xcoor] = meshgrid(-2*ym:2*ym,-2*xm:2*xm); % coordinates of the grid. Note g2d is y by x
ring = ac; ctr = ceil(size(ring)/2);    % a ring with the first peaks
ring(xcoor.^2+ycoor.^2<fsize^2) = 0; % remove the center
[~,idx] = max(ring(:));  % find the max, likely to be a peak in the ring closest to center
[ri,ci] = ind2sub(size(ring),idx); ri = ri-ctr(1); ci = ci-ctr(2);  % locate the peak
rad = sqrt(ri^2 + ci^2);  % radius 
ring(xcoor.^2+ycoor.^2<(0.7*rad)^2) = 0; % only the pixels on the ring can be non-zero
ring(xcoor.^2+ycoor.^2>(1.3*rad)^2) = 0;
peaks = zeros(6,2);
troughs = zeros(6,2);
ring((xcoor-ri).^2+(ycoor-ci).^2<fsize^2) = 0;
peaks(1,:) = [ri,ci];
for j = 2:6     % locate the 6 peaks
    [~,idx] = max(ring(:));
    [ri,ci] = ind2sub(size(ring),idx); ri = ri-ctr(1); ci = ci-ctr(2);  % locate the peak
    peaks(j,:) = [ri,ci];
    ring((xcoor-ri).^2+(ycoor-ci).^2<fsize^2) = 0;   
end
ring(xcoor.^2+ycoor.^2<(0.7*rad)^2) = max(ring(:)); % only the pixels on the ring can be non-zero
ring(xcoor.^2+ycoor.^2>(1.3*rad)^2) = max(ring(:));
for j = 1:6 % locate the in-between troughs
    [~,idx] = min(ring(:));
    [ri,ci] = ind2sub(size(ring),idx); ri = ri-ctr(1); ci = ci-ctr(2);  % locate the trough
    troughs(j,:) = [ri,ci];
    ring((xcoor-ri).^2+(ycoor-ci).^2<fsize^2) = 0;
end
%score = min(ac(peaks+ctr))-max(ax(troughs+ctr)); %
subplot(236); hold on; 
imagesc_env(ac,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; % the original AC
plot(peaks(:,1),peaks(:,2),'k+'); 
%plot(troughs(:,1),troughs(:,2),'wx'); title(['score:',num2str(score)]);
end
