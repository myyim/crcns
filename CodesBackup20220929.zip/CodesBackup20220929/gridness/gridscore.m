function [score,rad,frad,deriv] = gridscore(trackpos,trackf,sig,mask)
if nargin < 3
    sig = 3;
end
dmax = ceil(max(sqrt(trackpos(:,1).^2+trackpos(:,2).^2)));
if nargin < 4
    mask = ones(2*dmax+1,2*dmax+1); % minimum environment containing all data
end
xm = floor(size(mask,1)/2); ym = floor(size(mask,2)/2); % the mask matrix is rectangular
[ycoor,xcoor] = meshgrid(-2*ym:2*ym,-2*xm:2*xm); % coordinates of the grid, y by x
[rmap,spk,~] = smoothratemap(trackpos,trackf,sig,mask);
ac = xcorr2(rmap);
[rad,frad,ac0r,deriv] = max_activity_ring(ac);

[ac0,ac30,ac60,ac90,ac120,ac150] = data2ac(trackpos,trackf,sig,rad,frad,mask);

[score,cor] = gridness(ac0,ac30,ac60,ac90,ac120,ac150,rad,frad);

if 0    % 1 = plot; 0 = no plot
    figure; set(gcf,'Position',[0 0 1100 700]);
    subplot(341); hold on;
    axis image; title('spikes'); % the spikes convolved
    plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20); plot(trackf(:,1),trackf(:,2),'r.');
    subplot(342); hold on;
    imagesc_env(spk,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('convolved spikes'); % the spikes convolved
    subplot(343); hold on;
    %imagesc_env(dur,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('convolved time'); % the time convolved
    imagesc_env(rmap,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('ratemap');
    subplot(344); hold on; 
    plot([0,dmax],[0,0],'k:'); plot(ac0r,'k'); %plot(1.5:dmax,dac0r,'Color',[0.8 0.8 0.8]); 
    plot(rad*ones(1,2),[0,ac0r(rad)],'r'); plot(frad*ones(1,2),[0,ac0r(frad)],'b');
    xlabel('radius'); ylabel('mean autocorr along a circle'); xlim([0 dmax]); 
    if deriv == 1
        title(['1st: \color{blue}',num2str(frad),'; \color{red}',num2str(rad)]);
    elseif deriv == 2
        title(['2nd: \color{blue}',num2str(frad),'; \color{red}',num2str(rad)]);
    else
        title(['Assigned: \color{blue}',num2str(frad),'; \color{red}',num2str(rad)]);
    end
    subplot(345); hold on;
    imagesc_env(ac,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; caxis([0 max(ac(xcoor.^2+ycoor.^2>=frad^2))]); title('autocorr at 0^{\circ}'); % the original AC
    plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
    plot(frad*cos(0:0.01:2*pi+0.01),frad*sin(0:0.01:2*pi+0.01),'w');
    plot((2*rad-frad)*cos(0:0.01:2*pi+0.01),(2*rad-frad)*sin(0:0.01:2*pi+0.01),'w');

    % rings
    subplot(346); hold on; imagesc_env(ac0,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 0^{\circ}'); % the original AC
    subplot(347); hold on; imagesc_env(ac60,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 60^{\circ}');
    subplot(348); hold on; imagesc_env(ac120,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 120^{\circ}'); 
    subplot(349); hold on; imagesc_env(ac30,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 30^{\circ}');
    subplot(3,4,10); hold on; imagesc_env(ac90,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 90^{\circ}'); 
    subplot(3,4,11); hold on; imagesc_env(ac150,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 150^{\circ}'); 
    subplot(3,4,12); plot(0:30:150,cor,'ko-'); title(['gridness = ',num2str(score)]);
end
end