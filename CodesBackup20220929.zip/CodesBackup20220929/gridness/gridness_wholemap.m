function score = gridness_wholemap(trackpos,trackf,sig,mask)
% Same as gridscore except no extract but whole map is considered
fsize = 20; % center field in autocorrelation to remove 
if nargin < 3
    sig = 3;
end
dmax = ceil(max(sqrt(trackpos(:,1).^2+trackpos(:,2).^2)));
disp(dmax);
if nargin < 4
    mask = ones(2*dmax+21,2*dmax+21); % minimum environment containing all data
end
xm = floor(size(mask,1)/2); % the mask matrix is rectangular
ym = floor(size(mask,2)/2);
[ycoor,xcoor] = meshgrid(-ym:ym,-xm:xm); % coordinates of the grid. Note g2d is y by x
% testing
spk = zeros(size(mask));
for j = 1:size(trackf,1)
    spk = spk + exp(-((xcoor-trackf(j,1)).^2+(ycoor-trackf(j,2)).^2)/(2*sig^2)).*((xcoor-trackf(j,1)).^2+(ycoor-trackf(j,2)).^2<=25);
end
dur = zeros(size(mask));
for j = 1:size(trackpos,1)
    dur = dur + exp(-((xcoor-trackpos(j,1)).^2+(ycoor-trackpos(j,2)).^2)/(2*sig^2)).*((xcoor-trackpos(j,1)).^2+(ycoor-trackpos(j,2)).^2<=25);
end
% end of testing
f = figure; set(gcf,'Position',[0 0 1100 700]);
subplot(341); hold on;
imagesc_env(spk,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('spikes'); % the spikes convolved
plot(trackf(:,1),trackf(:,2),'kx');
subplot(342); hold on;
imagesc_env(spk,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('convolved spikes'); % the spikes convolved
subplot(343); hold on;
imagesc_env(dur,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('convolved time'); % the time convolved
subplot(344); hold on; 
rmap = smoothratemap(trackpos,trackf,sig,mask);
imagesc_env(rmap,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('ratemap');% the original AC
ac0 = xcorr2(rmap);
subplot(345); hold on;
imagesc_env(ac0,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 0^{\circ}'); % the original AC
rmap = smoothratemap(trackpos,trackf,sig,mask,pi/3);
ac60 = xcorr2(rmap);
subplot(346); hold on;
imagesc_env(ac60,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 60^{\circ}'); % the original AC
rmap = smoothratemap(trackpos,trackf,sig,mask,2*pi/3);
ac120 = xcorr2(rmap);
subplot(347); hold on;
imagesc_env(ac120,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 120^{\circ}'); % the original AC

rmap = smoothratemap(trackpos,trackf,sig,mask,pi/6);
ac30 = xcorr2(rmap);
subplot(349); hold on;
imagesc_env(ac30,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 30^{\circ}'); % the original AC
rmap = smoothratemap(trackpos,trackf,sig,mask,pi/2);
ac90 = xcorr2(rmap);
subplot(3,4,10); hold on;
imagesc_env(ac90,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 90^{\circ}'); % the original AC
rmap = smoothratemap(trackpos,trackf,sig,mask,5*pi/6);
ac150 = xcorr2(rmap);
subplot(3,4,11); hold on;
imagesc_env(ac150,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 150^{\circ}'); % the original AC
subplot(3,4,12);
cor = zeros(1,7);
for j = 1:7
    ac = eval(['ac',num2str(30*(j-1))]);
    xcor = corrcoef(ac0(:),ac);
    cor(j) = xcor(1,2);
end
score = min(cor(3:2:5))-max(cor(2:2:6));
plot(0:30:180,cor,'ko-'); title(['gridness = ',num2str(score)]);
figpath = './figures/';
saveas(gcf,[figpath,'gridscore.png']);
disp(dmax);
end