sig = 3;
dmax = ceil(max(sqrt(trackpos(:,1).^2+trackpos(:,2).^2)));
mask = ones(2*dmax+21,2*dmax+21); % minimum environment containing all data
xm = floor(size(mask,1)/2); % the mask matrix is rectangular
ym = floor(size(mask,2)/2);
[ycoor,xcoor] = meshgrid(-ym:ym,-xm:xm); % coordinates of the grid. Note g2d is y by x
% testing
spk = zeros(size(mask));
for j = 1:size(trackf,1)
    spk = spk + exp(-((xcoor-trackf(j,1)).^2+(ycoor-trackf(j,2)).^2)/(2*sig^2)).*((xcoor-trackf(j,1)).^2+(ycoor-trackf(j,2)).^2<=25);
end
dur = zeros(size(mask));
for j = 1:size(trackpos,1)
    dur = dur + exp(-((xcoor-trackpos(j,1)).^2+(ycoor-trackpos(j,2)).^2)/(2*sig^2)).*((xcoor-trackpos(j,1)).^2+(ycoor-trackpos(j,2)).^2<=25);
end
% end of testing
f = figure; set(gcf,'Position',[0 0 1100 700]);
subplot(341); hold on;
imagesc_env(spk,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('spikes'); % the spikes convolved
plot(trackf(:,1),trackf(:,2),'k.');
subplot(342); hold on;
imagesc_env(dur,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('convolved time'); % the time convolved
subplot(343); hold on; 
rmap = smoothratemap(trackpos,trackf,sig,mask);
imagesc_env(rmap,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('ratemap');% the original AC
ac0 = xcorr2(rmap);
subplot(344); hold on;
imagesc_env(ac0,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 0^{\circ}'); % the original AC

theta = pi/3;
trackpos2 = trackpos*rotation_matrix(-theta); 
trackf2 = trackf*rotation_matrix(-theta);
spk = zeros(size(mask));
for j = 1:size(trackf,1)
    spk = spk + exp(-((xcoor-trackf2(j,1)).^2+(ycoor-trackf2(j,2)).^2)/(2*sig^2)).*((xcoor-trackf2(j,1)).^2+(ycoor-trackf2(j,2)).^2<=25);
end
dur = zeros(size(mask));
for j = 1:size(trackpos,1)
    dur = dur + exp(-((xcoor-trackpos2(j,1)).^2+(ycoor-trackpos2(j,2)).^2)/(2*sig^2)).*((xcoor-trackpos2(j,1)).^2+(ycoor-trackpos2(j,2)).^2<=25);
end
subplot(345); hold on;
imagesc_env(spk,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('spikes'); % the spikes convolved
plot(trackf2(:,1),trackf2(:,2),'k.');
subplot(346); hold on;
imagesc_env(dur,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('convolved time'); % the time convolved
subplot(347); hold on; 
rmap = smoothratemap(trackpos,trackf,sig,mask,pi/3);
imagesc_env(rmap,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('ratemap');% the original AC
ac60 = xcorr2(rmap);
subplot(348); hold on;
imagesc_env(ac60,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 60^{\circ}'); % the original AC

theta = pi/3;
trackpos1 = trackpos + [5 10];
trackf1 = trackf + [5 10];
trackpos1 = trackpos1*rotation_matrix(-theta); 
trackf1 = trackf1*rotation_matrix(-theta);
spk = zeros(size(mask));
for j = 1:size(trackf,1)
    spk = spk + exp(-((xcoor-trackf1(j,1)).^2+(ycoor-trackf1(j,2)).^2)/(2*sig^2)).*((xcoor-trackf1(j,1)).^2+(ycoor-trackf1(j,2)).^2<=25);
end
dur = zeros(size(mask));
for j = 1:size(trackpos,1)
    dur = dur + exp(-((xcoor-trackpos1(j,1)).^2+(ycoor-trackpos1(j,2)).^2)/(2*sig^2)).*((xcoor-trackpos1(j,1)).^2+(ycoor-trackpos1(j,2)).^2<=25);
end
rmap = spk./dur;
rmap(isnan(rmap)) = 0;
ac = xcorr2(rmap);
subplot(349); hold on;
imagesc_env(spk,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('spikes'); % the spikes convolved
plot(trackf1(:,1),trackf1(:,2),'k.');
subplot(3,4,10); hold on;
imagesc_env(dur,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('convolved time'); % the time convolved
subplot(3,4,11); hold on; 
imagesc_env(rmap,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('ratemap');% the original AC
subplot(3,4,12); hold on;
imagesc_env(ac,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 60^{\circ} with a shift'); % the original AC

xcor = corrcoef(ac60(:),ac(:));
disp(xcor(1,2));
figpath = './figures/';
saveas(gcf,[figpath,'gridscore_shift.png']);