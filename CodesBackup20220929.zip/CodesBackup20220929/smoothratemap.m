function [rmap,spk,dur] = smoothratemap(trackpos,trackf,sig,mask,theta,mode)
% 
if nargin < 3
    sig = 3;    % standard deviation of gaussian kernel
end
cutoff = sig; % cutoff of the gaussian kernel
if nargin < 4
    rmax = ceil(max(sqrt(trackpos(:,1).^2+trackpos(:,2).^2)));
    mask = ones(2*rmax+1,2*rmax+1); % minimum environment containing all data
elseif mod(size(mask,1),2) == 0 || mod(size(mask,2),2) == 0
    error('Dimensions of the mask should be an odd number')
end
if nargin < 5   
    theta = 0;  % counterclockwise rotation
end
if nargin < 6
    mode = 0;
end
if theta ~= 0
    trackpos = trackpos*rotation_matrix(-theta); 
    % minus sign for counterclockwise wuth multiplication from the right
    trackf = trackf*rotation_matrix(-theta);
end
% convolution of every point of locations and spikes
xm = floor(size(mask,1)/2); % the mask matrix can be rectangular
ym = floor(size(mask,2)/2);
[ycoor,xcoor] = meshgrid(-ym:ym,-xm:xm); % coordinates of the grid. Note g2d is y by x
if mode == 0
    spk = zeros(size(mask));
    for j = 1:size(trackf,1)
        spk = spk + exp(-((xcoor-trackf(j,1)).^2+(ycoor-trackf(j,2)).^2)/(2*sig^2)).*((xcoor-trackf(j,1)).^2+(ycoor-trackf(j,2)).^2<=cutoff^2);
    end
    dur = zeros(size(mask));
    for j = 1:size(trackpos,1)
        dur = dur + exp(-((xcoor-trackpos(j,1)).^2+(ycoor-trackpos(j,2)).^2)/(2*sig^2)).*((xcoor-trackpos(j,1)).^2+(ycoor-trackpos(j,2)).^2<=cutoff^2);
    end
else
    kern = gauss2d(cutoff+1,cutoff+1,sig);
    temp = hist3(trackf,'Edges',{-xm:xm,-ym:ym});
    spk = conv2(temp,kern,'same'); % convolve with the kernel
    temp = hist3(trackpos,'Edges',{-xm:xm,-ym:ym});
    dur = conv2(temp,kern,'same');
end
rmap = spk./(dur*0.04); % dt=0.04; normalization=2*pi*sig^2
%rmap(isnan(rmap)) = 0;
end