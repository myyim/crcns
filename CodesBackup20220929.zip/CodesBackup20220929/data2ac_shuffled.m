function [ac0,ac30,ac60,ac90,ac120,ac150,rmap,thre] = data2ac_shuffled(trackpos,trackf,sig,mask,seed,thre0)
% mask is for ratemap; rad and frad for autocorrelation
%thre = 0.15; 
rad = 150; frad = 0;
dmax = ceil(max(sqrt(trackpos(:,1).^2+trackpos(:,2).^2)));
%mask = ones(2*dmax+1,2*dmax+1); % minimum environment containing all data
if nargin < 6
    is_rotate = 0;
end
if nargin < 5
    seed = 1;
end
[rmap0,~,~] = smoothratemap(trackpos,trackf,sig,mask);
[rmap,thre] = shuffledfields_lowthreshold(rmap0,seed,mask,thre0);
ac0 = xcorr2(rmap);
[ac30,ac60,ac90,ac120,ac150,~,~] = gridscore_interp2(ac0);
end
