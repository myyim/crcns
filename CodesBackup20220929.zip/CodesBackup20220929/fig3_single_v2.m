close all; clear all;

% disp('Note that the codes for smoother rate maps are in the end.');

% parameters
an = [1,1,2,4]; id = [4,9,31,40];   %2,33
% id = [4,9,31,33]; % animals and IDs
rmap_cscale1 = 0.2; rmap_cscale2 = 0.12; % fraction of max as the upper limit of colorbar
ac_cscale1 = 0.25; ac_cscale2 = 0.05;
rm = 75; % the square size is 2rm X 2rm
[y,x] = meshgrid(-rm:rm,-rm:rm);

% functions
% env_patch, getdata, imagesc_env

% data
datapath = './Jacob_Sargolini_All_Environments/'; % update your path here!
allpath = genpath(datapath); addpath(allpath);
codepath = './codes/'; % update your path here!
allpath = genpath(codepath); addpath(allpath);
datapath = './data/'; % update your path here!
allpath = genpath(datapath); addpath(allpath);
load('CellsID.mat');
load('fitcirculartrack.mat'); % pall (fitted parameters)
load('ac_struct.mat');

figure(1); set(gcf,'Position',[0 0 1400 1400]); colormap(jet(256));
fname = CellsID.Arena(id(1)); tID = CellsID.tetrode(id(1)); cID = CellsID.cell(id(1));
fname = char(fname); fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];  
[trackpos,trackf,~] = getdata(fname,1,pall(id(1),:));
rmap = rmap_A(an(1)).E(1).GC(id(1)).rmap; ac = ac_A(an(1)).E(1).GC(id(1)).ac; 
ax = subplot(6,6,1); hold on; plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); xlim([-rm-5,rm+5]); ylim([-rm-5,rm+5]);
axis equal; axis off; title(["Spikes",['rat ',num2str(an(1)),' cell ',num2str(id(1))]]);
ax.YLabel.Visible = 'on'; ylabel('E_1','Rotation',0);
subplot(6,6,3); r = (size(ac,2)-1)/2; imagesc_env(ac,-r:r,-r:r); title('Autocorrelation'); 
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(ac,[],'all')*ac_cscale1]);

fname = CellsID.CircularTrackLight(id(1)); tID = CellsID.tetrode(id(1)); cID = CellsID.cell(id(1));
fname = char(fname); fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];  
[trackpos,trackf,~] = getdata(fname,1,pall(id(1),:));
rmap = rmap_A(an(1)).E(2).GC(id(1)).rmap; ac = ac_A(an(1)).E(2).GC(id(1)).ac;
ax = subplot(6,6,7); hold on;  plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); xlim([-rm-5,rm+5]); ylim([-rm-5,rm+5]);
axis equal; axis off; ax.YLabel.Visible = 'on'; ylabel('E_2','Rotation',0);
subplot(6,6,9); r = (size(ac,2)-1)/2; imagesc_env(ac,-r:r,-r:r);
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(ac,[],'all')*ac_cscale2]);

fname = CellsID.CiruclarTrackDark(id(1)); tID = CellsID.tetrode(id(1)); cID = CellsID.cell(id(1));
fname = char(fname); fname = [fname(1:10),'d_t',num2str(tID),'_c',num2str(cID)];  
[trackpos,trackf,~] = getdata(fname,1,pall(id(1),:));
rmap = rmap_A(an(1)).E(3).GC(id(1)).rmap; ac = ac_A(an(1)).E(3).GC(id(1)).ac;
ax = subplot(6,6,13); hold on; plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); xlim([-rm-5,rm+5]); ylim([-rm-5,rm+5]);
axis equal; axis off; ax.YLabel.Visible = 'on'; ylabel('E_3','Rotation',0);
subplot(6,6,15); r = (size(ac,2)-1)/2; imagesc_env(ac,-r:r,-r:r);
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(ac,[],'all')*ac_cscale2]);

figure(2); set(gcf,'Position',[0 0 1400 1400]); colormap(jet(256));
fname = CellsID.Arena(id(2)); tID = CellsID.tetrode(id(2)); cID = CellsID.cell(id(2));
fname = char(fname); fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];  
[trackpos,trackf,~] = getdata(fname,1,pall(id(2),:));
rmap = rmap_A(an(2)).E(1).GC(id(2)).rmap; ac = ac_A(an(2)).E(1).GC(id(2)).ac;
subplot(6,6,4); hold on; plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); xlim([-rm-5,rm+5]); ylim([-rm-5,rm+5]);
axis equal; axis off; title(["Spikes",['rat ',num2str(an(2)),' cell ',num2str(id(2))]]);  
subplot(6,6,6); r = (size(ac,2)-1)/2; imagesc_env(ac,-r:r,-r:r); title('Autocorrelation');
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(ac,[],'all')*ac_cscale1]);

fname = CellsID.CircularTrackLight(id(2)); tID = CellsID.tetrode(id(2)); cID = CellsID.cell(id(2));
fname = char(fname); fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];  
[trackpos,trackf,~] = getdata(fname,1,pall(id(2),:));
rmap = rmap_A(an(2)).E(2).GC(id(2)).rmap; ac = ac_A(an(2)).E(2).GC(id(2)).ac;
subplot(6,6,10); hold on; plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); xlim([-rm-5,rm+5]); ylim([-rm-5,rm+5]);
axis equal; axis off;
subplot(6,6,12); r = (size(ac,2)-1)/2; imagesc_env(ac,-r:r,-r:r); 
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(ac,[],'all')*ac_cscale2]);

fname = CellsID.CiruclarTrackDark(id(2)); tID = CellsID.tetrode(id(2)); cID = CellsID.cell(id(2));
fname = char(fname); fname = [fname(1:10),'d_t',num2str(tID),'_c',num2str(cID)];  
[trackpos,trackf,~] = getdata(fname,1,pall(id(2),:));
rmap = rmap_A(an(2)).E(3).GC(id(2)).rmap; ac = ac_A(an(2)).E(3).GC(id(2)).ac;
subplot(6,6,16); hold on; plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); xlim([-rm-5,rm+5]); ylim([-rm-5,rm+5]);
axis equal; axis off;
subplot(6,6,18); r = (size(ac,2)-1)/2; imagesc_env(ac,-r:r,-r:r); 
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(ac,[],'all')*ac_cscale2]);

%% lower panels
figure(3); set(gcf,'Position',[0 0 1400 1400]); colormap(jet(256));
fname = CellsID.Arena(id(3)); tID = CellsID.tetrode(id(3)); cID = CellsID.cell(id(3));
fname = char(fname); fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];  
[trackpos,trackf,~] = getdata(fname,1,pall(id(3),:));
rmap = rmap_A(an(3)).E(1).GC(id(3)).rmap; ac = ac_A(an(3)).E(1).GC(id(3)).ac;
ax = subplot(6,6,19); hold on; plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); xlim([-rm-5,rm+5]); ylim([-rm-5,rm+5]);
axis equal; axis off; ax.YLabel.Visible = 'on'; ylabel('E_1','Rotation',0);
title(['rat ',num2str(an(3)),' cell ',num2str(id(3)-19)]); 
subplot(6,6,21); r = (size(ac,2)-1)/2; imagesc_env(ac,-r:r,-r:r); 
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(ac,[],'all')*ac_cscale1*1.4]);  
 
fname = CellsID.CircularTrackLight(id(3)); tID = CellsID.tetrode(id(3)); cID = CellsID.cell(id(3));
fname = char(fname); fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];  
[trackpos,trackf,~] = getdata(fname,1,pall(id(3),:));
rmap = rmap_A(an(3)).E(2).GC(id(3)).rmap; ac = ac_A(an(3)).E(2).GC(id(3)).ac;
ax = subplot(6,6,25); hold on;  plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); xlim([-rm-5,rm+5]); ylim([-rm-5,rm+5]);
axis equal; axis off; ax.YLabel.Visible = 'on'; ylabel('E_2','Rotation',0);
subplot(6,6,27); r = (size(ac,2)-1)/2; imagesc_env(ac,-r:r,-r:r);
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(ac,[],'all')*ac_cscale2]);
 
fname = CellsID.CiruclarTrackDark(id(3)); tID = CellsID.tetrode(id(3)); cID = CellsID.cell(id(3));
fname = char(fname); fname = [fname(1:10),'d_t',num2str(tID),'_c',num2str(cID)];  
[trackpos,trackf,~] = getdata(fname,1,pall(id(3),:));
rmap = rmap_A(an(3)).E(3).GC(id(3)).rmap; ac = ac_A(an(3)).E(3).GC(id(3)).ac;
ax = subplot(6,6,31); hold on; plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); xlim([-rm-5,rm+5]); ylim([-rm-5,rm+5]);
axis equal; axis off; ax.YLabel.Visible = 'on'; ylabel('E_3','Rotation',0);
subplot(6,6,33); r = (size(ac,2)-1)/2; imagesc_env(ac,-r:r,-r:r);
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(ac,[],'all')*ac_cscale2]);
xlabel('lag (cm)');

figure(4); set(gcf,'Position',[0 0 1400 1400]); colormap(jet(256));
fname = CellsID.Arena(id(4)); tID = CellsID.tetrode(id(4)); cID = CellsID.cell(id(4));
fname = char(fname); fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];  
[trackpos,trackf,~] = getdata(fname,1,pall(id(4),:));
rmap = rmap_A(an(4)).E(1).GC(id(4)).rmap; ac = ac_A(an(4)).E(1).GC(id(4)).ac;
subplot(6,6,22); hold on; plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); xlim([-rm-5,rm+5]); ylim([-rm-5,rm+5]);
axis equal; axis off; title(['rat ',num2str(an(4)),' cell ',num2str(id(4)-19)]);  
subplot(6,6,23); r = (size(rmap,2)-1)/2; imagesc_env(rmap,-r:r,-r:r,1);
caxis([0 max(rmap,[],'all')*rmap_cscale1]); title('Rate Map');
xlim([-rm-5,rm+5]); ylim([-rm-5,rm+5]); %text(rm-20,-rm,[num2str(max(max(rmap)),'%.1f'),'Hz']);
subplot(6,6,24); r = (size(ac,2)-1)/2; imagesc_env(ac,-r:r,-r:r);
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(ac,[],'all')*ac_cscale1*0.75]);

fname = CellsID.CircularTrackLight(id(4)); tID = CellsID.tetrode(id(4)); cID = CellsID.cell(id(4));
fname = char(fname); fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];  
[trackpos,trackf,~] = getdata(fname,1,pall(id(4),:));
rmap = rmap_A(an(4)).E(2).GC(id(4)).rmap; ac = ac_A(an(4)).E(2).GC(id(4)).ac;
subplot(6,6,28); hold on; plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); xlim([-rm-5,rm+5]); ylim([-rm-5,rm+5]);
axis equal; axis off;
subplot(6,6,30); r = (size(ac,2)-1)/2; imagesc_env(ac,-r:r,-r:r); 
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(ac,[],'all')*ac_cscale2]);
xlabel('lag (cm)');
 
%% Use smoother rate maps
load('ac_struct_s3c6.mat'); 
for j = 1:4
    figure(j);
    subplot(6,6,3*(j-1)+12*(j>=3)+2); rmap = rmap_A(an(j)).E(1).GC(id(j)).rmap; r = (size(rmap,2)-1)/2; imagesc_env(rmap,-r:r,-r:r,1); 
    xlim([-rm-5,rm+5]); ylim([-rm-5,rm+5]); %text(rm-20,-rm,[num2str(max(max(rmap)),'%.1f'),'Hz']);
    colormap(jet(256)); caxis([0 max(rmap,[],'all')*rmap_cscale1]);
    if j < 3
        title('Rate Map');
    end
    subplot(6,6,3*(j-1)+12*(j>=3)+8); rmap = rmap_A(an(j)).E(2).GC(id(j)).rmap; r = (size(rmap,2)-1)/2; imagesc_env(rmap,-r:r,-r:r,1); 
    xlim([-rm-5,rm+5]); ylim([-rm-5,rm+5]); %text(rm-20,-rm,[num2str(max(max(rmap)),'%.1f'),'Hz']);
    colormap(jet(256)); caxis([0 max(rmap,[],'all')*rmap_cscale2]);
    if j < 4
        subplot(6,6,3*(j-1)+12*(j>=3)+14); rmap = rmap_A(an(j)).E(3).GC(id(j)).rmap; r = (size(rmap,2)-1)/2; imagesc_env(rmap,-r:r,-r:r,1); 
        xlim([-rm-5,rm+5]); ylim([-rm-5,rm+5]); %text(rm-20,-rm,[num2str(max(max(rmap)),'%.1f'),'Hz']);
        colormap(jet(256)); caxis([0 max(rmap,[],'all')*rmap_cscale2]);
    end
end

figure(1);
set(findall(gcf,'-property','FontSize'),'FontSize',15);
set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,...
    'PaperPosition',[0 0 screenposition(3:4)],...
    'PaperSize',[screenposition(3:4)]);
print -dpdf fig3_single_A

figure(2);
set(findall(gcf,'-property','FontSize'),'FontSize',15);
set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,...
    'PaperPosition',[0 0 screenposition(3:4)],...
    'PaperSize',[screenposition(3:4)]);
print -dpdf fig3_single_B

figure(3);
set(findall(gcf,'-property','FontSize'),'FontSize',15);
set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,...
    'PaperPosition',[0 0 screenposition(3:4)],...
    'PaperSize',[screenposition(3:4)]);
print -dpdf fig3_single_C

figure(4);
set(findall(gcf,'-property','FontSize'),'FontSize',15);
set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,...
    'PaperPosition',[0 0 screenposition(3:4)],...
    'PaperSize',[screenposition(3:4)]);
print -dpdf fig3_single_D
