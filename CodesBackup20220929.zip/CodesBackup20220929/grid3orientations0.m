function [oris,xs,ys,a] = grid3orientations(a,rad,frad)
r = (size(a,1)-1)/2;
[ycoor,xcoor] = meshgrid(-r:r,-r:r);
a(xcoor.^2+ycoor.^2<frad^2) = 0; a(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0; % extract the ring
[val,~] = max(max(a));
a(xcoor<0) = 0; % consider half of autocorr due to symmetry
%a(a<val*exp(-1/2)) = 0; % thresholding
a(a<val*0.7) = 0; % thresholding
cc = bwconncomp(a);   % find connected components in binary image
numPixels = cellfun(@numel,cc.PixelIdxList);
k = 0;
while size(numPixels,2) < 3 && k <= 25
    k = k+1;
    a(a<val*(0.7+k*0.01)) = 0; % thresholding
    cc = bwconncomp(a,8);   % find connected components in binary image
    numPixels = cellfun(@numel,cc.PixelIdxList);
end
temp = numPixels;
oris = []; xs = []; ys = [];
for j = 1:min([size(numPixels,2) 3])
    [big,idx] = max(temp); % largest bump
    temp(temp==big) = 0;
    [~,id] = max(a(cc.PixelIdxList{idx}));
    id = cc.PixelIdxList{idx}(id);
    [row,col] = ind2sub(size(a),id);
    y = row-r-1; x = col-r-1;
    %disp([row col atan2(y,x)*180/pi]);
    oris = [oris atan2(y,x)*180/pi]; xs = [xs x]; ys = [ys y];
end
if any(oris<20) && any(oris>160)
    id1 = find(oris<20); id2 = find(oris>160);
    if id1 < id2    % larger cluster < 20 deg
        a(atan2(xcoor,ycoor)*180/pi>160) = 0;    % discard the cluster > 160
    else
        a(atan2(xcoor,ycoor)*180/pi<20) = 0;    % else discard the cluster < 20
    end
    cc = bwconncomp(a);   % find connected components in binary image
    numPixels = cellfun(@numel,cc.PixelIdxList);
    k = 0;
    while size(numPixels,2) < 3 && k <= 25
        k = k+1;
        a(a<val*(0.7+k*0.01)) = 0; % thresholding
        cc = bwconncomp(a,8);   % find connected components in binary image
        numPixels = cellfun(@numel,cc.PixelIdxList);
    end
    temp = numPixels;
    oris = []; xs = []; ys = [];
    for j = 1:min([size(numPixels,2) 3])
        [big,idx] = max(temp); % largest bump
        temp(temp==big) = 0;
        [~,id] = max(a(cc.PixelIdxList{idx}));
        id = cc.PixelIdxList{idx}(id);
        [row,col] = ind2sub(size(a),id);
        y = row-r-1; x = col-r-1;
        %disp([row col atan2(y,x)*180/pi]);
        oris = [oris atan2(y,x)*180/pi]; xs = [xs x]; ys = [ys y];
    end
end
oris = round(oris);
%oris = sort(round(oris));
end