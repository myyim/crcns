function imagesc_env(mat,x,y,is_transparent)
% imagesc_env(mat,x,y,is_transparent) returns the colormap for mat 
% with binnings x and y in the desirable format.
% is_transparent = 1 will set all nan values to be transparent.
% is_transparent = 2 will set all nan and 0 values to be transparent.
if nargin == 1
    x = 1:size(mat,1);
    y = 1:size(mat,2);
end
if nargin < 4
    is_transparent = 0;
end

if is_transparent == 0
    imagesc(x,y,mat);
else
    alpha = ones(size(mat')); alpha(isnan(mat')) = 0;
    if is_transparent == 2
        alpha(mat'==0) = 0;
    end
    imagesc(x,y,mat','AlphaData',alpha); 
    set(gca,'color',[1 1 1]); axis off;    
end
axis image; set(gca,'YDir','normal');
end