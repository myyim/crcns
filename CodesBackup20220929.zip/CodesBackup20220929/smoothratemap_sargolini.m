function [rmap,spk,dur] = smoothratemap_sargolini(trackpos,trackf,sig,bin)
% trying to replicate Sargolini's analysis:
% Bins = 2.5 cm × 2.5 cm
% A Gaussian kernel was used with h = 2 × 2.5 cm.
if nargin < 4
    bin = 2.5;
end
if nargin < 3
    sig = 5;    % standard deviation of gaussian kernel
end
cutoff = bin; % cutoff of the gaussian kernel
rmax = ceil(max(sqrt(trackpos(:,1).^2+trackpos(:,2).^2)));
x0 = -rmax:bin:rmax;  
y0 = x0;
gau = gauss2d(cutoff/bin+1,cutoff/bin+1,sig);
x_edge = [x0-bin/2,x0(end)+bin/2]; % for histcounts2 (edges)
y_edge = [y0-bin/2,y0(end)+bin/2];
dur = histcounts2(trackpos(:,1),trackpos(:,2),x_edge,y_edge);    % time spent on each bin in 2D
spk = histcounts2(trackf(:,1),trackf(:,2),x_edge,y_edge);  % spike count on each bin in 2D
dur = conv2(dur,gau,'same'); % convolution of binned timestamps
spk = conv2(spk,gau,'same');
rmap = spk./(dur*0.04*(2*pi*sig^2)); % dt=0.04; normalization=2*pi*sig^2
end
