close all; clear all;
norm = 2; % 0: no normalization; 1: overall peak; 2: peak within donut
r = 150;
sd_range = 0.05; % max spatial frequency in PSD
%rmesh = -2*lmesh:2*lmesh;
halfw = 5;
[ycoor,xcoor] = meshgrid(-r:r,-r:r);
load('./ac_struct64.mat');
% animal
a = 5;
if a == 4
    idx = [40]; % animal 4
elseif a == 5
    idx = [60]; % animal 5 delete 52 55
end

figpath = './figures/Jacob_Sargolini_across_cells/';
if ~exist(figpath)
    mkdir(figpath);
end
addpath(figpath);

figure(1); set(gcf,'Position',[0 0 1100 600]);
figure(2); set(gcf,'Position',[0 0 1100 600]);
% figure(4); set(gcf,'Position',[0 0 1100 600]);
% figure(5); set(gcf,'Position',[0 0 1100 600]);
figure(6); set(gcf,'Position',[0 0 1100 600]);
aE0 = zeros(2*r+1,2*r+1); aE30 = zeros(2*r+1,2*r+1); aE60 = zeros(2*r+1,2*r+1); 
aE90 = zeros(2*r+1,2*r+1); aE120 = zeros(2*r+1,2*r+1); aE150 = zeros(2*r+1,2*r+1);

for e = [1,2] % environment
    a0 = zeros(2*r+1,2*r+1); a30 = zeros(2*r+1,2*r+1); a60 = zeros(2*r+1,2*r+1); 
    a90 = zeros(2*r+1,2*r+1); a120 = zeros(2*r+1,2*r+1); a150 = zeros(2*r+1,2*r+1);
    for i = 1:size(idx,2)    % cell ID
        ac0 = ac_A(a).E(e).GC(idx(i)).ac;
        [ac30,ac60,ac90,ac120,ac150,~,~] = gridscore_interp2(ac0);
        for k = 0:5 % rotation out of 6            
            %eval(['ac = ac_A(a).E(e).GC(idx(i)).R',num2str(k*30),';']);
            %eval(['ac = f.ac.A',num2str(a),'.E',num2str(e),'(idx(i)).R',num2str(k*30),';']);
            eval(['ac = ac',num2str(k*30),';']); 
            s = size(ac,1); 
            if s < 2*r+1    % zero-padding when size of ac is smaller than r
                temp = zeros(2*r+1,2*r+1);
                temp((2*r+1-s)/2+1:2*r+1-(2*r+1-s)/2,(2*r+1-s)/2+1:2*r+1-(2*r+1-s)/2) = ac;
                ac = temp;
            else
                ac = ac((s+1)/2-r:(s+1)/2+r,(s+1)/2-r:(s+1)/2+r);   % reshape ac
            end
            eval(['t',num2str(k*30),'= ac;']);
        end
        if a == 4 && e == 2
            [rad,frad,~,deriv] = max_activity_ring(t0,60,90);
        elseif a == 5
            [rad,frad,~,deriv] = max_activity_ring(t0,30,50);
        else
            [rad,frad,~,deriv] = max_activity_ring(t0);
        end
        [oris,xs,ys,ath] = grid3orientations(ac0,rad,rad-halfw);
        [score,~] = gridness(t0,t30,t60,t90,t120,t150,rad,frad);
        ori = gridorientation(t0,rad,frad);
        acplot = t0; 
        ringplot = t0; ringplot(xcoor.^2+ycoor.^2<frad^2) = 0; ringplot(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0; % extract the ring
        if norm == 0
            acmax = 1;
        elseif norm == 1
            acmax = max(max(acplot));
        elseif norm == 2
            acmax = max(max(ringplot));
        end
        if acmax ~= 0
            acplot = acplot/acmax; ringplot = ringplot/acmax;
            for k = 0:5
              eval(['a',num2str(k*30),' = a',num2str(k*30),' + t',num2str(k*30),'/acmax;']);
            end 
        end       
        figure(e); subplot(4,5,5*(i-1)+1); hold on;
        imagesc_env(acplot,-r:r,-r:r); plot(xs,ys,'w+','MarkerSize',8); 
        axis image; colormap(jet(256)); colorbar; caxis([0 max(max(ringplot))]);
        titlestring = [num2str(deriv),': \color{blue}',num2str(frad),'; \color{red}',num2str(rad),'; ',num2str(round(mean(sqrt(xs.^2+ys.^2)))),'\color{black}; '];
        for j = 1:size(oris,2)
            titlestring = [titlestring,num2str(oris(j)),'^{\circ} ']; 
        end
        title([titlestring,'; g:',num2str(score,2)]);
        plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
        plot(frad*cos(0:0.01:2*pi+0.01),frad*sin(0:0.01:2*pi+0.01),'w');
        plot((2*rad-frad)*cos(0:0.01:2*pi+0.01),(2*rad-frad)*sin(0:0.01:2*pi+0.01),'w');
    end
    sgtitle(['Animal ',num2str(a),'; Environment ',num2str(e)]);
    if a == 4 && e == 2
        [rad,frad,a0r,deriv] = max_activity_ring(a0,60,90);
    elseif a == 5
        [rad,frad,a0r,deriv] = max_activity_ring(a0,30,50);
    else
        [rad,frad,a0r,deriv] = max_activity_ring(a0);
    end
    [score,cor] = gridness(a0,a30,a60,a90,a120,a150,rad,frad);
    ori = gridorientation(a0,rad,frad);

    figure(6); 
    subplot(4,4,4*(e-(e>3)-1)+1); hold on; 
    plot([0,r],[0,0],'k:'); plot(a0r,'k');
    plot(rad*ones(1,2),[0,a0r(rad)],'r'); plot(frad*ones(1,2),[0,a0r(frad)],'b');
    xlabel('radius'); ylabel('mean autocorr'); xlim([0 r]); ylim([0 2*a0r(rad)]);
    title([num2str(deriv),': \color{blue}',num2str(frad),'; \color{red}',num2str(rad),'\color{black}; ',num2str(round(ori)),'^{\circ}']);
    subplot(4,4,4*(e-(e>3)-1)+2); hold on;
    imagesc_env(a0,-r:r,-r:r); axis image; colormap(jet(256)); colorbar; 
    a0(xcoor.^2+ycoor.^2<frad^2) = 0; a0(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0; % extract the ring
    caxis([0 max(max(a0))]); title(['autocorr in E',num2str(e)]);
    plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
    plot(frad*cos(0:0.01:2*pi+0.01),frad*sin(0:0.01:2*pi+0.01),'w');
    plot((2*rad-frad)*cos(0:0.01:2*pi+0.01),(2*rad-frad)*sin(0:0.01:2*pi+0.01),'w');
    subplot(4,4,4*(e-(e>3)-1)+3); hold on;    
    imagesc_env(a0,-r:r,-r:r); axis image; colormap(jet(256)); colorbar; 
    caxis([0 max(max(a0))]); title(['autocorr in E',num2str(e)]);
    plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
    plot(frad*cos(0:0.01:2*pi+0.01),frad*sin(0:0.01:2*pi+0.01),'w');
    plot((2*rad-frad)*cos(0:0.01:2*pi+0.01),(2*rad-frad)*sin(0:0.01:2*pi+0.01),'w');
    subplot(4,4,4*(e-(e>3))); hold on;
    plot(0:30:150,cor,'ko-'); title(['gridness = ',num2str(score)]);
end

saveas(1,[figpath,'sel_gridness_a',num2str(a),'e1norm',num2str(norm),'.png']);
saveas(2,[figpath,'sel_gridness_a',num2str(a),'e2norm',num2str(norm),'.png']);
% saveas(4,[figpath,'sel_gridness_a',num2str(a),'e4norm',num2str(norm),'.png']);
% saveas(5,[figpath,'sel_gridness_a',num2str(a),'e5norm',num2str(norm),'.png']);
saveas(6,[figpath,'sel_gridness_a',num2str(a),'allnorm',num2str(norm),'.png']);
