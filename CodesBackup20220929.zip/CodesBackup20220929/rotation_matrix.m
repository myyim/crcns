function M = rotation_matrix(theta)
% M = rotation_matrix(theta) returns the rotation matrix in the
% counterclockwise direction. For clockwise direction, use negative values
% for theta.
M = [cos(theta), -sin(theta); sin(theta), cos(theta)];
end