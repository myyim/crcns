function ori = gridorientation(a,rad,frad)
r = (size(a,1)-1)/2;
[ycoor,xcoor] = meshgrid(-r:r,-r:r);
a(xcoor.^2+ycoor.^2<frad^2) = 0; a(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0; % extract the ring
[~,col] = max(max(a));
[~,row] = max(a(:,col));
y = col-r-1;
x = row-r-1;
angle_radian = atan2(x,y);
ori = mod(angle_radian,pi/3)*180/pi;
if ori > 30
    ori = ori - 60;
end
end