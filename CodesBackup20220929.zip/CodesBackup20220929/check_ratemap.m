close all; clear all;

figpath = './figures/check/';
if ~exist(figpath)
    mkdir(figpath);
end
addpath(figpath);

datapath = './Jacob_Sargolini_All_Environments/'; % update your path here!
allpath = genpath(datapath); addpath(allpath);

load('CellsID.mat');
load('fitcirculartrack.mat'); % pall (fitted parameters)

id = [4,9];
rmap_cscale1 = 0.2; rmap_cscale2 = 0.1;
rm = 75; 

for j = 1:size(id,2)
    figure(j); set(gcf,'Position',[0 0 1400 700]);
    fname = CellsID.Arena(id(j)); tID = CellsID.tetrode(id(j)); cID = CellsID.cell(id(j));
    fname = char(fname); fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];  
    [trackpos,trackf,~] = getdata(fname,1,pall(id(1),:));
    subplot(251); hold on; plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
    plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); xlim([-rm-5,rm+5]); ylim([-rm-5,rm+5]);
    axis equal; axis off; title(['rat ',num2str(1),' cell ',num2str(id(j))]);
    fname = CellsID.CircularTrackLight(id(j)); tID = CellsID.tetrode(id(j)); cID = CellsID.cell(id(j));
    fname = char(fname); fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];  
    [trackpos,trackf,~] = getdata(fname,1,pall(id(1),:));
    subplot(256); hold on; plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
    plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); xlim([-rm-5,rm+5]); ylim([-rm-5,rm+5]);
    axis equal; axis off; title(['rat ',num2str(1),' cell ',num2str(id(j))]);
    for k = 1:4
        if k == 1
            fname = 'ac_struct.mat'; 
        elseif k == 2
            fname = 'ac_struct_s3c6.mat'; 
        elseif k == 3
            fname = 'ac_struct_b1s3c3.mat'; 
        elseif k == 4
            fname = 'ac_struct_b1s3c6.mat'; 
        end
        load(fname);
        subplot(2,5,1+k);
        rmap = rmap_A(1).E(1).GC(id(j)).rmap; r = (size(rmap,2)-1)/2; imagesc_env(rmap,-r:r,-r:r,1); 
        xlim([-rm-5,rm+5]); ylim([-rm-5,rm+5]); text(rm-20,-rm,[num2str(max(max(rmap)),'%.1f'),'Hz']);
        colormap(jet(256)); caxis([0 5]); title(fname);
        subplot(2,5,6+k);
        rmap = rmap_A(1).E(2).GC(id(j)).rmap; r = (size(rmap,2)-1)/2; imagesc_env(rmap,-r:r,-r:r,1); 
        xlim([-rm-5,rm+5]); ylim([-rm-5,rm+5]); text(rm-20,-rm,[num2str(max(max(rmap)),'%.1f'),'Hz']);
        colormap(jet(256)); caxis([0 5]); %caxis([0 max(rmap,[],'all')*rmap_cscale2]);
    end
    saveas(gcf,[figpath,'check_ratemap',num2str(id(j)),'.png']);
end

