close all; clear all;
figpath = './figures/';
addpath('./gridness/');
xm = 75; ym = 75; % the size is 2rx X 2ry
dmax = max([xm ym]);
lam = 41;   % grid period
psi = 0.31; % grid orientation
[y,x] = meshgrid(-ym:ym,-xm:xm);    
[ycoor,xcoor] = meshgrid(-2*ym:2*ym,-2*xm:2*xm);

figure; set(gcf,'Position',[0 0 1100 600]);
% First row: default grid
[ac,ac0r,rad,fsize,cor,score] = gridscore_ratemap(y,x,lam,psi);
rmap = gridcell(y,x,1,lam,psi,[0,0]);  % from left to right in a matrix is in the direction of increasing the second coordinate, thus (y,x)
subplot(341); imagesc_env(rmap,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('ratemap');
subplot(342); hold on; ac0 = ac; ac0(xcoor.^2+ycoor.^2<fsize^2) = 0; ac0(xcoor.^2+ycoor.^2>(2*rad-fsize)^2) = 0;
imagesc_env(ac0,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; caxis([0 max(ac(x.^2+y.^2>=fsize^2))]); title('autocorr at 0^{\circ}'); % the original AC
xlim([-xm xm]); ylim([-ym ym]);
plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
plot(fsize*cos(0:0.01:2*pi+0.01),fsize*sin(0:0.01:2*pi+0.01),'w');
plot((2*rad-fsize)*cos(0:0.01:2*pi+0.01),(2*rad-fsize)*sin(0:0.01:2*pi+0.01),'w');
subplot(343); hold on; 
plot([0,dmax],[0,0],'k:'); plot(ac0r,'k');
plot(rad*ones(1,2),[0,ac0r(rad)],'r'); plot(fsize*ones(1,2),[0,ac0r(fsize)],'b');
xlabel('radius'); ylabel('mean autocorr along a circle'); xlim([0 dmax]); 
title(['1st: \color{blue}',num2str(fsize),'; \color{red}',num2str(rad)]);
subplot(344); plot(0:30:150,cor,'ko-'); title(['gridness = ',num2str(score)]);

% Second row: narrower grid
thre = 0.5;
[ac,ac0r,rad,fsize,cor,score] = gridscore_ratemap(y,x,lam,psi,thre);
rmap = gridcell(y,x,1,lam,psi,[0,0],thre);  % from left to right in a matrix is in the direction of increasing the second coordinate, thus (y,x)
subplot(345); imagesc_env(rmap,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('ratemap');
subplot(346); hold on; ac0 = ac; ac0(xcoor.^2+ycoor.^2<fsize^2) = 0; ac0(xcoor.^2+ycoor.^2>(2*rad-fsize)^2) = 0;
imagesc_env(ac0,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; caxis([0 max(ac(x.^2+y.^2>=fsize^2))]); title('autocorr at 0^{\circ}'); % the original AC
xlim([-xm xm]); ylim([-ym ym]);
plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
plot(fsize*cos(0:0.01:2*pi+0.01),fsize*sin(0:0.01:2*pi+0.01),'w');
plot((2*rad-fsize)*cos(0:0.01:2*pi+0.01),(2*rad-fsize)*sin(0:0.01:2*pi+0.01),'w');
subplot(347); hold on; 
plot([0,dmax],[0,0],'k:'); plot(ac0r,'k');
plot(rad*ones(1,2),[0,ac0r(rad)],'r'); plot(fsize*ones(1,2),[0,ac0r(fsize)],'b');
xlabel('radius'); ylabel('mean autocorr along a circle'); xlim([0 dmax]); 
title(['1st: \color{blue}',num2str(fsize),'; \color{red}',num2str(rad)]);
subplot(348); plot(0:30:150,cor,'ko-'); title(['gridness = ',num2str(score)]);

% Third row: shuffled bumps
[rmap,ac,ac60,ac120,ac30,ac90,ac150,ac0r,rad,fsize,cor,score] = gridscore_shuffled(y,x,lam,psi);
subplot(349); imagesc_env(rmap,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('ratemap');
subplot(3,4,10); hold on; ac0 = ac; ac0(xcoor.^2+ycoor.^2<fsize^2) = 0; ac0(xcoor.^2+ycoor.^2>(2*rad-fsize)^2) = 0;
imagesc_env(ac0,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; caxis([0 max(ac(x.^2+y.^2>=fsize^2))]); title('autocorr at 0^{\circ}'); % the original AC
xlim([-xm xm]); ylim([-ym ym]);
plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
plot(fsize*cos(0:0.01:2*pi+0.01),fsize*sin(0:0.01:2*pi+0.01),'w');
plot((2*rad-fsize)*cos(0:0.01:2*pi+0.01),(2*rad-fsize)*sin(0:0.01:2*pi+0.01),'w');
subplot(3,4,11); hold on; 
plot([0,dmax],[0,0],'k:'); plot(ac0r,'k');
plot(rad*ones(1,2),[0,ac0r(rad)],'r'); plot(fsize*ones(1,2),[0,ac0r(fsize)],'b');
xlabel('radius'); ylabel('mean autocorr along a circle'); xlim([0 dmax]); 
title(['1st: \color{blue}',num2str(fsize),'; \color{red}',num2str(rad)]);
subplot(3,4,12); plot(0:30:150,cor,'ko-'); title(['gridness = ',num2str(score)]);
%saveas(gcf,[figpath,'gridscore_ratemap',num2str(lam),'.png']);

if 0
    figure; set(gcf,'Position',[0 0 800 600]);
    subplot(231); hold on; imagesc_env(ac,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 0^{\circ}'); % the original AC
    subplot(232); hold on; imagesc_env(ac60,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 60^{\circ}');
    subplot(233); hold on; imagesc_env(ac120,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 120^{\circ}'); 
    subplot(234); hold on; imagesc_env(ac30,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 30^{\circ}');
    subplot(235); hold on; imagesc_env(ac90,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 90^{\circ}'); 
    subplot(236); hold on; imagesc_env(ac150,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 150^{\circ}'); 
end