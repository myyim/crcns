function [ac0,ac30,ac60,ac90,ac120,ac150] = data2ac(trackpos,trackf,sig,mask)
dmax = ceil(max(sqrt(trackpos(:,1).^2+trackpos(:,2).^2)));
if nargin < 4
    mask = ones(2*dmax+1,2*dmax+1); % minimum environment containing all data
end
[rmap,~,~] = smoothratemap(trackpos,trackf,sig,mask);
ac0 = xcorr2(rmap);
[ac30,ac60,ac90,ac120,ac150,~,~] = gridscore_interp2(ac0);

%[xm,ym] = size(ac0); xm = (xm-1)/2; ym = (ym-1)/2;
%[ycoor,xcoor] = meshgrid(-ym:ym,-xm:xm); % coordinates of the grid, y by x
%ac0(xcoor.^2+ycoor.^2<frad^2) = 0; ac0(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0;

% [rmap,~,~] = smoothratemap(trackpos,trackf,sig,mask,pi/3);
% ac60 = xcorr2(rmap); ac60(xcoor.^2+ycoor.^2<frad^2) = 0; ac60(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0;
% [rmap,~,~] = smoothratemap(trackpos,trackf,sig,mask,2*pi/3);
% ac120 = xcorr2(rmap); ac120(xcoor.^2+ycoor.^2<frad^2) = 0; ac120(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0;
% [rmap,~,~] = smoothratemap(trackpos,trackf,sig,mask,pi/6);
% ac30 = xcorr2(rmap); ac30(xcoor.^2+ycoor.^2<frad^2) = 0; ac30(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0;
% [rmap,~,~] = smoothratemap(trackpos,trackf,sig,mask,pi/2);
% ac90 = xcorr2(rmap); ac90(xcoor.^2+ycoor.^2<frad^2) = 0; ac90(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0;
% [rmap,~,~] = smoothratemap(trackpos,trackf,sig,mask,5*pi/6);
% ac150 = xcorr2(rmap); ac150(xcoor.^2+ycoor.^2<frad^2) = 0; ac150(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0;
end
