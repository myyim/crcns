close all; clear all;
datapath = './Jacob_Sargolini_Data/light_large/'; % enter your data path here!
addpath(datapath);
addpath('./gridness/');
%load('CellIDarena.mat'); % data 2d
load('CellIDtrack.mat');    % data track
figpath = './figures/';
score_array = []; rad_array = []; fsize_array = []; d1_array = [];
for j = 1:71
    %[trackpos,trackf,ts] = getdata_sargolini(CellIDarena{j,1},CellIDarena{j,2},CellIDarena{j,3},1); % data 2d
    [trackpos,trackf,ts] = getdata_sargolini(CellIDtrack{j,1},CellIDtrack{j,2},CellIDtrack{j,3},1); % data track
    [score,rad,fsize,d1] = gridscore(trackpos,trackf);
    score_array = [score_array score]; rad_array = [rad_array rad]; fsize_array = [fsize_array fsize]; d1_array = [d1_array d1];
    if isnan(score)
        %disp(['Please check ',CellIDarena{j,1},num2str(CellIDarena{j,2}),num2str(CellIDarena{j,3})]);
    end
    saveas(gcf,[figpath,'gridscore_track',num2str(j),'.png']);
end
figure; set(gcf,'Position',[0 0 600 450]);
subplot(221); histogram(score_array,-1:0.1:2); xlabel('score'); title('all');
subplot(222); hold on; histogram(score_array(d1_array==1),-1:0.1:2); histogram(score_array(d1_array==0),-1:0.1:2); title('with & without max'); xlabel('score');
subplot(223); histogram(rad_array,0:5:100); ylabel('spacing'); title('all');
subplot(224); hold on; histogram(rad_array(score_array>0.1),0:5:100); ylabel('spacing'); title('score > 0.1');
saveas(gcf,[figpath,'gridscore_track_stat.png']);