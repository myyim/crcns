close all; clear all;
datapath = './Jacob_Sargolini_Data/light_large/'; % enter your data path here!
addpath(datapath);
addpath('./gridness/');
load('CellIDarena.mat'); % data 2d
% load('CellIDtrack.mat');    % data track
figpath = './figures/';

% define the circular extraction
rad_extract = 75-15/2;   % mid-radius of the track
tractw_extract = 20;  % track width of the extraction; can be larger than actual width because animals' head can be outside
t = 0:0.01:2*pi+0.01; % for plotting circles

score_array = []; rad_array = []; fsize_array = []; d1_array = [];
for j = 1:71 %71
    [trackpos_extract,trackf_extract,ts] = getdata_sargolini(CellIDarena{j,1},CellIDarena{j,2},CellIDarena{j,3},4,tractw_extract,rad_extract); % data 2d
    % file name, tetrode ID, cell ID, 4=extract circular track from given data
    [score,rad,fsize,d1] = gridscore(trackpos_extract,trackf_extract);
    score_array = [score_array score]; rad_array = [rad_array rad]; fsize_array = [fsize_array fsize]; d1_array = [d1_array d1];
    if isnan(score)
        disp(['Please check ',CellIDarena{j,1},num2str(CellIDarena{j,2}),num2str(CellIDarena{j,3})]);
    end
    saveas(gcf,[figpath,'gridscore_extract',num2str(j),'.png']);
end
figure; set(gcf,'Position',[0 0 600 450]);
subplot(221); histogram(score_array,-1:0.1:2); xlabel('score'); title('all');
subplot(222); hold on; histogram(score_array(d1_array==1),-1:0.1:2); histogram(score_array(d1_array==0),-1:0.1:2); title('with & without max'); xlabel('score');
subplot(223); histogram(rad_array,0:5:100); ylabel('spacing'); title('all');
subplot(224); hold on; histogram(rad_array(score_array>0.1),0:5:100); ylabel('spacing'); title('score > 0.1');
saveas(gcf,[figpath,'gridscore_extract_stat.png']);