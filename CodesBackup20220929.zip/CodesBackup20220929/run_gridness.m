close all; clear all;

%% which datapath?
% 1: Large Arena matlab files (all 64 cells)
% 2: Large Circular track light matlab files (all 64 cells)
% 3: Large Circular track dark matlab files (35 cells)
% 4: Small Arena matlab files (29 cells)
% 5: Small Circular track matlab files (29 cells)
dp = 1;

%% load paths and data
datapath = './Jacob_Sargolini_All_Environments/'; % update your path here!
allpath = genpath(datapath);
addpath(allpath);
addpath('./gridness/');
load('./CellsID.mat');
load('./fitcirculartrack.mat'); % load data pall (fitted parameters)
figpath = './figures/Jacob_Sargolini_gridness_circular_light/';
if ~exist(figpath)
    mkdir(figpath);
end
addpath(figpath);
if dp == 1
    %addpath([datapath,'Large Arena matlab files/']);
    filename = 'CellsID.Arena';
elseif dp == 2
    %addpath([datapath,'Large Circular track light matlab files/']);
    filename = 'CellsID.CircularTrackLight';
elseif dp == 3
    %addpath([datapath,'Large Circular track dark matlab files/']);
    filename = 'CellsID.CiruclarTrackDark';
elseif dp == 4
    %addpath([datapath,'Small Arena matlab files/']);
    filename = 'CellsID.SmallArena';
elseif dp == 5
    %addpath([datapath,'Small Circular track matlab files/']);
    filename = 'CellsID.SmallCircularTrack';
end

%% main
score_array = []; rad_array = []; frad_array = []; deriv_array = []; count = 0;
for j = 7:7    % filenames
    eval(['fname = ',filename,'(j);']);
    if fname == ""
        continue
    end
    tID = CellsID.tetrode(j);
    cID = CellsID.cell(j);
    fname = char(fname);
    if fname(1) == 'M'
        if dp == 1
            fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];          
        else
            fname = [fname(1:11),'_t',num2str(tID),'_c',num2str(cID)];
        end
    else
        fname = [fname(1:16),'_t',num2str(tID),'_c',num2str(cID)];
    end
    [trackpos,trackf,~] = getdata_sargolini(fname,tID,cID,1,pall(j,:)); % pall stores the fitted parameters
    [score,rad,frad,deriv] = gridscore(trackpos,trackf);
    if ~isnan(score)
        score_array = [score_array score]; rad_array = [rad_array rad]; frad_array = [frad_array frad]; deriv_array = [deriv_array deriv];
    else
        disp(['Loop ',num2str(j),': Please check ',fname]);
    end
    if fname(1) == 'M'
        if dp == 1
            fname = [fname(1:10),'l\_t',num2str(tID),'\_c',num2str(cID)];          
        else
            fname = [fname(1:11),'\_t',num2str(tID),'\_c',num2str(cID)];
        end
    else
        fname = [fname(1:16),'\_t',num2str(tID),'\_c',num2str(cID)];
    end
    sgtitle(fname);
    %saveas(gcf,[figpath,'gridscore',num2str(j),'.png']);
end
% figure; set(gcf,'Position',[0 0 600 450]);
% subplot(221); histogram(score_array,-1:0.1:2); xlabel('score'); title('all');
% subplot(222); hold on; histogram(score_array(deriv_array==1),-1:0.1:2); histogram(score_array(deriv_array~=1),-1:0.1:2); title('with & without max'); xlabel('score');
% subplot(223); hold on; histogram(rad_array(deriv_array==1),0:5:100);histogram(rad_array(deriv_array~=1),0:5:100); ylabel('spacing'); title('all');
% subplot(224); hold on; histogram(rad_array(score_array>0.1),0:5:100); ylabel('spacing'); title('score > 0.1');
% saveas(gcf,[figpath,'gridscore_stat.png']);
% save(['run_gridness_dp',num2str(dp),'.mat'],'score_array','rad_array','frad_array','deriv_array');