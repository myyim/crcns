close all; clear all;
norm = 2; % 0: no normalization; 1: overall peak; 2: peak within donut
r = 150;
sd_range = 0.05; % max spatial frequency in PSD
%rmesh = -2*lmesh:2*lmesh;
[ycoor,xcoor] = meshgrid(-r:r,-r:r);
load('./ac_struct.mat');
% animal
a = 1;
if a == 1
    idx = [1:5,7:19];  % animal 1 
elseif a == 2
    idx = [20:26,28:35]; % animal 2
end

figpath = './figures/Jacob_Sargolini_across_cells/';
if ~exist(figpath)
    mkdir(figpath);
end
addpath(figpath);

figure(1); set(gcf,'Position',[0 0 1100 600]);
figure(2); set(gcf,'Position',[0 0 1100 600]);
figure(3); set(gcf,'Position',[0 0 1100 600]);
figure(4); set(gcf,'Position',[0 0 1100 600]);
figure(5); set(gcf,'Position',[0 0 1100 600]);
aE0 = zeros(2*r+1,2*r+1); aE30 = zeros(2*r+1,2*r+1); aE60 = zeros(2*r+1,2*r+1); 
aE90 = zeros(2*r+1,2*r+1); aE120 = zeros(2*r+1,2*r+1); aE150 = zeros(2*r+1,2*r+1);
a1_gscores = [];
for e = 1:3 % environment
    a0 = zeros(2*r+1,2*r+1); a30 = zeros(2*r+1,2*r+1); a60 = zeros(2*r+1,2*r+1); 
    a90 = zeros(2*r+1,2*r+1); a120 = zeros(2*r+1,2*r+1); a150 = zeros(2*r+1,2*r+1);
    for i = 1:size(idx,2)    % cell ID
        ac0 = ac_A(a).E(e).GC(idx(i)).ac;
        [ac30,ac60,ac90,ac120,ac150,~,~] = gridscore_interp2(ac0);
        for k = 0:5 % rotation out of 6            
            %eval(['ac = ac_A(a).E(e).GC(idx(i)).R',num2str(k*30),';']);
            %eval(['ac = f.ac.A',num2str(a),'.E',num2str(e),'(idx(i)).R',num2str(k*30),';']);
            eval(['ac = ac',num2str(k*30),';']); 
            s = size(ac,1); 
            if s < 2*r+1    % zero-padding when size of ac is smaller than r
                temp = zeros(2*r+1,2*r+1);
                temp((2*r+1-s)/2+1:2*r+1-(2*r+1-s)/2,(2*r+1-s)/2+1:2*r+1-(2*r+1-s)/2) = ac;
                ac = temp;
            else
                ac = ac((s+1)/2-r:(s+1)/2+r,(s+1)/2-r:(s+1)/2+r);   % reshape ac
            end
            eval(['t',num2str(k*30),'= ac;']);
        end
        [rad,frad,~,deriv] = max_activity_ring(t0);
        [score,~] = gridness(t0,t30,t60,t90,t120,t150,rad,frad);
        ori = gridorientation(t0,rad,frad);
        acplot = t0; 
        ringplot = t0; ringplot(xcoor.^2+ycoor.^2<frad^2) = 0; ringplot(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0; % extract the ring
        if norm == 0
            acmax = 1;
        elseif norm == 1
            acmax = max(max(acplot));
        elseif norm == 2
            acmax = max(max(ringplot));
        end
        if acmax ~= 0
            acplot = acplot/acmax; ringplot = ringplot/acmax;
            for k = 0:5
              eval(['a',num2str(k*30),' = a',num2str(k*30),' + t',num2str(k*30),'/acmax;']);
            end 
        end       
        figure(e); subplot(4,5,i); hold on;
        imagesc_env(acplot,-r:r,-r:r); axis image; colormap(jet(256)); colorbar; caxis([0 max(max(ringplot))]); 
        title([num2str(deriv),': \color{blue}',num2str(frad),'; \color{red}',num2str(rad),'\color{black}; ',num2str(round(ori)),'^{\circ}; g:',num2str(score,2)]);
        plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
        plot(frad*cos(0:0.01:2*pi+0.01),frad*sin(0:0.01:2*pi+0.01),'w');
        plot((2*rad-frad)*cos(0:0.01:2*pi+0.01),(2*rad-frad)*sin(0:0.01:2*pi+0.01),'w');
    end
    sgtitle(['Animal ',num2str(a),'; Environment ',num2str(e)]);
    if e >= 2
        [rad,frad,a0r,deriv] = max_activity_ring(a0,30,90);
    else
        [rad,frad,a0r,deriv] = max_activity_ring(a0);
    end    
    [score,cor] = gridness(a0,a30,a60,a90,a120,a150,rad,frad);
    ori = gridorientation(a0,rad,frad);
    if e == 1
        a1_ac1 = a0;
    elseif e == 2
        a1_ac2 = a0;
    elseif e == 3
        a1_ac3 = a0;
    end
    a1_gscores = [a1_gscores; score];
        
    % combine E2 & E3
    if e == 2 || e == 3
        for k = 0:5 % rotation out of 6
            eval(['aE',num2str(k*30),' = aE',num2str(k*30),' + a',num2str(k*30),';']);
        end
    end
    a0psd = ac2psd(a0); a30psd = ac2psd(a30); a60psd = ac2psd(a60); a90psd = ac2psd(a90); a120psd = ac2psd(a120); a150psd = ac2psd(a150); 
    figure(4); subplot(4,4,4*(e-1)+1); hold on; 
    plot([0,r],[0,0],'k:'); plot(a0r,'k');
    plot(rad*ones(1,2),[0,a0r(rad)],'r'); plot(frad*ones(1,2),[0,a0r(frad)],'b');
    xlabel('radius'); ylabel('mean autocorr'); xlim([0 r]); ylim([0 2*a0r(rad)]);
    title([num2str(deriv),': \color{blue}',num2str(frad),'; \color{red}',num2str(rad),'\color{black}; ',num2str(round(ori)),'^{\circ}']);
    subplot(4,4,4*(e-1)+2); hold on;
    imagesc_env(a0,-r:r,-r:r); axis image; colormap(jet(256)); colorbar; 
    a0(xcoor.^2+ycoor.^2<frad^2) = 0; a0(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0; % extract the ring
    caxis([0 max(max(a0))]); title(['autocorr in E',num2str(e)]);
    plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
    plot(frad*cos(0:0.01:2*pi+0.01),frad*sin(0:0.01:2*pi+0.01),'w');
    plot((2*rad-frad)*cos(0:0.01:2*pi+0.01),(2*rad-frad)*sin(0:0.01:2*pi+0.01),'w');
    subplot(4,4,4*(e-1)+3); hold on;    
    imagesc_env(a0,-r:r,-r:r); axis image; colormap(jet(256)); colorbar; 
    caxis([0 max(max(a0))]); title(['autocorr in E',num2str(e)]);
    plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
    plot(frad*cos(0:0.01:2*pi+0.01),frad*sin(0:0.01:2*pi+0.01),'w');
    plot((2*rad-frad)*cos(0:0.01:2*pi+0.01),(2*rad-frad)*sin(0:0.01:2*pi+0.01),'w');
    subplot(4,4,4*e); hold on;
    plot(0:30:150,cor,'ko-'); title(['gridness = ',num2str(score)]);
    % psd
    [rad,frad,~,~,a0r] = max_activity_ring_psd(a0psd);
    ori = gridorientation(a0psd,rad,frad);
    [score,cor] = gridness(a0psd,a30psd,a60psd,a90psd,a120psd,a150psd,rad,frad);
    figure(5); subplot(3,4,4*(e-1)+1); hold on;
    plot([0,r],[0,0],'k:'); plot(a0r,'k');
    plot(rad*ones(1,2),[0,a0r(rad)],'r'); plot(frad*ones(1,2),[0,a0r(frad)],'b');
    xlabel('radius'); ylabel('mean PSD'); xlim([0 r]); 
    title([num2str(deriv),': \color{blue}',num2str(frad),'; \color{red}',num2str(rad),'\color{black}; ',num2str(round(ori)),'^{\circ}']);
    subplot(3,4,4*(e-1)+2); hold on;
    imagesc_env(a0psd,(-r:r)/(2*r),(-r:r)/(2*r));
    axis image; colormap(jet(256)); xlim([-sd_range,sd_range]); ylim([-sd_range,sd_range]);    
    a0psd(xcoor.^2+ycoor.^2<frad^2) = 0; a0psd(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0; % extract the ring
    caxis([0 max(max(a0psd))]); title(['PSD in E',num2str(e)]);
    plot(rad*cos(0:0.01:2*pi+0.01)/(2*r),rad*sin(0:0.01:2*pi+0.01)/(2*r),'w');
    plot(frad*cos(0:0.01:2*pi+0.01)/(2*r),frad*sin(0:0.01:2*pi+0.01)/(2*r),'w');
    plot((2*rad-frad)*cos(0:0.01:2*pi+0.01)/(2*r),(2*rad-frad)*sin(0:0.01:2*pi+0.01)/(2*r),'w');
    subplot(3,4,4*(e-1)+3); hold on;    
    imagesc_env(a0psd,(-r:r)/(2*r),(-r:r)/(2*r)); 
    axis image; colormap(jet(256)); colorbar; xlim([-sd_range,sd_range]); ylim([-sd_range,sd_range]);
    caxis([0 max(max(a0psd))]); title(['PSD in E',num2str(e)]);
    plot(rad*cos(0:0.01:2*pi+0.01)/(2*r),rad*sin(0:0.01:2*pi+0.01)/(2*r),'w');
    plot(frad*cos(0:0.01:2*pi+0.01)/(2*r),frad*sin(0:0.01:2*pi+0.01)/(2*r),'w');
    plot((2*rad-frad)*cos(0:0.01:2*pi+0.01)/(2*r),(2*rad-frad)*sin(0:0.01:2*pi+0.01)/(2*r),'w');
    subplot(3,4,4*e); hold on;
    plot(0:30:150,cor,'ko-'); title(['gridness = ',num2str(score)]);
end

[rad,frad,ac0r,deriv] = max_activity_ring(aE0,30,90);
[score,cor] = gridness(aE0,aE30,aE60,aE90,aE120,aE150,rad,frad);
ori = gridorientation(aE0,rad,frad);
a1_ac4 = aE0;
a1_gscores = [a1_gscores; score];
figure(4); subplot(4,4,13); hold on; 
plot([0,r],[0,0],'k:'); plot(ac0r,'k');
plot(rad*ones(1,2),[0,ac0r(rad)],'r'); plot(frad*ones(1,2),[0,ac0r(frad)],'b');
xlabel('radius'); ylabel('mean autocorr'); xlim([0 r]); ylim([0 2*ac0r(rad)]);
title([num2str(deriv),': \color{blue}',num2str(frad),'; \color{red}',num2str(rad),'\color{black}; ',num2str(round(ori)),'^{\circ}']);
subplot(4,4,14); hold on;
imagesc_env(aE0,-r:r,-r:r); axis image; colormap(jet(256)); colorbar; 
aE0(xcoor.^2+ycoor.^2<frad^2) = 0; aE0(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0;
caxis([0 max(max(aE0))]); title(['autocorr in E2 & 3']);
plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
plot(frad*cos(0:0.01:2*pi+0.01),frad*sin(0:0.01:2*pi+0.01),'w');
plot((2*rad-frad)*cos(0:0.01:2*pi+0.01),(2*rad-frad)*sin(0:0.01:2*pi+0.01),'w');
subplot(4,4,15); hold on;
imagesc_env(aE0,-r:r,-r:r); axis image; colormap(jet(256)); colorbar; 
caxis([0 max(max(aE0))]); title(['autocorr in E2 & 3']);
plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
plot(frad*cos(0:0.01:2*pi+0.01),frad*sin(0:0.01:2*pi+0.01),'w');
plot((2*rad-frad)*cos(0:0.01:2*pi+0.01),(2*rad-frad)*sin(0:0.01:2*pi+0.01),'w');
subplot(4,4,16); hold on;
plot(0:30:150,cor,'ko-'); title(['gridness = ',num2str(score)]);
save(['a',num2str(a),'_summary_ac.mat'],'a1_ac1','a1_ac2','a1_ac3','a1_ac4');
save(['a',num2str(a),'_gscores.mat'],'a1_gscores');
% saveas(1,[figpath,'gridness_a',num2str(a),'e1norm',num2str(norm),'.png']);
% saveas(2,[figpath,'gridness_a',num2str(a),'e2norm',num2str(norm),'.png']);
% saveas(3,[figpath,'gridness_a',num2str(a),'e3norm',num2str(norm),'.png']);
% saveas(4,[figpath,'gridness_a',num2str(a),'allnorm',num2str(norm),'.png']);
% saveas(5,[figpath,'psdgridness_a',num2str(a),'allnorm',num2str(norm),'.png']);
