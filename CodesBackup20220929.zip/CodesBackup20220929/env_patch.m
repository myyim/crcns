function env_patch(env)

rad = 75; N = 120; ang = pi/7; theta = linspace(ang,2*pi+ang,N+1);
theta(end) = []; ids = (1:N/2)'; faces = [ids, ids+1, N-ids, N-ids+1];
if env < 3
    c = exp(-0.05*cos(ang-theta))';
else
    c = exp(-cos(ang-theta))';
end
c = 0.8*[c c c]/max(c);
%patch('Faces', faces, 'Vertices',[rad*cos(theta);rad*sin(theta)]','FaceVertexCData',c,'FaceColor', 'interp', 'EdgeColor', 'none');
patch('Faces', faces, 'Vertices',[rad*cos(theta);rad*sin(theta)]','FaceVertexCData',c,'FaceColor', 'interp', 'EdgeColor', 'none');

if env >= 2 % track
    c = ones(N,3); % the inner white circle
    patch('Faces', faces, 'Vertices',[0.8*rad*cos(theta);0.8*rad*sin(theta)]','FaceVertexCData',c,'FaceColor', 'interp','EdgeColor', 'none');    
end

axis equal;