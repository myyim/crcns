function sd = ac2psd1d(ac)
% zero-padding
x = [0,ac];
sd = abs(fft(x));
% sd = [sd0(size(ac,2)+1:end),sd0(1:size(ac,2))];
end