cscale = 0.5;
figpath = './figures/Jacob_Sargolini_shuffled/';
addpath(figpath);
s = 1;
load('lowthreshold.mat');

% figure(1); hold on;
% for j = 1:3
%     plot(lowthreshold(:,j),'.');
% end
% legend('E1','E2','E3'); legend('Location','northwest'); xlabel('cell ID'); ylabel('threshold');
% saveas(1,'lowthreshold.png'); close all;

load(['ac_struct_s',num2str(s),'.mat']);
for dp = 1:3
    figure(1+dp); set(gcf,'Position',[0 0 1000 1200]);
    for j = 1:19
        subplot(4,5,j); hold on; axis image;
        rmap = rmap_A(1).E(dp).GC(j).rmap;
        r = (size(rmap,2)-1)/2; imagesc_env(rmap',-r:r,-r:r); 
        colorbar; colormap(jet(256)); caxis([0 cscale*max(rmap,[],'all')]);
        set(gca,'color',[1 1 1]); set(gca,'YDir','normal'); title(num2str(lowthreshold(j,dp)));
    end
    saveas(1+dp,[figpath,'verify_ac_A1_E',num2str(dp),'_s',num2str(s),'.png']);
end

for dp = 1:3
    figure(4+dp); set(gcf,'Position',[0 0 1000 1200]);
    for j = 20:35
        subplot(4,5,j-19); hold on; axis image;
        rmap = rmap_A(2).E(dp).GC(j).rmap;
        r = (size(rmap,2)-1)/2; imagesc_env(rmap',-r:r,-r:r); 
        colorbar; colormap(jet(256)); caxis([0 cscale*max(rmap,[],'all')]);
        set(gca,'color',[1 1 1]); set(gca,'YDir','normal'); title(num2str(lowthreshold(j,dp)));
    end
    saveas(4+dp,[figpath,'verify_ac_A2_E',num2str(dp),'_s',num2str(s),'.png']);
end