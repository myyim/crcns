function [score,cor] = gridness(ac0,ac30,ac60,ac90,ac120,ac150,rad,frad)
[xm,ym] = size(ac0); xm = (xm-1)/2; ym = (ym-1)/2;
[ycoor,xcoor] = meshgrid(-ym:ym,-xm:xm); % coordinates of the grid, y by x
cor = ones(1,6);
ac0_vec = ac0(logical((xcoor.^2+ycoor.^2>=frad^2).*(xcoor.^2+ycoor.^2<=(2*rad-frad)^2)));
for j = 2:6
    ac_vec = eval(['ac',num2str(30*(j-1))]);
    ac_vec = ac_vec(logical((xcoor.^2+ycoor.^2>=frad^2).*(xcoor.^2+ycoor.^2<=(2*rad-frad)^2)));
    xcor = corrcoef(ac0_vec,ac_vec);
    cor(j) = xcor(1,2);
end
score = min(cor(3:2:5))-max(cor(2:2:6));