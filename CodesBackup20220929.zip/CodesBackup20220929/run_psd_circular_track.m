clear all; close all;
figpath = './figures/psd_circular/';
if ~exist(figpath, 'dir')
    mkdir(figpath);
end
%addpath('../Knierim_Data');
addpath('./oldcode');
%% parameters
lam = 31; % period
psi = 0.31;    % orientation
c = [12,21];  % center related to phase
r = 75*2;    % radius of circular track
thre = 0.2;   % threshold for grid cell activity
trackw = 10; % width of the track
fpk = 1;    % peak rate
sd_range = 0.05; % max spatial frequency in PSD
lmesh = 90*2;%2*r;    % size of environment containing the track is 2*lmesh+1
t = 0:1/r:2*pi; % parameter
N = 20; % number of neurons in combined responses
x0 = -lmesh:lmesh;
y0 = -lmesh:lmesh;
x1 = -2*lmesh:2*lmesh;
y1 = -2*lmesh:2*lmesh;
[xm,ym] = meshgrid(x0,y0);
%x = r*cos(t);
%y = r*sin(t);
%orange = [0.8500, 0.3250, 0.0980];
%green = [0,0.5,0];

%% define grid cells
g2d = gridcell(xm,ym,fpk,lam,psi,c,thre);
gcir = g2d;    % circular track in 2D
gcir(abs(sqrt(xm.^2+ym.^2)-r)>trackw/2) = 0;

%% 2D grid
figure;
set(gcf,'Position',[0 0 800 650]);
subplot(451);
imagesc(x0,y0,gcir); axis image; colormap(jet(256)); caxis([0 1]);
title('grid cell');
ylabel('2D');
subplot(456);
gcir_xcor = xcorr2(gcir);
gcir_psdac = ac2psd(gcir_xcor);
imagesc(x0,y0,gcir_xcor); axis image; colormap(jet(256));
ylabel('autocorr');
subplot(4,5,11);
imagesc(x1/(4*lmesh),y1/(4*lmesh),gcir_psdac); axis image; colormap(jet(256)); xlim([-sd_range,sd_range]); ylim([-sd_range,sd_range]);
ylabel('PSD via corr');
subplot(4,5,16);
imagesc(x1/(4*lmesh),y1/(4*lmesh),psd2d(gcir)); axis image; colormap(jet(256)); xlim([-sd_range,sd_range]); ylim([-sd_range,sd_range]);
ylabel('PSD');

%% circle on
gcir = zeros(size(gcir));
gcir(abs(sqrt(xm.^2+ym.^2)-r)<=trackw/2) = 1;
subplot(452);
imagesc(x0,y0,gcir); axis image; colormap(jet(256)); caxis([0 1]);
title('track on');
subplot(457);
gcir_xcor = xcorr2(gcir);
gcir_psdac = ac2psd(gcir_xcor);
imagesc(x0,y0,gcir_xcor); axis image; colormap(jet(256));
subplot(4,5,12);
imagesc(x1/(4*lmesh),y1/(4*lmesh),gcir_psdac); axis image; colormap(jet(256)); xlim([-sd_range,sd_range]); ylim([-sd_range,sd_range]);
subplot(4,5,17);
imagesc(x1/(4*lmesh),y1/(4*lmesh),psd2d(gcir)); axis image; colormap(jet(256)); xlim([-sd_range,sd_range]); ylim([-sd_range,sd_range]);

%% circle off
gcir = ones(size(gcir));
gcir(abs(sqrt(xm.^2+ym.^2)-r)<=trackw/2) = 0;
subplot(453);
imagesc(x0,y0,gcir); axis image; colormap(jet(256)); caxis([0 1]);
title('track off');
subplot(458);
gcir_xcor = xcorr2(gcir);
gcir_psdac = ac2psd(gcir_xcor);
imagesc(x0,y0,gcir_xcor); axis image; colormap(jet(256));
subplot(4,5,13);
imagesc(x1/(4*lmesh),y1/(4*lmesh),gcir_psdac); axis image; colormap(jet(256)); xlim([-sd_range,sd_range]); ylim([-sd_range,sd_range]);
subplot(4,5,18);
imagesc(x1/(4*lmesh),y1/(4*lmesh),psd2d(gcir)); axis image; colormap(jet(256)); xlim([-sd_range,sd_range]); ylim([-sd_range,sd_range]);

%% thin circle track
gcir = zeros(size(gcir));
gcir(abs(sqrt(xm.^2+ym.^2)-r)<=1) = 1;
subplot(454);
imagesc(x0,y0,gcir); axis image; colormap(jet(256)); caxis([0 1]);
title('thin circle');
subplot(459);
gcir_xcor = xcorr2(gcir);
gcir_psdac = ac2psd(gcir_xcor);
imagesc(x0,y0,gcir_xcor); axis image; colormap(jet(256));
subplot(4,5,14);
imagesc(x1/(4*lmesh),y1/(4*lmesh),gcir_psdac); axis image; colormap(jet(256)); xlim([-sd_range,sd_range]); ylim([-sd_range,sd_range]);
subplot(4,5,19);
imagesc(x1/(4*lmesh),y1/(4*lmesh),psd2d(gcir)); axis image; colormap(jet(256)); xlim([-sd_range,sd_range]); ylim([-sd_range,sd_range]);

%% small circle
gcir = zeros(size(gcir));
gcir(abs(sqrt(xm.^2+ym.^2)-r/2)<=trackw/2) = 1;
subplot(455);
imagesc(x0,y0,gcir); axis image; colormap(jet(256)); caxis([0 1]);
title('small circle');
subplot(4,5,10);
gcir_xcor = xcorr2(gcir);
gcir_psdac = ac2psd(gcir_xcor);
imagesc(x0,y0,gcir_xcor); axis image; colormap(jet(256));
subplot(4,5,15);
imagesc(x1/(4*lmesh),y1/(4*lmesh),gcir_psdac); axis image; colormap(jet(256)); xlim([-sd_range,sd_range]); ylim([-sd_range,sd_range]);
subplot(4,5,20);
imagesc(x1/(4*lmesh),y1/(4*lmesh),psd2d(gcir)); axis image; colormap(jet(256)); xlim([-sd_range,sd_range]); ylim([-sd_range,sd_range]);


%% save figure
if 0
    set(gcf,'Units','Inches');
    pos = get(gcf,'Position');
    set(gcf,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)]);
    print(gcf,[figpath,'run_psd_circular_track2'],'-dpdf','-r0');
end
