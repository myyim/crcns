close all; clear all;

%% parameters
rm = 75; % outer radius
rmin = 60; % inner radius
rad = (rm+rmin)/2; % center radius
lam = 65;   % grid spacing
psi = 0.26; % grid orientation
rng(1); clist = randi(lam,[18,2]);  % grid center of 20 cells
c1 = [8,23]; % grid center
c2 = [3,7]; % grid center
thre = 0.2;   % for bump detection
cscale = 0.6-0.25; cscale2 = 0.2-0.12; % fraction of max as the upper limit of colorbar
[y,x] = meshgrid(-rm:rm,-rm:rm);    % coordinates of arena/track
mask = ones(2*rm+1,2*rm+1); mask(x.^2+y.^2<rmin^2) = 0; mask(x.^2+y.^2>rm^2) = 0; % for the track
lam_std = 5; psi_std = 3*pi/180; % use a bit bigger values than inferred from figures 1-2 
% in Stensola et al (2012), which are 3.5cm and 2 deg
plist = randn(20,2); 
% here we show the most extreme example
[~,idx] = max(plist(:,1).^2 + plist(:,2).^2);
temp = plist(1,:); plist(1,:) = plist(idx,:); plist(idx,:) = temp;
plist(:,1) = lam_std*plist(:,1); plist(:,2) = psi_std*plist(:,2);

%% codes needed
codepath = './codes/'; % update your path here!
allpath = genpath(codepath); addpath(allpath);
% env_patch, model_rmap_ac, imagesc_env, model_shuffled_rmap_ac,
% shuffled_identical_circular_fields, gridcell

%% Figure: First column
figure; set(gcf,'Position',[0 0 900 700]);
subplot(461);[rmap,ac] = model_rmap_ac(y,x,lam,psi,c1,0,rm); imagesc_env(rmap,-rm:rm,-rm:rm,2); title('Rate Map');
subplot(462); imagesc_env(ac,-2*rm:2*rm,-2*rm:2*rm); colormap(jet(256)); title('Autocorrelation');
caxis([0 max(max(ac))*cscale]); %xlim([-rm rm]); ylim([-rm rm]);
subplot(467); rmap(x.^2+y.^2<rmin^2) = 0; imagesc_env(rmap,-rm:rm,-rm:rm,2);
subplot(468); ac = xcorr2(rmap); imagesc_env(ac,-2*rm:2*rm,-2*rm:2*rm); 
caxis([0 max(max(ac))*cscale]); acsum = ac;
subplot(4,6,13); [rmap,~] = model_rmap_ac(y,x,lam,psi,c2,0,rm); 
rmap(x.^2+y.^2<rmin^2) = 0; imagesc_env(rmap,-rm:rm,-rm:rm,2);
subplot(4,6,14); ac = xcorr2(rmap); imagesc_env(ac,-2*rm:2*rm,-2*rm:2*rm); 
caxis([0 max(max(ac))*cscale]); acsum = acsum + ac;
for j = 3:20
    [rmap,~] = model_rmap_ac(y,x,lam,psi,clist(j-2,:),0,rm); rmap(x.^2+y.^2<rmin^2) = 0; 
    ac = xcorr2(rmap); acsum = acsum + ac;
end
subplot(4,6,20); imagesc_env(acsum,-2*rm:2*rm,-2*rm:2*rm);
caxis([0 max(max(acsum))*cscale2]); xlabel('lag (cm)'); %title('pop. autocorrelation');

%% Middle column
rm = 75-4; % outer radius
rmin = 60+4; % inner radius
lam = 45;   % grid spacing
subplot(463);[rmap,ac] = model_rmap_ac(y,x,lam,psi,c1,0,rm); imagesc_env(rmap,-rm:rm,-rm:rm,2); title('Rate Map');
subplot(464); imagesc_env(ac,-2*rm:2*rm,-2*rm:2*rm); colormap(jet(256)); title('Autocorrelation');
caxis([0 max(max(ac))*cscale]); %xlim([-rm rm]); ylim([-rm rm]);
subplot(469); rmap(x.^2+y.^2<rmin^2) = 0; imagesc_env(rmap,-rm:rm,-rm:rm,2);
subplot(4,6,10); ac = xcorr2(rmap); imagesc_env(ac,-2*rm:2*rm,-2*rm:2*rm); 
caxis([0 max(max(ac))*cscale]); acsum = ac;
subplot(4,6,15); [rmap,~] = model_rmap_ac(y,x,lam,psi,c2,0,rm); 
rmap(x.^2+y.^2<rmin^2) = 0; imagesc_env(rmap,-rm:rm,-rm:rm,2);
subplot(4,6,16); ac = xcorr2(rmap); imagesc_env(ac,-2*rm:2*rm,-2*rm:2*rm); 
caxis([0 max(max(ac))*cscale]); acsum = acsum + ac;
for j = 3:20
    [rmap,~] = model_rmap_ac(y,x,lam,psi,clist(j-2,:),0,rm); rmap(x.^2+y.^2<rmin^2) = 0; 
    ac = xcorr2(rmap); acsum = acsum + ac;
end
subplot(4,6,22); imagesc_env(acsum,-2*rm:2*rm,-2*rm:2*rm);
caxis([0 max(max(acsum))*cscale2]); xlabel('lag (cm)'); %title('pop. autocorrelation'); 

%% Last column
% rm = 75; % outer radius
% rmin = 60; % inner radius
subplot(465);[rmap,ac] = model_rmap_ac(y,x,lam+plist(1,1),psi+plist(1,2),c1,0,rm); imagesc_env(rmap,-rm:rm,-rm:rm,2); title('Rate Map');
subplot(466); imagesc_env(ac,-2*rm:2*rm,-2*rm:2*rm); colormap(jet(256)); title('Autocorrelation'); caxis([0 max(max(ac))*cscale]);
subplot(4,6,11); rmap(x.^2+y.^2<rmin^2) = 0; imagesc_env(rmap,-rm:rm,-rm:rm,2);
subplot(4,6,12); ac = xcorr2(rmap); imagesc_env(ac,-2*rm:2*rm,-2*rm:2*rm); 
caxis([0 max(max(ac))*cscale]); acsum = ac;
subplot(4,6,17); [rmap,~] = model_rmap_ac(y,x,lam+plist(2,1),psi+plist(2,2),c2,0,rm); 
rmap(x.^2+y.^2<rmin^2) = 0; imagesc_env(rmap,-rm:rm,-rm:rm,2);
subplot(4,6,18); ac = xcorr2(rmap); imagesc_env(ac,-2*rm:2*rm,-2*rm:2*rm); 
caxis([0 max(max(ac))*cscale]); acsum = acsum + ac;
for j = 3:20
    [rmap,~] = model_rmap_ac(y,x,lam+plist(j,1),psi+plist(j,2),clist(j-2,:),0,rm); rmap(x.^2+y.^2<rmin^2) = 0; 
    ac = xcorr2(rmap); acsum = acsum + ac;
end
subplot(4,6,24); imagesc_env(acsum,-2*rm:2*rm,-2*rm:2*rm);
caxis([0 max(max(acsum))*cscale2]); xlabel('lag (cm)'); %title('pop. autocorrelation');

set(findall(gcf,'-property','FontSize'),'FontSize',10);
set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,...
    'PaperPosition',[0 0 screenposition(3:4)],...
    'PaperSize',[screenposition(3:4)]);
print -dpdf fig2_simulation