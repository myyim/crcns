close all; clear all;

%% parameters
norm = 2; % 0: no normalization; 1: overall peak; 2: peak within donut
r = 150;
halfw = 5;
[ycoor,xcoor] = meshgrid(-r:r,-r:r);
an = {'MEC2','MEC1','MEC3','MEC4','1RS_','2BS_'};
sig = 3;
cscale = 0.2; cscale2 =0.1;
load('./ac_struct.mat');

%% codes needed
codepath = './codes/'; % update your path here!
allpath = genpath(codepath); addpath(allpath);
load('./CellsID.mat');
load('./fitcirculartrack.mat');

%% figure
datapath = './Jacob_Sargolini_All_Environments/'; % update your path here!
allpath = genpath(datapath); addpath(allpath);
codepath = './codes/'; % update your path here!
allpath = genpath(codepath); addpath(allpath);
datapath = './data/'; % update your path here!
allpath = genpath(datapath); addpath(allpath);

a = 2;
if a == 1
    idx = [1:5,7:19];  % animal 1 
    idx_rob = [15,9,17]; % cells with the highest gridness to be removed 1 by 1
elseif a == 2
    %idx = [20:26,28:35]; % animal 2
    idx = [20,22:26,30,33,34]; idx_rob = [22,33];
%     idx = [21,29,31,32,35]; idx_rob = [31,29];
end

figure(1); set(gcf,'Position',[0 0 1000 1200]);
load('ac_struct.mat');

for nleave = 1:3
    if nleave == 1
        leaveout = [];
    elseif nleave == 2
        leaveout = [idx_rob(1)];
    elseif nleave == 3
        leaveout = idx_rob(1:2);
    end
    aE0 = zeros(2*r+1,2*r+1);
    for e = 1:3 % environment
        a0 = zeros(2*r+1,2*r+1);
        for i = 1:size(idx,2)    % cell ID
            if any(idx(i)==leaveout)
                continue
            end
            ac = ac_A(a).E(e).GC(idx(i)).ac;
            s = size(ac,1); 
            if s < 2*r+1    % zero-padding when size of ac is smaller than r
                temp = zeros(2*r+1,2*r+1);
                temp((2*r+1-s)/2+1:2*r+1-(2*r+1-s)/2,(2*r+1-s)/2+1:2*r+1-(2*r+1-s)/2) = ac;
                ac = temp;
            else
                ac = ac((s+1)/2-r:(s+1)/2+r,(s+1)/2-r:(s+1)/2+r);   % reshape ac
            end
            [rad,frad,ac0r,deriv] = max_activity_ring(ac,30);
            [oris,xs,ys] = grid3orientations(ac,rad,rad-halfw);
            if a == 2 && e == 1 && (idx(i) == 21 || idx(i) == 34)
                [rad,frad,ac0r,deriv] = max_activity_ring(ac,40);
            end
            if a == 1 && e == 1 && idx(i) == 18
                rad = 48;
            end
            if a == 2 && e == 1 && (idx(i) == 29 || idx(i) == 32)
                rad = 60;
            end
            if norm == 0
                acmax = 1;
            elseif norm == 1
                acmax = max(max(ac));
            elseif norm == 2
                ringplot = ac; ringplot(xcoor.^2+ycoor.^2<frad^2) = 0; ringplot(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0; % extract the ring
                acmax = max(max(ringplot));
            end
            if acmax ~= 0
                a0 = a0 + ac/acmax;
            end
        end
        subplot(4,4,4*(e-1)+nleave); hold on;
        ringplot = a0; ringplot(xcoor.^2+ycoor.^2<frad^2) = 0; ringplot(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0; % extract the ring
        a0max = max(max(ringplot));
        [rad,frad,~,~] = max_activity_ring(a0,40);
        [~,~,~,~,~,score,~] = gridscore_interp2(a0,rad,frad);
        imagesc_env(a0/a0max,-r:r,-r:r); %plot(xs,ys,'w+','MarkerSize',8);
%         plot((rad-halfw)*cos(0:0.01:2*pi+0.01),(rad-halfw)*sin(0:0.01:2*pi+0.01),'w');
%         plot((rad+halfw)*cos(0:0.01:2*pi+0.01),(rad+halfw)*sin(0:0.01:2*pi+0.01),'w');
%         titlestring = [num2str(rad),'; ',num2str(round(mean(sqrt(xs.^2+ys.^2)))),'; ']; 
%         for j = 1:size(oris,2)
%             titlestring = [titlestring,num2str(oris(j)),'^{\circ} ']; 
%         end
%         title(titlestring); colorbar; 
        gridstring = eval(['"gridness: ',num2str(score,2),'";']);
        if e == 1
            cellstring = eval(['"',num2str(size(idx,2)-size(leaveout,2)),' cells";']);
            title([cellstring,gridstring]);
        else
            title(gridstring);
        end
        axis image; colormap(jet(256)); caxis([0 1]); 
        % combine E2 & E3
        if e == 2 || e == 3
            aE0 = aE0 + a0;
        end
    end
    [rad,frad,~,~] = max_activity_ring(aE0,40);
    [~,~,~,~,~,score,~] = gridscore_interp2(aE0,rad,frad);
    subplot(4,4,4*(4-1)+nleave); hold on;
    ringplot = aE0; ringplot(xcoor.^2+ycoor.^2<frad^2) = 0; ringplot(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0; % extract the ring
    aE0max = max(max(ringplot));
    imagesc_env(aE0/aE0max,-r:r,-r:r); %plot(xs,ys,'w+','MarkerSize',8);
%     plot((rad-halfw)*cos(0:0.01:2*pi+0.01),(rad-halfw)*sin(0:0.01:2*pi+0.01),'w');
%     plot((rad+halfw)*cos(0:0.01:2*pi+0.01),(rad+halfw)*sin(0:0.01:2*pi+0.01),'w');
%   colorbar; 
    title(['gridness: ',num2str(score,2)]); axis image; colormap(jet(256)); caxis([0 1]); 
end

set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,...
    'PaperPosition',[0 0 screenposition(3:4)],...
    'PaperSize',[screenposition(3:4)]);
print -dpdf supp_robustness_rat2_mod1