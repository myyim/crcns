function [trackpos,trackf,ts] = getlinearized_sargolini(fname,tID,cID,pfit)

%% default
if nargin < 3
    error('fname,tID,cID are required!');
elseif nargin < 4
    error('pfit is required!');  
end
rad = 75-15/2;  % center radius of the track

%% get data
load(fname);
ts = PosMtx(:,1);
trackpos = PosMtx(:,2:3); %;Pos(:,4)];  Both Tetrodes
fT = TTMtx(logical((TTMtx(:,2)==tID).*(TTMtx(:,3)==cID)),1);  % Timestamps of firing data with tetrode and cell ID
if sum(logical((fT<ts(1))+(fT>ts(end))))
    disp([fname,' ',num2str(ts(1)),'-',num2str(ts(end)),': ']);
    disp(num2str(fT(logical((fT<ts(1))+(fT>ts(end))))));
end
fT = fT(logical((fT>=ts(1)).*(fT<=ts(end))));   % discard spikes before and after the session

% centering
trackpos = trackpos-[pfit(1),pfit(2)]; 

% linearized
trackpos = mod(atan2(trackpos(:,2),trackpos(:,1)),2*pi);    % atan(Y,X)
dx = trackpos(2:end)-trackpos(1:end-1);     % difference
id_forw = find(dx<-pi);
id_back = find(dx>pi);
for j = id_forw'
    trackpos(j+1:end) = trackpos(j+1:end) + 2*pi;
end
for j = id_back'
    trackpos(j+1:end) = trackpos(j+1:end) - 2*pi;
end

trackf = interp1(ts,trackpos,fT,'nearest'); % spike location set to be the animal location at the nearest time

% scaling
trackpos = rad*trackpos;
trackf = rad*trackf;

end