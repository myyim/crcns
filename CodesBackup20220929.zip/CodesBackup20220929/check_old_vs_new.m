id = []; fname = [];
for j = 1:64
    for k = 1:71
        if CellsID.Arena(j) == CellIDarena{k}(1:end-4) 
            break
        end
        if k == 71
            id = [id,j]; fname = [fname,CellsID.Arena(j)];
        end
    end
end

id2 = []; fname2 = [];
for k = 1:71
    for j = 1:64
        if CellsID.Arena(j) == CellIDarena{k}(1:end-4) 
            break
        end
        if j == 64
            id2 = [id2,k]; fname2 = [fname2,CellIDarena(k)];
        end
    end
end

potentialgrid_id2 = [9,10,16,21,22,27,45,61];
potentialgrid_fname_old = [];
for j = potentialgrid_id2
    idx = find(id2 == j); disp(idx);
    potentialgrid_fname_old = [potentialgrid_fname_old, fname2(idx)];
end