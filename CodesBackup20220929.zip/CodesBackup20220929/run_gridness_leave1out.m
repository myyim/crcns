close all; clear all;
norm = 2; % 0: no normalization; 1: overall peak; 2: peak within donut
r = 150;
sd_range = 0.05; % max spatial frequency in PSD
%rmesh = -2*lmesh:2*lmesh;
[ycoor,xcoor] = meshgrid(-r:r,-r:r);
f = load('./ac_struct.mat');
% animal
a = 1;
if a == 1
    idx = [1:5,7:19];  % animal 1 
elseif a == 2
    idx = [20:35]; % animal 2
end

figpath = './figures/Jacob_Sargolini_across_cells/';
if ~exist(figpath)
    mkdir(figpath);
end
addpath(figpath);

acorr = zeros(3,size(idx,2),6,2*r+1,2*r+1);   % 3 env, 18 cells, 6 rotations
acorrsum = zeros(3,6,2*r+1,2*r+1);  % sum over cells
for e = 1:3 % environment
    for i = 1:size(idx,2)    % cell ID
        for k = 0:5 % rotation out of 6
            eval(['ac = f.ac.A',num2str(a),'.E',num2str(e),'(idx(i)).R',num2str(k*30),';']);
            s = size(ac,1); 
            if s < 2*r+1    % zero-padding when size of ac is smaller than r
                temp = zeros(2*r+1,2*r+1);
                temp((2*r+1-s)/2+1:2*r+1-(2*r+1-s)/2,(2*r+1-s)/2+1:2*r+1-(2*r+1-s)/2) = ac;
                ac = temp;
            else
                ac = ac((s+1)/2-r:(s+1)/2+r,(s+1)/2-r:(s+1)/2+r);   % reshape ac
            end
            if k == 0
                if norm == 0
                    acmax = 1;
                elseif norm == 1
                    acmax = max(max(ac));
                elseif norm == 2
                    [rad,frad,~,~] = max_activity_ring(ac);
                    ringplot = ac; ringplot(xcoor.^2+ycoor.^2<frad^2) = 0; ringplot(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0; % extract the ring
                    acmax = max(max(ringplot));
                end
            end
            if acmax ~= 0
                acorr(e,i,k+1,1:end,1:end) = ac/acmax;
                acorrsum(e,k+1,1:end,1:end) = squeeze(acorrsum(e,k+1,1:end,1:end)) + ac/acmax;
            end
        end
    end
end

for i = 1:size(idx,2)    % cell ID
    figure(i); set(gcf,'Position',[0 0 1100 600]);
    for e = 1:3
        for k = 0:5
            eval(['a',num2str(k*30),' = squeeze(acorrsum(e,k+1,:,:))-squeeze(acorr(e,i,k+1,:,:));']);
        end
        if e >= 2
            [rad,frad,a0r,deriv] = max_activity_ring2(a0);
        else
            [rad,frad,a0r,deriv] = max_activity_ring(a0);
        end    
        [score,cor] = gridness(a0,a30,a60,a90,a120,a150,rad,frad);
        subplot(4,4,4*(e-1)+1); hold on; 
        plot([0,r],[0,0],'k:'); plot(a0r,'k');
        plot(rad*ones(1,2),[0,a0r(rad)],'r'); plot(frad*ones(1,2),[0,a0r(frad)],'b');
        xlabel('radius'); ylabel('mean autocorr'); xlim([0 r]); 
        if deriv == 1
            title(['1st: \color{blue}',num2str(frad),'; \color{red}',num2str(rad)]);
        else
            title(['Assigned: \color{blue}',num2str(frad),'; \color{red}',num2str(rad)]);
        end
        subplot(4,4,4*(e-1)+2); hold on;
        imagesc_env(a0,-r:r,-r:r); axis image; colormap(jet(256)); colorbar; 
        a0(xcoor.^2+ycoor.^2<frad^2) = 0; a0(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0; % extract the ring
        caxis([0 max(max(a0))]); title(['autocorr in E',num2str(e)]);
        plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
        plot(frad*cos(0:0.01:2*pi+0.01),frad*sin(0:0.01:2*pi+0.01),'w');
        plot((2*rad-frad)*cos(0:0.01:2*pi+0.01),(2*rad-frad)*sin(0:0.01:2*pi+0.01),'w');
        subplot(4,4,4*(e-1)+3); hold on;    
        imagesc_env(a0,-r:r,-r:r); axis image; colormap(jet(256)); colorbar; 
        caxis([0 max(max(a0))]); title(['autocorr in E',num2str(e)]);
        plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
        plot(frad*cos(0:0.01:2*pi+0.01),frad*sin(0:0.01:2*pi+0.01),'w');
        plot((2*rad-frad)*cos(0:0.01:2*pi+0.01),(2*rad-frad)*sin(0:0.01:2*pi+0.01),'w');
        subplot(4,4,4*e); hold on;
        plot(0:30:150,cor,'ko-'); title(['gridness = ',num2str(score)]);
        sgtitle(['No cell ',num2str(i)]);
    end
    saveas(i,[figpath,'gridness_a',num2str(a),'leave1out',num2str(i),'.png']);
end


