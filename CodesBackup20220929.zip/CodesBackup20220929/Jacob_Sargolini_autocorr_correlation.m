clear all; close all;
r = 150;

%% Which datapath?
% 1: Large Arena matlab files (all 64 cells)
% 2: Large Circular track light matlab files (all 64 cells)
% 3: Large Circular track dark matlab files (35 cells)
% 4: Small Arena matlab files (29 cells)
% 5: Small Circular track matlab files (29 cells)

%% set path and get directories
datapath = './Jacob_Sargolini_All_Environments/'; % update your path here!
allpath = genpath(datapath);
addpath(allpath);
figpath = './figures/Jacob_Sargolini_autocorr_correlation/';
if ~exist(figpath)
    mkdir(figpath);
end
addpath(figpath);
load('./CellsID.mat');
load('./fitcirculartrack.mat');
f = load('./ac_struct.mat');

% animal
a = 2;
if a == 1
    idx = [1:5,7:19];  % animal 1 (18 cells with activity)
elseif a == 2
    idx = 20:35; % animal 2
end
rad = 75-15/2; 

for j = 1:size(idx,2)
    if mod(j,4) == 1
        figure; set(gcf,'Position',[0 0 1000 750]);
    end
    for dp = 1:3
        subplot(3,4,(dp-1)*4+mod(j-1,4)+1); hold on;
        if dp == 1
            filename = 'CellsID.Arena';
            eval(['fname = ',filename,'(idx(j));']);
            if fname == ""
                continue
            end
            tID = CellsID.tetrode(idx(j));
            cID = CellsID.cell(idx(j));
            fname = char(fname);
            fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];
            [trackpos,trackf,~] = getdata_sargolini(fname,tID,cID,1,pall(idx(j),:));
            [rmap,~,~] = smoothratemap(trackpos,trackf);
            s = (size(rmap,1)-1)/2;
            [ycoor,xcoor] = meshgrid(-s:s,-s:s); % coordinates of the grid, y by x
            rmap(((xcoor.^2+ycoor.^2>(rad+15/2)^2)+(xcoor.^2+ycoor.^2<(rad-15/2)^2))>0) = 0;
            ac = xcorr2(rmap);
        else
            eval(['ac = f.ac.A',num2str(a),'.E',num2str(dp),'(idx(j)).R0;']);
        end
        s = size(ac,1); 
        if s < 2*r+1    % zero-padding when size of ac is smaller than r
            temp = zeros(2*r+1,2*r+1);
            temp((2*r+1-s)/2+1:2*r+1-(2*r+1-s)/2,(2*r+1-s)/2+1:2*r+1-(2*r+1-s)/2) = ac;
            ac = temp;
        else
            ac = ac((s+1)/2-r:(s+1)/2+r,(s+1)/2-r:(s+1)/2+r);   % reshape ac
        end
        imagesc_env(ac,-r:r,-r:r);
        axis image; colormap(jet(256)); colorbar; caxis([0 0.4*max(max(ac))]); 
        if dp == 1
            ac1 = ac;
            title(['cell ',num2str(idx(j))]);
        elseif dp == 2
            ac2 = ac;
        else
            ac3 = ac;
        end
        if mod(j,4) == 1
            ylabel(['E',num2str(dp)]);
        end
    end
    cc = corrcoef(ac1,ac2); xc(1,j) = cc(1,2);
    cc = corrcoef(ac1,ac3); xc(2,j) = cc(1,2);
    cc = corrcoef(ac2,ac3); xc(3,j) = cc(1,2);
    if mod(j,4) == 0
        saveas(gcf,[figpath,'ac_compare_a',num2str(a),'_',num2str(j/4),'.png']);
    end
end
saveas(gcf,[figpath,'ac_compare_a',num2str(a),'_',num2str(ceil(j/4)),'.png']);
close all;
figure; set(gcf,'Position',[0 0 1000 250]); hold on;
plot(xc(1,:),'o','DisplayName','E1 & E2');
plot(xc(2,:),'s','DisplayName','E1 & E3');
plot(xc(3,:),'v','DisplayName','E2 & E3');
legend; title('autocorr correlation'); xlabel('cell ID');
saveas(gcf,[figpath,'autocorr_corr_a',num2str(a),'.png']);
figure; hold on;
plot(ones(size(idx,2)),xc(1,:),'o'); plot(2*ones(size(idx,2)),xc(2,:),'s'); plot(3*ones(size(idx,2)),xc(3,:),'v');
xlim([0,4]); title('autocorr correlation'); xticks(1:3); xticklabels({'E1 & E2','E1 & E3','E2 & E3'});
saveas(gcf,[figpath,'autocorr_corr_summary_a',num2str(a),'.png']);
