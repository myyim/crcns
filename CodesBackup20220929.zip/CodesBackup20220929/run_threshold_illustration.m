% close all; clear all;
load('./fitcirculartrack.mat');
figure(1); set(gcf,'Position',[0 0 1000 1200]);
[trackpos,trackf,~] = getdata_sargolini('MEC181011Al_t2_c1',2,1,1,pall(21,:));
subplot(441); hold on; axis image; title('cell 21');
plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2);

[rmap,spk,dur] = smoothratemap(trackpos,trackf);
subplot(442); hold on; axis image; 
r = (size(rmap,2)-1)/2; imagesc_env(rmap',-r:r,-r:r);
colorbar; colormap(jet(256)); caxis([0 0.2*max(rmap,[],'all')]);
set(gca,'color',[1 1 1]); set(gca,'YDir','normal');

subplot(443); hold on; axis image; 
imagesc_env(rmap',-r:r,-r:r);
colorbar; colormap(jet(256)); caxis([0 0.4*max(rmap,[],'all')]);
set(gca,'color',[1 1 1]); set(gca,'YDir','normal');

subplot(444); hold on; axis image;
rmap1 = (rmap>0); imagesc_env(rmap1',-r:r,-r:r);
colorbar; colormap(jet(256)); caxis([0 1]);
set(gca,'color',[1 1 1]); set(gca,'YDir','normal');

upper = max(rmap(:)); gthre = 0.08*upper; rmap1 = rmap; rmap1(rmap1<=gthre) = 0; [mp,n] = bwlabel(rmap1);
%[gs,thre] = shuffledfields_lowthreshold(rmap,1,mask?,0.08)
rmap_s = rmap_A(2).E(1).GC(21).rmap;
subplot(446); hold on; axis image;
imagesc_env(rmap_s',-r:r,-r:r);
colorbar; colormap(jet(256)); caxis([0 0.2*max(rmap_s,[],'all')]);
set(gca,'color',[1 1 1]); set(gca,'YDir','normal');

subplot(447); hold on; axis image;
imagesc_env(rmap_s',-r:r,-r:r);
colorbar; colormap(jet(256)); caxis([0 0.4*max(rmap_s,[],'all')]);
set(gca,'color',[1 1 1]); set(gca,'YDir','normal');

subplot(448); hold on; axis image; 
imagesc_env(mp',-r:r,-r:r);
colorbar; colormap(jet(256)); caxis([0 max(mp,[],'all')]);
set(gca,'color',[1 1 1]); set(gca,'YDir','normal');



% %close all; clear all;
% %% 6 animals
% an = {'MEC2','MEC1','MEC3','MEC4','1RS_','2BS_'};
% sig = 3;
% 
% %% which datapath dp?
% % 1: Large Arena matlab files (all 64 cells)
% % 2: Large Circular track light matlab files (all 64 cells)
% % 3: Large Circular track dark matlab files (35 cells)
% % 4: Small Arena matlab files (29 cells)
% % 5: Small Circular track matlab files (29 cells)
% 
% %% load paths and data
% datapath = './Jacob_Sargolini_All_Environments/'; % update your path here!
% allpath = genpath(datapath);
% addpath(allpath);
% addpath('./gridness/');
% load('./CellsID.mat');
% load('./fitcirculartrack.mat'); % load data pall (fitted parameters)
% figpath = './figures/Jacob_Sargolini_shuffled/';
% if ~exist(figpath)
%     mkdir(figpath);
% end
% addpath(figpath);
% 
% lowthreshold = zeros(35,3); % 35 cells; 3 env
% for s = 1:1 %100
%     disp('-------------------');
%     disp(['s = ',num2str(s)]);
%     % create a struct for storing ratemaps & autocorrelations
%     rmap_A = struct();
%     for j = 1:2 % animals
%         ac_A(j).E = struct();
%     end
% 
%     for dp = 1:2
%         disp(['dp = ',num2str(dp)]);
%         if dp == 1
%             %addpath([datapath,'Large Arena matlab files/']);
%             filename = 'CellsID.Arena';
%         elseif dp == 2
%             %addpath([datapath,'Large Circular track light matlab files/']);
%             filename = 'CellsID.CircularTrackLight';
%         elseif dp == 3
%             %addpath([datapath,'Large Circular track dark matlab files/']);
%             filename = 'CellsID.CiruclarTrackDark';
%         elseif dp == 4
%             %addpath([datapath,'Small Arena matlab files/']);
%             filename = 'CellsID.SmallArena';
%         elseif dp == 5
%             %addpath([datapath,'Small Circular track matlab files/']);
%             filename = 'CellsID.SmallCircularTrack';
%         end
%         for j = [21] %1:35
%             eval(['fname = ',filename,'(j);']);
%             if fname == ""
%                 continue
%             end
%             disp(['cell = ',num2str(j)]);
%             tID = CellsID.tetrode(j);
%             cID = CellsID.cell(j);
%             fname = char(fname);
%             if fname(1) == 'M'
%                 if dp == 1
%                     fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];          
%                 else
%                     fname = [fname(1:11),'_t',num2str(tID),'_c',num2str(cID)];
%                 end
%             else
%                 fname = [fname(1:16),'_t',num2str(tID),'_c',num2str(cID)];
%             end
%             aid = find(strcmp(fname(1:4),an)==1);
%             [trackpos,trackf,~] = getdata_sargolini(fname,tID,cID,1,pall(j,:)); % pall stores the fitted parameters            
%             trackpos_radius = sqrt(trackpos(:,1).^2+trackpos(:,2).^2); rm = ceil(max(trackpos_radius));
%             trackf_radius = sqrt(trackf(:,1).^2+trackf(:,2).^2); rmax = min([ceil(max(trackf_radius))+2 rm]);
%             if size(trackf,1) == 0
%                 rmap_A(aid).E(dp).GC(j).rmap = zeros(2*rm+1);
%                 for k = 0:5
%                     eval(['ac_A(aid).E(dp).GC(j).R',num2str(k*30),' = zeros(4*ceil(max(trackpos_radius))+1);']);
%                 end
%             else
%                 %rm = min([78 rm]); % set limit for max
%                 mask = ones(2*rm+1); [ycoor,xcoor] = meshgrid(-rm:rm,-rm:rm); % coordinates of the grid, y by x
%                 mask(xcoor.^2+ycoor.^2>rmax^2) = 0;
%                 if dp > 1
%                     %rmin = max([55 floor(min(trackpos_radius))]);   % set limit for min
%                     rmin = max([55 floor(min(trackf_radius))]);   % set limit for min
%                     mask(xcoor.^2+ycoor.^2<rmin^2) = 0;
%                 end
%                 seed = 105*(s-1)+3*(j-1)+dp;
%                 if s == 1
%                     [ac0,ac30,ac60,ac90,ac120,ac150,rmap,thre0] = data2ac_shuffled(trackpos,trackf,sig,mask,seed);
%                     lowthreshold(j,dp) = thre0;
%                 else
%                     [ac0,ac30,ac60,ac90,ac120,ac150,rmap,~] = data2ac_shuffled(trackpos,trackf,sig,mask,seed,lowthreshold(j,dp));
%                 end
%                 rmap_A(aid).E(dp).GC(j).rmap = rmap;
%                 for k = 0:5
%                     eval(['ac_A(aid).E(dp).GC(j).R',num2str(k*30),' = ac',num2str(k*30),';']);
%                 end
%             end
%         end
%     end
%     if s == 1
%         save([figpath,'lowthreshold.mat'],'lowthreshold');
%     end
%     save([figpath,'ac_struct_s',num2str(s),'.mat'],'ac_A','rmap_A');
% end
