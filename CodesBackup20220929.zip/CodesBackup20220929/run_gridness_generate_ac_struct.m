close all; clear all;
%% 6 animals
an = {'MEC2','MEC1','MEC3','MEC4','1RS_','2BS_'};
sig = 3;

%% which datapath dp?
% 1: Large Arena matlab files (all 64 cells)
% 2: Large Circular track light matlab files (all 64 cells)
% 3: Large Circular track dark matlab files (35 cells)
% 4: Small Arena matlab files (29 cells)
% 5: Small Circular track matlab files (29 cells)

%% load paths and data
datapath = './Jacob_Sargolini_All_Environments/'; % update your path here!
allpath = genpath(datapath);
addpath(allpath);
addpath('./gridness/');
load('./CellsID.mat');
load('./fitcirculartrack.mat'); % load data pall (fitted parameters)
figpath = './figures/Jacob_Sargolini_gridness_circular_light/';
if ~exist(figpath)
    mkdir(figpath);
end
addpath(figpath);

%% create a struct for storing ratemaps & autocorrelations
rmap_A = struct();
ac_A = struct();
% for j = 1:6 % animals
%     ac_A(j).E = struct();
% end

for dp = 1:3
    disp(['dp = ',num2str(dp)]);
    if dp == 1
        %addpath([datapath,'Large Arena matlab files/']);
        filename = 'CellsID.Arena';
    elseif dp == 2
        %addpath([datapath,'Large Circular track light matlab files/']);
        filename = 'CellsID.CircularTrackLight';
    elseif dp == 3
        %addpath([datapath,'Large Circular track dark matlab files/']);
        filename = 'CellsID.CiruclarTrackDark';
    elseif dp == 4
        %addpath([datapath,'Small Arena matlab files/']);
        filename = 'CellsID.SmallArena';
    elseif dp == 5
        %addpath([datapath,'Small Circular track matlab files/']);
        filename = 'CellsID.SmallCircularTrack';
    end
    for j = 1:64
        eval(['fname = ',filename,'(j);']);
        if fname == ""
            continue
        end
        disp(['cell = ',num2str(j)]);
        tID = CellsID.tetrode(j);
        cID = CellsID.cell(j);
        fname = char(fname);
        if fname(1) == 'M'
            if dp == 1
                fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];          
            else
                fname = [fname(1:11),'_t',num2str(tID),'_c',num2str(cID)];
            end
        else
            fname = [fname(1:16),'_t',num2str(tID),'_c',num2str(cID)];
        end
        aid = find(strcmp(fname(1:4),an)==1);
        [trackpos,trackf,~] = getdata_sargolini(fname,tID,cID,1,pall(j,:)); % pall stores the fitted parameters
        [rmap,~,~] = smoothratemap(trackpos,trackf,sig);
        rmap_A(aid).E(dp).GC(j).rmap = rmap;
        rmap(isnan(rmap)) = 0;
        ac0 = xcorr2(rmap);
        ac_A(aid).E(dp).GC(j).ac = ac0;
        %[ac0,ac30,ac60,ac90,ac120,ac150] = data2ac(trackpos,trackf,sig,300,0);
        %for k = 0:5
        %    eval(['ac_A(aid).E(dp).GC(j).R',num2str(k*30),' = ac',num2str(k*30),';']);
        %end
    end
end
save('ac_struct64.mat','ac_A','rmap_A');
