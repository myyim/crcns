function gs = shuffledfields_lowthreshold(g2d,seed,mask)
% gs = shuffledfields(g2d,seed,mask) shuffles grid fields in g2d.
% Optional seed returns different realizations.
% Optional mask defines the boundary for shuffled fields.
% Image processing toolbox is required.
if nargin <= 1
    seed = 1;
end
if nargin <= 2
    mask = ones(size(g2d));
end
if sum(size(g2d) ~= size(mask))
    error('The mask should have the same size as the input matrix.')
end
maxiter = 100000;
if mask(round(size(mask,1)*size(mask,2)/2)) > 0
    mp_thre = 1000;
else
    mp_thre = 500;
end
mask0 = mask;
upper = max(g2d(:));
thre = 0;
[ycoor,xcoor] = meshgrid(1:size(g2d,2),1:size(g2d,1)); % coordinates of the grid. Note g2d is y by x. 
count = maxiter;
while thre < 0.15 && count >= maxiter
    gthre = thre*upper; 
    g2d_small = g2d(logical((g2d<=gthre).*(g2d>0))); % take all including outside mask
    g2d1 = g2d; g2d1(g2d1<=gthre) = 0;
    [mp,n] = bwlabel(g2d1);  % find the islands and the number
    mp_size = zeros(n,1);
    for j = 1:n
        mp_size(j) = sum(sum(mp==j));
    end
    disp([num2str(thre),' ',num2str(n),' ', num2str(max(mp_size))]);
    if n < 2 || max(mp_size)>mp_thre
        thre = thre + 0.01; 
        continue;
        %error('Multiple isolated circular bumps separated by 0s are needed. Consider thresholding your data.');
    end
    gs = zeros(size(g2d));
    rng(seed);
    for j = 1:n
        xtemp = (mp==j).*xcoor; xmax = max(xtemp,[],'all'); % find the smallest rectangle that contains the island
        xtemp(xtemp==0)=1e10; xmin = min(xtemp,[],'all');
        ytemp = (mp==j).*ycoor; ymax = max(ytemp,[],'all');
        ytemp(ytemp==0)=1e10; ymin = min(ytemp,[],'all');
        count = 0;
        while count==0 || sum(sum(mp==j))~=sum(sum((proj>0).*mask)) % restrict the new field using the mask
            if count >= maxiter
                break;
                %error('A field does not fit in the shuffled environment. Consider using a larger environment.')
            end
            select = (mask==1).*(xcoor<max(xcoor,[],'all')-xmax+xmin+1).*(ycoor<max(ycoor,[],'all')-ymax+ymin+1);
            newcorner = datasample([xcoor(select==1) ycoor(select==1)],1); % coordinates of the lower corner to place the field
            proj = zeros(size(g2d));
            proj(newcorner(1):newcorner(1)+xmax-xmin,newcorner(2):newcorner(2)+ymax-ymin) = g2d(xmin:xmax,ymin:ymax);
            count = count + 1;
        end
        if count >= maxiter
            break;
        end
        mask(proj>0) = 0; % update the mask
        gs = gs + proj; % assign the field to the new location    
    end
    thre = thre + 0.01;
end

% fill the empty space with exact subthreshold activity
mask = (gs==0).*mask0;  % locations where subthreshold activity can be placed
idx = find(mask==1);
idx = randsample(idx,numel(g2d_small));
gs(idx) = g2d_small;
% figure; hold on; axis image; colorbar; colormap(jet(256));imagesc_env(gs);
end