% close all; clear all;
%% 6 animals
an = {'MEC2','MEC1','MEC3','MEC4','1RS_','2BS_'};
sig = 3;

%% which datapath dp?
% 1: Large Arena matlab files (all 64 cells)
% 2: Large Circular track light matlab files (all 64 cells)
% 3: Large Circular track dark matlab files (35 cells)
% 4: Small Arena matlab files (29 cells)
% 5: Small Circular track matlab files (29 cells)

%% load paths and data
datapath = './Jacob_Sargolini_All_Environments/'; % update your path here!
allpath = genpath(datapath);
addpath(allpath);
addpath('./gridness/');
load('./CellsID.mat');
load('./fitcirculartrack.mat'); % load data pall (fitted parameters)
figpath = './figures/Jacob_Sargolini_shuffled/';
if ~exist(figpath)
    mkdir(figpath);
end
addpath(figpath);

if s == 1
    lowthreshold = zeros(35,3); % 35 cells; 3 env
else
    load('lowthreshold.mat');
    threshold = zeros(35,3); % 35 cells; 3 env
end    

%for s = 1:100
if 1
    disp('-------------------');
    disp(['s = ',num2str(s)]);
    % create a struct for storing ratemaps & autocorrelations
    rmap_A = struct();
    ac_A = struct();

    for dp = 1:3
        disp(['dp = ',num2str(dp)]);
        if dp == 1
            %addpath([datapath,'Large Arena matlab files/']);
            filename = 'CellsID.Arena';
        elseif dp == 2
            %addpath([datapath,'Large Circular track light matlab files/']);
            filename = 'CellsID.CircularTrackLight';
        elseif dp == 3
            %addpath([datapath,'Large Circular track dark matlab files/']);
            filename = 'CellsID.CiruclarTrackDark';
        elseif dp == 4
            %addpath([datapath,'Small Arena matlab files/']);
            filename = 'CellsID.SmallArena';
        elseif dp == 5
            %addpath([datapath,'Small Circular track matlab files/']);
            filename = 'CellsID.SmallCircularTrack';
        end
        for j = 1:35
            eval(['fname = ',filename,'(j);']);
            if fname == ""
                continue
            end
            disp(['cell = ',num2str(j)]);
            tID = CellsID.tetrode(j);
            cID = CellsID.cell(j);
            fname = char(fname);
            if fname(1) == 'M'
                if dp == 1
                    fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];          
                else
                    fname = [fname(1:11),'_t',num2str(tID),'_c',num2str(cID)];
                end
            else
                fname = [fname(1:16),'_t',num2str(tID),'_c',num2str(cID)];
            end
            aid = find(strcmp(fname(1:4),an)==1);
            [trackpos,trackf,~] = getdata_sargolini(fname,tID,cID,1,pall(j,:)); % pall stores the fitted parameters            
            trackpos_radius = sqrt(trackpos(:,1).^2+trackpos(:,2).^2); rm = ceil(max(trackpos_radius));
            trackf_radius = sqrt(trackf(:,1).^2+trackf(:,2).^2); rmax = min([ceil(max(trackf_radius))+2 rm]);
            if size(trackf,1) == 0
                rmap_A(aid).E(dp).GC(j).rmap = zeros(2*rm+1);
                for k = 0:5
                    eval(['ac_A(aid).E(dp).GC(j).R',num2str(k*30),' = zeros(4*ceil(max(trackpos_radius))+1);']);
                end
            else
                %rm = min([78 rm]); % set limit for max
                mask = ones(2*rm+1); [ycoor,xcoor] = meshgrid(-rm:rm,-rm:rm); % coordinates of the grid, y by x
                mask(xcoor.^2+ycoor.^2>rmax^2) = 0;
                if dp > 1
                    %rmin = max([55 floor(min(trackpos_radius))]);   % set limit for min
                    rmin = max([55 floor(min(trackf_radius))]);   % set limit for min
                    mask(xcoor.^2+ycoor.^2<rmin^2) = 0;
                end
                seed = 105*(s-1)+3*(j-1)+dp;
                if s == 1
                    [ac0,ac30,ac60,ac90,ac120,ac150,rmap,thre0] = data2ac_shuffled(trackpos,trackf,sig,mask,seed,0);
                    lowthreshold(j,dp) = thre0;
                else
                    [ac0,ac30,ac60,ac90,ac120,ac150,rmap,thre] = data2ac_shuffled(trackpos,trackf,sig,mask,seed,lowthreshold(j,dp));
                    threshold(j,dp) = thre;
                end
                rmap_A(aid).E(dp).GC(j).rmap = rmap;
                ac0 = xcorr2(rmap);
                ac_A(aid).E(dp).GC(j).ac = ac0;
            end
        end
    end
    if s == 1
        save([figpath,'lowthreshold.mat'],'lowthreshold');
    else
        save([figpath,'threshold_s',num2str(s),'.mat'],'threshold');
    end
    save([figpath,'ac_struct_s',num2str(s),'.mat'],'ac_A','rmap_A');
end
