close all; clear all;

% parameters
norm = 2; % 0: no normalization; 1: overall peak; 2: peak within donut
r = 150;
[ycoor,xcoor] = meshgrid(-r:r,-r:r);

% data
codepath = './codes/'; % update your path here!
allpath = genpath(codepath); addpath(allpath);
datapath = './data/'; % update your path here!
allpath = genpath(datapath); addpath(allpath);
load('CellsID.mat');
load('fitcirculartrack.mat'); % pall (fitted parameters)

figure; set(gcf,'Position',[0 0 1200 800]); colormap(jet(256));

for col = 1:3
    % animal
    if col == 1
        load('gridness_a1_shuffled_summary.mat');
        v = [1.4447,0.49488,0.63461,0.82604];
        ctitle = 'rat 1';
    elseif col == 2
        load('gridness_a2_split1_shuffled_summary.mat');
        v = [0.89352,-0.037425,0.28376,0.17494];
        ctitle = 'rat 2 module 1';
    else
        load('gridness_a2_split2_shuffled_summary.mat');
        v = [1.2333,0.84242,0.1818,-0.0025795];
        ctitle = 'rat 2 module 2';
    end
    p = [sum(score_listE1>=v(1)) sum(score_listE2>=v(2)) sum(score_listE3>=v(3)) sum(score_listE23>=v(4))]/1000;
    p23 = sum((score_listE2>=v(2)).*(score_listE3>=v(3)))/1000;

    subplot(4,5,col); hold on; h = histogram(score_listE1,-1.05:0.1:2.05,'FaceColor','k'); 
    plot(v(1)*ones(1,2),[0 max(h.Values)],'r'); ylabel('E_1','Rotation',0); xlabel('gridness');    
    text(0.5,200,['p=',num2str(p(1),'%.2f')]); title(ctitle);
    subplot(4,5,col+5); hold on; h = histogram(score_listE2,-1.05:0.1:2.05,'FaceColor','k'); 
    plot(v(2)*ones(1,2),[0 max(h.Values)],'r'); ylabel('E_2','Rotation',0); xlabel('gridness');
    text(1,100,['p=',num2str(p(2),'%.2f')]);
    subplot(4,5,col+10); hold on; h = histogram(score_listE3,-1.05:0.1:2.05,'FaceColor','k'); 
    plot(v(3)*ones(1,2),[0 max(h.Values)],'r'); ylabel('E_3','Rotation',0); xlabel('gridness');
    text(1,100,['p=',num2str(p(3),'%.2f')]);
    subplot(4,5,col+15); hold on; h = histogram(score_listE23,-1.05:0.1:2.05,'FaceColor','k');
    plot(v(4)*ones(1,2),[0 max(h.Values)],'r'); ylabel('E_2 + E_3','Rotation',0); xlabel('gridness');
    text(1,100,['p=',num2str(p(4),'%.2f')]);
    subplot(3,3,3*col); hold on; plot(score_listE2,score_listE3,'k.'); plot(v(2)*ones(2),[-1.3,1.3],'r'); plot([-1.3,1.3],v(3)*ones(2),'r');
    axis image; xlabel('E_2 gridness'); ylabel('E_3 gridness'); title(ctitle); 
    text(0.8,0.8,['p=',num2str(p23,'%.2f')]);
end

set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,...
    'PaperPosition',[0 0 screenposition(3:4)],...
    'PaperSize',[screenposition(3:4)]);
print -dpdf supp_stats 