clear all; close all;
lam = 41; % period
psi = 0.31;    % orientation
c = [0,0]; %[12,21];  % center related to phase
r = 75-15/2;    % radius of circular track
figpath = './figures/';
%addpath('../Knierim_Data');
addpath('./oldcode');
fpk = 1;    % peak rate
sd_range = 0.1; % max spatial frequency in PSD
lmesh = r;%2*r;    % size of environment containing the track is 2*lmesh+1
t = 0:1/r:2*pi; % parameter
x0 = -lmesh:lmesh;
y0 = -lmesh:lmesh;
[xm,ym] = meshgrid(x0,y0);
g2d = gridcell(xm,ym,fpk,lam,psi,c);
x = r*cos(t);
y = r*sin(t);
%g = gridcell(x,y,fpk,lam,psi,c);
%psd = conj(fft(g)).*fft(g);
%shuffle = @(v)v(randperm(numel(v)));
%gs = shuffle(g);
%psds = conj(fft(gs)).*fft(gs);
figure;
set(gcf,'Position',[0 0 900 400])
subplot(341);
imagesc(x0,y0,g2d); axis image; colorbar; colormap(jet(256)); caxis([0 1]);
hold on;
plot(x,y,'w');
title('grid')
subplot(345);
gcir = zeros(size(g2d));
xcoor = x+lmesh+1;
ycoor = y+lmesh+1;
for j = 1:size(xcoor,2)
    gcir(round(xcoor(j)),round(ycoor(j))) = g2d(round(xcoor(j)),round(ycoor(j)));
end
imagesc(x0,y0,gcir); axis image; colorbar; colormap(jet(256)); caxis([0 1]);
hold on;
title('grid on circle')
%plot(round(x),round(y),'wx')
%plot(x,y,'w')
subplot(342);
x1 = -2*lmesh:2*lmesh;
y1 = -2*lmesh:2*lmesh;
g2d_xcor = xcorr2(g2d);
imagesc(x1,y1,g2d_xcor); axis image; colorbar; colormap(jet(256));
title('acorr');
subplot(343);
g2d_psdac = ac2psd(g2d_xcor);
imagesc(x1/(4*lmesh),y1/(4*lmesh),g2d_psdac); axis image; colorbar; colormap(jet(256)); xlim([-sd_range,sd_range]); ylim([-sd_range,sd_range]);
title('PSD via acorr');
subplot(344);
g2d_psd = psd2d(g2d);
imagesc(x0/(2*lmesh),y0/(2*lmesh),g2d_psd); axis image; colorbar; colormap(jet(256)); xlim([-sd_range,sd_range]); ylim([-sd_range,sd_range]);
title('PSD');
subplot(346);
gcir_xcor = xcorr2(gcir);
imagesc(x1,y1,gcir_xcor); axis image; colorbar; colormap(jet(256));
title('acorr');
subplot(347);
gcir_psdac = ac2psd(gcir_xcor);
imagesc(x1/(4*lmesh),y1/(4*lmesh),gcir_psdac); axis image; colorbar; colormap(jet(256)); xlim([-sd_range,sd_range]); ylim([-sd_range,sd_range]);
title('PSD via acorr');
subplot(348);
gcir_psd = psd2d(gcir);
imagesc(x0/(2*lmesh),y0/(2*lmesh),gcir_psd); axis image; colorbar; colormap(jet(256)); xlim([-sd_range,sd_range]); ylim([-sd_range,sd_range]);
title('PSD');
subplot(3,4,10);
imagesc(x1,y1,log10(gcir_xcor)); axis image; colorbar; colormap(jet(256));
title('log10 acorr');
subplot(3,4,11);
imagesc(x1/(4*lmesh),y1/(4*lmesh),log10(gcir_psdac)); axis image; colorbar; colormap(jet(256)); xlim([-sd_range,sd_range]); ylim([-sd_range,sd_range]);
title('log10 PSD via acorr');
subplot(3,4,12);
imagesc(x0/(2*lmesh),y0/(2*lmesh),log10(gcir_psd)); axis image; colorbar; colormap(jet(256)); xlim([-sd_range,sd_range]); ylim([-sd_range,sd_range]);
title('log10 PSD');
subplot(349);
axis off;
fname = ['psd_l',num2str(lam),'o',num2str(psi),'c',num2str(c),'r',num2str(r)];
title(fname(5:end));
%title(['\lambda: ',num2str(lam),'; ori: ',num2str(psi),'; C: ',num2str(c),'; r: ',num2str(r)]);
%saveas(gcf,[figpath,fname,'.pdf']);
plotcirculargrid(lam,psi,c,r)