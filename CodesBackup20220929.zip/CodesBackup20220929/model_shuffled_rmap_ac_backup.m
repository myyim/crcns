function [rmap,ac] = model_shuffled_rmap_ac(y,x,lam,psi,c,r_inner,r_outer,thre,seed)
% [rmap,ac,ac0r,rad,fsize,cor,score]
if nargin < 9
    seed = 1;
end
if nargin < 8
    thre = 0.2;
end
if nargin < 7
    r_outer = 2*max(size(y));   % no outer bound
end
if nargin < 6
    r_inner = 0;   % no inner bound
end
if nargin < 5
    c = [0,0];   % centered at [0,0]
end
rng(seed);
rmap = gridcell(y,x,1,lam,psi,c);  % from left to right in a matrix is in the direction of increasing the second coordinate, thus (y,x)
rmap = shuffled_identical_circular_fields(rmap,thre,seed);
rmap(x.^2+y.^2<r_inner^2) = 0; rmap(x.^2+y.^2>r_outer^2) = 0; % inner and outer radii
ac = xcorr2(rmap);

% rmap0 = rmap;
% 
% % Locate the ring in ac0 with max activity
% xm = floor(size(rmap,1)/2); % the mask matrix is rectangular
% ym = floor(size(rmap,2)/2);
% [ycoor,xcoor] = meshgrid(-2*ym:2*ym,-2*xm:2*xm); % coordinates of the autocorrelation grid, y by x
% topright = sqrt((xcoor+0.5).^2+(ycoor+0.5).^2);
% topleft = sqrt((xcoor-0.5).^2+(ycoor+0.5).^2);
% bottomleft = sqrt((xcoor-0.5).^2+(ycoor-0.5).^2);
% bottomright = sqrt((xcoor+0.5).^2+(ycoor-0.5).^2);
% rtensor(:,:,1) = topright; rtensor(:,:,2) = topleft; rtensor(:,:,3) = bottomleft; rtensor(:,:,4) = bottomright;
% rmin = min(rtensor,[],3); rmax = max(rtensor,[],3);
% dmax = floor(max(size(rmap,1))/2); ac0r = zeros(1,dmax);  % average autocorrelation along a circle (index = radius) 
% for rad = 1:dmax
%     ringon = (rad>=rmin).*(rad<=rmax); % define the bins on the circle
%     ac0r(rad) = sum(ac(ringon==1))/sum(sum(ringon==1));
% end
% dac0r = ac0r(2:end)-ac0r(1:end-1); % difference
% 
% % The radius with max average autocorrelation or with min decrease in
% % autocorrelation in case of no max
% sgn = [0 dac0r(1:end-2)>=0].*(dac0r(1:end-1)>=0).*(dac0r(2:end)<0).*[dac0r(3:end)<0 0];
% if sum(sgn) == 0   
%     ddac0r = dac0r(2:end)-dac0r(1:end-1); % difference of difference
%     sgn = [0 ddac0r(1:end-2)>=0].*(ddac0r(1:end-1)>=0).*(ddac0r(2:end)<0).*[ddac0r(3:end)<0 0];
%     if sum(sgn) == 0
%         score = nan; rad = nan; fsize = nan; d1 = nan;
%         return
%     else
%         rad = find(sgn==1); rad = rad(1)+2;   % radius of the circle (second order difference)
%         fsize = ceil(rad/2);
% 
%     end
% else
%     rad = find(sgn==1); rad = rad(1)+1;   % radius of the circle (first order difference)
%     sgn = [0 dac0r(1:end-2)<=0].*(dac0r(1:end-1)<=0).*(dac0r(2:end)>0).*[dac0r(3:end)>0 0];
%     fsize = find(sgn==1); fsize = fsize(1);   % radius of the circle (first order difference)
% end
% 
% ac0 = ac; ac0(xcoor.^2+ycoor.^2<fsize^2) = 0; ac0(xcoor.^2+ycoor.^2>(2*rad-fsize)^2) = 0;
% rmap = gridcell(y,x,1,lam,psi+pi/3,rotation_matrix(pi/3)*c',thre); rmap(x.^2+y.^2<r_inner^2) = 0; rmap(x.^2+y.^2>r_outer^2) = 0;
% ac60 = xcorr2(rmap); ac60(xcoor.^2+ycoor.^2<fsize^2) = 0; ac60(xcoor.^2+ycoor.^2>(2*rad-fsize)^2) = 0;
% rmap = gridcell(y,x,1,lam,psi+2*pi/3,rotation_matrix(2*pi/3)*c',thre); rmap(x.^2+y.^2<r_inner^2) = 0; rmap(x.^2+y.^2>r_outer^2) = 0;
% ac120 = xcorr2(rmap); ac120(xcoor.^2+ycoor.^2<fsize^2) = 0; ac120(xcoor.^2+ycoor.^2>(2*rad-fsize)^2) = 0;
% rmap = gridcell(y,x,1,lam,psi+pi/6,rotation_matrix(pi/6)*c',thre); rmap(x.^2+y.^2<r_inner^2) = 0; rmap(x.^2+y.^2>r_outer^2) = 0;
% ac30 = xcorr2(rmap); ac30(xcoor.^2+ycoor.^2<fsize^2) = 0; ac30(xcoor.^2+ycoor.^2>(2*rad-fsize)^2) = 0;
% rmap = gridcell(y,x,1,lam,psi+pi/2,rotation_matrix(pi/2)*c',thre); rmap(x.^2+y.^2<r_inner^2) = 0; rmap(x.^2+y.^2>r_outer^2) = 0;
% ac90 = xcorr2(rmap); ac90(xcoor.^2+ycoor.^2<fsize^2) = 0; ac90(xcoor.^2+ycoor.^2>(2*rad-fsize)^2) = 0;
% rmap = gridcell(y,x,1,lam,psi+5*pi/6,rotation_matrix(5*pi/6)*c',thre); rmap(x.^2+y.^2<r_inner^2) = 0; rmap(x.^2+y.^2>r_outer^2) = 0;
% ac150 = xcorr2(rmap); ac150(xcoor.^2+ycoor.^2<fsize^2) = 0; ac150(xcoor.^2+ycoor.^2>(2*rad-fsize)^2) = 0;
% 
% cor = ones(1,6);
% ac0_vec = ac0(logical((xcoor.^2+ycoor.^2>=fsize^2).*(xcoor.^2+ycoor.^2<=(2*rad-fsize)^2)));
% for j = 2:6
%     ac_vec = eval(['ac',num2str(30*(j-1))]);
%     ac_vec = ac_vec(logical((xcoor.^2+ycoor.^2>=fsize^2).*(xcoor.^2+ycoor.^2<=(2*rad-fsize)^2)));
%     xcor = corrcoef(ac0_vec,ac_vec);
%     cor(j) = xcor(1,2);
% end
% score = min(cor(3:2:5))-max(cor(2:2:6));
% rmap = rmap0;

end