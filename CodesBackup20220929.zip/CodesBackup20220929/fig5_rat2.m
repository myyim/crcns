close all; clear all;

% parameters
cscale = 0.25; cscale2 = 0.07; % fraction of max as the upper limit of colorbar
rm = 75; % the square size is 2rm X 2rm
idx = [20:26,28:35];  % animal 3
[y,x] = meshgrid(-rm:rm,-rm:rm);

% functions
% env_patch, getdata, imagesc_env

% data for figure 3
datapath = './Jacob_Sargolini_All_Environments/'; % update your path here!
allpath = genpath(datapath); addpath(allpath);
codepath = './codes/'; % update your path here!
allpath = genpath(codepath); addpath(allpath);
datapath = './data/'; % update your path here!
allpath = genpath(datapath); addpath(allpath);
load('CellsID.mat');
load('fitcirculartrack.mat'); % pall (fitted parameters)
load('ac_struct.mat');
load('gridcells_spac_ori.mat'); % from run_grid3orientations_data
load('a2_gridcells_summary_spac_ori.mat'); % from run_grid3orientations
load('a2_summary_ac.mat'); load('a2_gscores.mat');     % from run_gridness_norm
load('a2M_gridcells_summary_spac_ori.mat'); 
% from run_grid3orientations_split
load('a2M_summary_ac.mat'); load('a2M_gscores.mat');     
% from run_gridness_norm_split

figure; set(gcf,'Position',[0 0 1200 900]); colormap(jet(256)); 
subplot(4,6,2); r = (size(a2_ac1,2)-1)/2; imagesc_env(a2_ac1,-r:r,-r:r); title(['gridness: ',num2str(a2_gscores(1),2)]);
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(a2_ac1,[],'all')*cscale]); ylabel('E_1','Rotation',0);

subplot(4,6,8); r = (size(a2_ac2,2)-1)/2; imagesc_env(a2_ac2,-r:r,-r:r); title(['gridness: ',num2str(a2_gscores(2),2)]);
caxis([0 max(a2_ac2,[],'all')*cscale2]); xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); ylabel('E_2','Rotation',0);

subplot(4,6,14); r = (size(a2_ac3,2)-1)/2; imagesc_env(a2_ac3,-r:r,-r:r); title(['gridness: ',num2str(a2_gscores(3),2)]);
caxis([0 max(a2_ac3,[],'all')*cscale2]); xlabel('lag (cm)'); ylabel('E_3','Rotation',0); %xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); 

a2_oris(a2_oris<20) = a2_oris(a2_oris<20) + 180;
[a2_oris,idx] = sort(a2_oris,2);
a2_spacs = mean(a2_spacs,2);
subplot(4,3,10); hold on; yyaxis left;
% plot([0 19],a2_sum_oris(1,1)*ones(2),'-','LineWidth',0.1);
% plot([0 19],a2_sum_oris(1,2)*ones(2),'-','LineWidth',0.1);
% plot([0 19],a2_sum_oris(1,3)*ones(2),'-','LineWidth',0.1);
% yyaxis right; plot([0 19],mean(a2_sum_spacs(1,:),2)*ones(2),'-','LineWidth',0.1);
% yyaxis left;
for j = 1:15
    plot(j*ones(1,3),a2_oris(j,:),'x');
end 
ylabel('E_1-inferred orientations (^{\circ})'); ylim([20 210]); 
yyaxis right; plot(a2_spacs,'o'); ylim([32 62]);
ylabel('E_1-inferred spacing (cm)'); xlabel('cell ID'); xlim([0,16]); xticks([1,5,10,15]);

subplot(3,3,2);
x1 = zscore(a2_spacs,0,1); x2 = zscore(a2_oris,0,1);
X = horzcat(x1,x2); Y = pdist(X);
Z = linkage(Y,'average');
h = dendrogram(Z,'ColorThreshold',2.5); 
xlabel('cell ID'); ylabel('distance'); yticks(0:4); title('2 modules'); % dendrogram
for j = [1:4,7,9,10,12]
    h(j).Color = '#008000';   % #1f77b4
end
for j = [5,6,8,11]
    h(j).Color = '#008000';    % #ff7f0e
end
subplot(3,3,5); hold on; yyaxis left;
plot([0 5],a2M1_sum_oris(1,1)*ones(2),'-','LineWidth',0.1);
plot([0 5],a2M1_sum_oris(1,2)*ones(2),'-','LineWidth',0.1);
plot([0 5],a2M1_sum_oris(1,3)*ones(2),'-','LineWidth',0.1);
plot([1.8 4.2],(a2M1_sum_oris(1,1)+a2M1_sum_oris(1,2))/2*ones(2),'--','LineWidth',0.1);
plot([1.8 4.2],(a2M1_sum_oris(1,2)+a2M1_sum_oris(1,3))/2*ones(2),'--','LineWidth',0.1);
plot([1.8 4.2],(a2M1_sum_oris(1,1)+a2M1_sum_oris(1,3)+180)/2*ones(2)-180,'--','LineWidth',0.1);
yyaxis right; plot([0 5],mean(a2M1_sum_spacs(1,:),2)*ones(2),'-','LineWidth',0.1);
plot([1.8 4.2],sqrt(3)*mean(a2M1_sum_spacs(1,:),2)*ones(2),'--','LineWidth',0.1);
yyaxis left; ylim([0 220]);
for j = 1:4
    plot(j*ones(1,3),a2M1_sum_oris(j,:),'x');
end 
ylabel('Pop-inferred orientations (^{\circ})');
yyaxis right; plot(mean(a2M1_sum_spacs,2),'o'); ylim([35 90]);
ylabel('Pop-inferred spacing (cm)'); xlabel('environment');
xticks(1:4); xlim([0.5,4.5]); xticklabels({'E_1','E_2','E_3','E_2 + E_3'});
subplot(3,3,8); 
hold on; yyaxis left;
plot([0 5],a2M2_sum_oris(1,1)*ones(2),'-','LineWidth',0.1);
plot([0 5],a2M2_sum_oris(1,2)*ones(2),'-','LineWidth',0.1);
plot([0 5],a2M2_sum_oris(1,3)*ones(2),'-','LineWidth',0.1);
plot([1.8 4.2],(a2M2_sum_oris(1,1)+a2M2_sum_oris(1,2))/2*ones(2),'--','LineWidth',0.1);
plot([1.8 4.2],(a2M2_sum_oris(1,2)+a2M2_sum_oris(1,3))/2*ones(2),'--','LineWidth',0.1);
plot([1.8 4.2],(a2M2_sum_oris(1,1)+a2M2_sum_oris(1,3)+180)/2*ones(2)-180,'--','LineWidth',0.1);
yyaxis right; plot([0 5],mean(a2M2_sum_spacs(1,:),2)*ones(2),'-','LineWidth',0.1);
plot([1.8 4.2],sqrt(3)*mean(a2M2_sum_spacs(1,:),2)*ones(2),'--','LineWidth',0.1);
yyaxis left; ylim([0 220]);
for j = 1:4
    plot(j*ones(1,3),a2M2_sum_oris(j,:),'x');
end 
ylabel('Pop-inferred orientations (^{\circ})');
yyaxis right; plot(mean(a2M2_sum_spacs,2),'o'); ylim([30 80]);
ylabel('Pop-inferred spacing (cm)'); xlabel('environment');
xticks(1:4); xlim([0.5,4.5]); xticklabels({'E_1','E_2','E_3','E_2 + E_3'});

subplot(4,6,5); imagesc_env(a2M1_ac1,-r:r,-r:r); title(['gridness: ',num2str(a2M1_gscores(1),2)]);
caxis([0 max(a2M1_ac1,[],'all')*cscale]); ylabel('E_1','Rotation',0);%xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); 
subplot(4,6,6); imagesc_env(a2M2_ac1,-r:r,-r:r); title(['gridness: ',num2str(a2M2_gscores(1),2)]);
caxis([0 max(a2M2_ac1,[],'all')*cscale]); 
subplot(4,6,11); imagesc_env(a2M1_ac2,-r:r,-r:r); title(['gridness: ',num2str(a2M1_gscores(2),2)]);
caxis([0 max(a2M1_ac2,[],'all')*cscale2]); ylabel('E_2','Rotation',0);
subplot(4,6,12); imagesc_env(a2M2_ac2,-r:r,-r:r); title(['gridness: ',num2str(a2M2_gscores(2),2)]);
caxis([0 max(a2M2_ac2,[],'all')*cscale2]);
subplot(4,6,17); imagesc_env(a2M1_ac3,-r:r,-r:r); title(['gridness: ',num2str(a2M1_gscores(3),2)]);
caxis([0 max(a2M1_ac3,[],'all')*cscale2]); ylabel('E_3','Rotation',0);
subplot(4,6,18); imagesc_env(a2M2_ac3,-r:r,-r:r); title(['gridness: ',num2str(a2M2_gscores(3),2)]);
caxis([0 max(a2M2_ac3,[],'all')*cscale2]);
subplot(4,6,23); imagesc_env(a2M1_ac4,-r:r,-r:r); title(['gridness: ',num2str(a2M1_gscores(4),2)]);
caxis([0 max(a2M1_ac4,[],'all')*cscale2]); xlabel('lag (cm)'); ylabel('E_2 + E_3','Rotation',0);
subplot(4,6,24); imagesc_env(a2M2_ac4,-r:r,-r:r); title(['gridness: ',num2str(a2M2_gscores(4),2)]);
caxis([0 max(a2M2_ac4,[],'all')*cscale2]); xlabel('lag (cm)');

set(findall(gcf,'-property','FontSize'),'FontSize',10);
set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,...
    'PaperPosition',[0 0 screenposition(3:4)],...
    'PaperSize',[screenposition(3:4)]);
print -dpdf fig5_rat2