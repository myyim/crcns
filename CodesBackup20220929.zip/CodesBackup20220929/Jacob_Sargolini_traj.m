% This script plots the trajectories corresponding to all 64 cells in all 
% environmets in the folder Jacob_Sargolini_All_Environments. 
% The trajectories corresponding to a cell are overlaid in one single 
% panel, with different colors.
% To rescale from pixels to cm, the trajectory in CircularTrackLight was
% fitted with a circle for individial cells.

clear all; close all;

%% parameters for fitting
p_guess = [100,100,100]; 
t = 0:0.05:2*pi+0.05;
w = 15;

%% set path and get directories
datapath = './Jacob_Sargolini_All_Environments/'; % update your path here!
addpath(datapath);
addpath([datapath,'Large Arena matlab files/']);
addpath([datapath,'Large Circular track light matlab files/']);
addpath([datapath,'Large Circular track dark matlab files/']);
addpath([datapath,'Small Arena matlab files/']);
addpath([datapath,'Small Circular track matlab files/']);
figpath = './figures/Jacob_Sargolini_traj/';
if ~exist(figpath)
    mkdir(figpath);
end
addpath(figpath);
load('./CellsID.mat');

%% loop over all 64 cells
pall = [];
for j = 1:64    % filenames
    tID = CellsID.tetrode(j);
    cID = CellsID.cell(j);
    if mod(j,16) == 1
        figure;
        set(gcf,'Position',[0 0 1000 750]);
    end
    subplot(4,4,mod(j-1,16)+1); hold on; axis image;
    
    % Arena (all 64 cells)
    fname = char(CellsID.Arena(j));
    if fname(1) == 'M'
        fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];
    else
        fname = [fname(1:16),'_t',num2str(tID),'_c',num2str(cID)];
    end
    [trackpos,~,~] = getdata_sargolini(fname,tID,cID,0);
    plot(trackpos(:,1),trackpos(:,2),'k.','MarkerSize',2);
    
    % CircularTrackLight (all 64 cells)
    fname = char(CellsID.CircularTrackLight(j));
    if fname(1) == 'M'
        fname = [fname(1:11),'_t',num2str(CellsID.tetrode(j)),'_c',num2str(CellsID.cell(j))];
    else
        fname = [fname(1:16),'_t',num2str(CellsID.tetrode(j)),'_c',num2str(CellsID.cell(j))];
    end
    [trackpos,~,~] = getdata_sargolini(fname,CellsID.tetrode(j),CellsID.cell(j),0);
    plot(trackpos(:,1),trackpos(:,2),'r.','MarkerSize',2);
    p = fitcirculartrack(trackpos,p_guess,0);
    pall = [pall; p];
    
    % CircularTrackDark (35 cells)
    if CellsID.CiruclarTrackDark(j) ~= ""
        fname = char(CellsID.CiruclarTrackDark(j));
        if fname(1) == 'M'
            fname = [fname(1:11),'_t',num2str(tID),'_c',num2str(cID)];
        else
            fname = [fname(1:16),'_t',num2str(tID),'_c',num2str(cID)];
        end
        [trackpos,~,~] = getdata_sargolini(fname,tID,cID,0);
        plot(trackpos(:,1),trackpos(:,2),'b.','MarkerSize',1);
    end
    halfw_pixel = w/2*p(3)/(75-w/2);
    plot((p(3)+halfw_pixel)*cos(t)+p(1),(p(3)+halfw_pixel)*sin(t)+p(2),'c-');
    plot((p(3)-halfw_pixel)*cos(t)+p(1),(p(3)-halfw_pixel)*sin(t)+p(2),'c-');
    
    % SmallArena (29 cells)
    if CellsID.SmallArena(j) ~= ""
        fname = char(CellsID.SmallArena(j));
        if fname(1) == 'M'
            fname = [fname(1:11),'_t',num2str(tID),'_c',num2str(cID)];
        else
            fname = [fname(1:16),'_t',num2str(tID),'_c',num2str(cID)];
        end
        [trackpos,~,~] = getdata_sargolini(fname,tID,cID,0); 
        plot(trackpos(:,1),trackpos(:,2),'g.','MarkerSize',1);
    end
    
    % SmallCircularTrack (29 cells)
    if CellsID.SmallCircularTrack(j) ~= ""
        fname = char(CellsID.SmallCircularTrack(j));
        if fname(1) == 'M'
            fname = [fname(1:11),'_t',num2str(tID),'_c',num2str(cID)];
        else
            fname = [fname(1:16),'_t',num2str(tID),'_c',num2str(cID)];
        end
        [trackpos,~,~] = getdata_sargolini(fname,tID,cID,0); 
        plot(trackpos(:,1),trackpos(:,2),'m.','MarkerSize',1);
    end    
    title([CellsID.Arena{j}(1:4),';c=[',num2str(round(p(1))),',',num2str(round(p(2))),']; r=',num2str(round(p(3)))]);
    if mod(j,16) == 0
        saveas(gcf,[figpath,'traj_overlaid',num2str(j/16),'.png']);
    end
end
save('fitcirculartrack.mat','pall');
saveas(gcf,[figpath,'traj_overlaid4.png']);