clear all; close all;
%% Which datapath?
% 1: Large Arena matlab files (all 64 cells)
% 2: Large Circular track light matlab files (all 64 cells)
% 3: Large Circular track dark matlab files (35 cells)
% 4: Small Arena matlab files (29 cells)
% 5: Small Circular track matlab files (29 cells)

%% set path and get directories
datapath = './Jacob_Sargolini_All_Environments/'; % update your path here!
allpath = genpath(datapath);
addpath(allpath);
figpath = './figures/Jacob_Sargolini_ratemapcorr/';
if ~exist(figpath)
    mkdir(figpath);
end
addpath(figpath);
load('./CellsID.mat');
load('./fitcirculartrack.mat');

% animal
a = 2;
if a == 1
    idx = [1:5,7:19];  % animal 1 
elseif a == 2
    idx = [20:26,28:35]; % animal 2
end
count = size(idx,2);
rad = 75-15/2;
w = 15;   % should be <= 15
load('ac_struct64.mat');

% count = 0; rm = {};
% for j = idx    % filenames
%     count = count + 1;
%     for dp = 1:3
%         if dp == 1
%             %addpath([datapath,'Large Arena matlab files/']);
%             filename = 'CellsID.Arena';
%         elseif dp == 2
%             %addpath([datapath,'Large Circular track light matlab files/']);
%             filename = 'CellsID.CircularTrackLight';
%         elseif dp == 3
%             %addpath([datapath,'Large Circular track dark matlab files/']);
%             filename = 'CellsID.CiruclarTrackDark';
%         elseif dp == 4
%             %addpath([datapath,'Small Arena matlab files/']);
%             filename = 'CellsID.SmallArena';
%         elseif dp == 5
%             %addpath([datapath,'Small Circular track matlab files/']);
%             filename = 'CellsID.SmallCircularTrack';
%         end
%         eval(['fname = ',filename,'(j);']);
%         if fname == ""
%             continue
%         end
%         tID = CellsID.tetrode(j);
%         cID = CellsID.cell(j);
%         fname = char(fname);
%         if fname(1) == 'M'
%             if dp == 1
%                 fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];          
%             else
%                 fname = [fname(1:11),'_t',num2str(tID),'_c',num2str(cID)];
%             end
%         else
%             fname = [fname(1:16),'_t',num2str(tID),'_c',num2str(cID)];
%         end
%         [trackpos,trackf,~] = getdata_sargolini(fname,tID,cID,1,pall(j,:));
%         [rmap,~,~] = smoothratemap(trackpos,trackf);
%         rm{count,dp} = rmap;
%     end
% end 

rmap1 = []; rmap2 = []; rmap3 = [];
for j = 1:count
    if mod(j,4) == 1
        figure; set(gcf,'Position',[0 0 1000 750]);
    end
    for dp = 1:3
        subplot(3,4,(dp-1)*4+mod(j-1,4)+1); hold on;
        rmap = rmap_A(a).E(dp).GC(idx(j)).rmap;
        r = floor(size(rmap,1)/2);
        [ycoor,xcoor] = meshgrid(-r:r,-r:r); % coordinates of the grid, y by x
        imagesc_env(rmap,-r:r,-r:r,1);
        plot((rad-w/2)*cos(0:0.01:2*pi+0.01),(rad-w/2)*sin(0:0.01:2*pi+0.01),'w');
        plot((rad+w/2)*cos(0:0.01:2*pi+0.01),(rad+w/2)*sin(0:0.01:2*pi+0.01),'w');
        axis image; colormap(jet(256)); colorbar; caxis([0 0.4*max(max(rmap))]); 
        rmap = rmap((xcoor.^2+ycoor.^2<=(rad+w/2)^2).*(xcoor.^2+ycoor.^2>=(rad-w/2)^2)==1);
        rmap = rmap - mean(rmap(~isnan(rmap)),"all"); rmap(isnan(rmap)) = 0;
        if dp == 1
            rmap1 = [rmap1; rmap'];
            title(['cell ',num2str(j)]);
        elseif dp == 2
            rmap2 = [rmap2; rmap'];
        else
            rmap3 = [rmap3; rmap'];
        end
        if mod(j,4) == 1
            ylabel(['E',num2str(dp)]);
        end
    end
    if mod(j,4) == 0
        saveas(gcf,[figpath,'ratemap_compare_a',num2str(a),'_',num2str(j/4),'.png']);
    end
end

xc12 = zeros(count); xc31 = zeros(count); xc23 = zeros(count); 
for j = 1:count
    for k = 1:count
        cc = corrcoef(rmap1(j,:),rmap2(k,:)); xc12(j,k) = cc(1,2);
        cc = corrcoef(rmap3(j,:),rmap1(k,:)); xc31(j,k) = cc(1,2);
        cc = corrcoef(rmap2(j,:),rmap3(k,:)); xc23(j,k) = cc(1,2);
    end
end

figure; set(gcf,'Position',[0 0 1000 250]); hold on; plot([0.5 count+0.5],[0 0],'k--');
for j = 1:count
    ctrl = [xc12(j,1:j-1) xc12(j,j+1:end) xc31(1:j-1,j)' xc31(j+1:end,j)'];
    plot(j*ones(size(ctrl)),ctrl,'o','Color',[17 17 17]/20);
    ctrl = [xc23(j,1:j-1) xc23(j,j+1:end) xc12(1:j-1,j)' xc12(j+1:end,j)'];
    plot(j*ones(size(ctrl)),ctrl,'s','Color',[17 17 17]/20);
    ctrl = [xc31(j,1:j-1) xc31(j,j+1:end) xc23(1:j-1,j)' xc23(j+1:end,j)'];
    plot(j*ones(size(ctrl)),ctrl,'v','Color',[17 17 17]/20);
end
plot(diag(xc12),'bo','DisplayName','E1 & E2');
plot(diag(xc31),'gs','DisplayName','E1 & E3');
plot(diag(xc23),'rv','DisplayName','E2 & E3'); 
%legend; 
title('ratemap correlation'); xlabel('cell ID');
saveas(gcf,[figpath,'ratemap_corr_a',num2str(a),'.png']);
figure; set(gcf,'Position',[0 0 1000 400]);
subplot(121); hold on; plot([0.5 3.5],[0 0],'k--');
plot(ones(count*(count-1)),xc12(eye(count)==0),'o','Color',[17 17 17]/20);
plot(2*ones(count*(count-1)),xc31(eye(count)==0),'s','Color',[17 17 17]/20);
plot(3*ones(count*(count-1)),xc23(eye(count)==0),'v','Color',[17 17 17]/20);
plot(ones(count),diag(xc12),'bo'); plot(2*ones(count),diag(xc31),'gs'); plot(3*ones(count),diag(xc23),'rv');
xlim([0,4]); title('ratemap correlation'); xticks(1:3); xticklabels({'E1 & E2','E1 & E3','E2 & E3'});
subplot(122); hold on; plot([0.5 3.5],[0 0],'k--');

g1 = repmat({'E1 & E2'},count*(count-1),1); g2 = repmat({'E1 & E3'},count*(count-1),1);
g3 = repmat({'E2 & E3'},count*(count-1),1); g = [g1; g2; g3];
boxplot([xc12(eye(count)==0); xc31(eye(count)==0); xc23(eye(count)==0)],g,'Colors',[17 17 17]/20);
b1 = findobj(gcf,'tag','Outliers'); set(b1,'Marker','none');
g1 = repmat({'E1 & E2'},count,1); g2 = repmat({'E1 & E3'},count,1); g3 = repmat({'E2 & E3'},count,1); 
g = [g1; g2; g3];
boxplot([diag(xc12);diag(xc31);diag(xc23)],g,'Colors','k');
b2 = findobj(gcf,'tag','Outliers'); set(b2,'Marker','none');

% g1 = repmat({'E1 & E2'},count,1); g2 = repmat({'E1 & E3'},count,1); g3 = repmat({'E2 & E3'},count,1); 
% g = [g1; g2; g3];
% g1 = repmat({'E1 & E2'},count*(count-1),1); g2 = repmat({'E1 & E3'},count*(count-1),1);
% g3 = repmat({'E2 & E3'},count*(count-1),1); g = [g; g1; g2; g3];
% h1 = repmat({'Data'},3*count,1); h2 = repmat({'Ctrl'},3*count*(count-1),1);
% h = [h1; h2]; g = categorical(g);
% boxchart(g,[diag(xc12);diag(xc31);diag(xc23);xc12(eye(count)==0);xc31(eye(count)==0);xc23(eye(count)==0)],'GroupByColor',h);
% legend;

ylim([-0.2 0.32]);
[p12,h12,stats12] = ranksum(diag(xc12),xc12(eye(count)==0),'tail','right');
[p31,h31,stats31] = ranksum(diag(xc31),xc31(eye(count)==0),'tail','right');
[p23,h23,stats23] = ranksum(diag(xc23),xc23(eye(count)==0),'tail','right');
text(0.7,0.3,['p=',num2str(p12,'%.2f')]);
text(1.7,0.3,['p=',num2str(p31,'%.2f')]);
text(2.7,0.3,['p=',num2str(p23,'%.3f')]);
[p12_23,~,~] = ranksum(diag(xc23),diag(xc12),'tail','right');
[p31_23,~,~] = ranksum(diag(xc23),diag(xc31),'tail','right');
text(1.2,-0.15,['p=',num2str(p12_23,'%.2f')]);
text(2.2,-0.15,['p=',num2str(p31_23,'%.2f')]);
[c12_23,~,~] = ranksum(xc23(eye(count)==0),xc12(eye(count)==0),'tail','right');
[c31_23,~,~] = ranksum(xc23(eye(count)==0),xc31(eye(count)==0),'tail','right');
text(1.2,-0.18,['p=',num2str(c12_23,'%.2f')]);
text(2.2,-0.18,['p=',num2str(c31_23,'%.2f')]);
saveas(gcf,[figpath,'ratemap_corr_summary_a',num2str(a),'_w',num2str(w),'.png']);
%save(['ratemap_correlation_a',num2str(a),'_w',num2str(w),'.mat'],'xc12','xc31','xc23');
