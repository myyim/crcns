function [ac30,ac60,ac90,ac120,ac150,score,cor] = gridscore_interp2(ac0,rad,frad)

r = floor(size(ac0,2)/2); r1 = ceil(sqrt(2)*r);
ac1 = zeros(2*r1+1); ac1(r1-r+1:r1+r+1,r1-r+1:r1+r+1) = ac0;
[xcoor1,ycoor1] = meshgrid(-r1:r1);
[xcoor,ycoor] = meshgrid(-r:r); % coordinates of the autocorrelation grid, y by x
for j = 30:30:150
    xq = cos(j*pi/180)*xcoor-sin(j*pi/180)*ycoor;
    yq = sin(j*pi/180)*xcoor+cos(j*pi/180)*ycoor;
    acq = interp2(xcoor1,ycoor1,ac1,xq,yq);
    eval(['ac',num2str(j),' = acq;']);
end
score = nan; cor = nan;

if nargin == 3
    cor = ones(1,6);
    ac0_vec = ac0(logical((xcoor.^2+ycoor.^2>=frad^2).*(xcoor.^2+ycoor.^2<=(2*rad-frad)^2)));
    for j = 2:6
        eval(['ac_vec = ac',num2str((j-1)*30),';']);
        ac_vec = ac_vec(logical((xcoor.^2+ycoor.^2>=frad^2).*(xcoor.^2+ycoor.^2<=(2*rad-frad)^2)));
        xcor = corrcoef(ac0_vec,ac_vec);
        cor(j) = xcor(1,2);
    end
    score = min(cor(3:2:5))-max(cor(2:2:6));
end
end