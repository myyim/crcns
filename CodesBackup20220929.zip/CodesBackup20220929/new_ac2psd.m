function psd = ac2psd(ac)
s = size(ac,1); % assume that ac is a square matrix
r = (s-1)/2;
temp = abs(fft2(ac)).^2; 
% temp = vertcat(zeros(1,2*r+1),temp); temp = horzcat(zeros(2*r+2,1),temp); % zero-padding
psd = temp*0; 
psd(r+1:end,r+1:end) = temp(1:r+1,1:r+1);
psd(1:r,r+1:end) = temp(r+2:end,1:r+1);
psd(r+1:end,1:r) = temp(1:r+1,r+2:end);
psd(1:r,1:r) = temp(r+2:end,r+2:end);
psd(r+1,r+1) = 0;
end