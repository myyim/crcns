close all; clear all;

%% parameters
rm = 75; % outer radius
rmin = 60; % inner radius
rad = (rm+rmin)/2; % center radius
lam = 45;   % grid spacing
psi = 0.26; % grid orientation
rng(1); clist = randi(lam,[18,2]);  % grid center of 20 cells
c1 = [8,23]; % grid center
c2 = [3,7]; % grid center
thre = 0.2;   % for bump detection
cscale = 0.6; cscale2 = 0.2; % fraction of max as the upper limit of colorbar
[y,x] = meshgrid(-rm:rm,-rm:rm);    % coordinates of arena/track
mask = ones(2*rm+1,2*rm+1); mask(x.^2+y.^2<rmin^2) = 0; mask(x.^2+y.^2>rm^2) = 0; % for the track

%% codes needed
codepath = './codes/'; % update your path here!
allpath = genpath(codepath); addpath(allpath);
% env_patch, model_rmap_ac, imagesc_env, model_shuffled_rmap_ac,
% shuffled_identical_circular_fields, gridcell

%% figure
figure; set(gcf,'Position',[0 0 900 1000]);
%subplot(551); env_patch(1); text(-100,85,'1 cell'); axis off; % title('2D env');
ax = subplot(552);[rmap,ac] = model_rmap_ac(y,x,lam,psi,c1,0,rm); imagesc_env(rmap,-rm:rm,-rm:rm,2); 
ax.YLabel.Visible = 'on'; ylabel('Cell 1','Rotation',0); title('Rate Map');
subplot(553); imagesc_env(ac,-2*rm:2*rm,-2*rm:2*rm); colormap(jet(256)); title('Autocorrelation');
caxis([0 max(max(ac))*cscale]); %xlim([-rm rm]); ylim([-rm rm]);
subplot(554);[rmap_s,ac_s] = model_shuffled_rmap_ac(y,x,lam,psi,c1,0,rm,thre,randi(1000));
imagesc_env(rmap_s,-rm:rm,-rm:rm,2); title('Shuffled Rate Map');
subplot(555); imagesc_env(ac_s,-2*rm:2*rm,-2*rm:2*rm); title('Autocorrelation');
caxis([0 max(max(ac_s))*cscale]);

%subplot(556); env_patch(2); axis off; text(-100,85,'1 cell'); 
ax = subplot(557); rmap(x.^2+y.^2<rmin^2) = 0; imagesc_env(rmap,-rm:rm,-rm:rm,2); %title('cell 1');
ax.YLabel.Visible = 'on'; ylabel(["Annulus","Cell 1"],'Rotation',0);
subplot(558); ac = xcorr2(rmap); imagesc_env(ac,-2*rm:2*rm,-2*rm:2*rm); 
caxis([0 max(max(ac))*cscale]); acsum = ac;
subplot(559); rmap_s(x.^2+y.^2<rmin^2) = 0; imagesc_env(rmap_s,-rm:rm,-rm:rm,2);
subplot(5,5,10); ac_s = xcorr2(rmap_s);imagesc_env(ac_s,-2*rm:2*rm,-2*rm:2*rm);
caxis([0 max(max(ac_s))*cscale]); acsum_s = ac_s;

%subplot(5,5,11); env_patch(2); text(-100,85,'1 cell'); axis off;
ax = subplot(5,5,12); [rmap,~] = model_rmap_ac(y,x,lam,psi,c2,0,rm); 
rmap(x.^2+y.^2<rmin^2) = 0; imagesc_env(rmap,-rm:rm,-rm:rm,2); %title('cell 2');
ax.YLabel.Visible = 'on'; ylabel(["Annulus","Cell 2"],'Rotation',0);
subplot(5,5,13); ac = xcorr2(rmap); imagesc_env(ac,-2*rm:2*rm,-2*rm:2*rm); 
caxis([0 max(max(ac))*cscale]); acsum = acsum + ac;
subplot(5,5,14); [rmap_s,~] = model_shuffled_rmap_ac(y,x,lam,psi,c2,0,rm,thre,randi(1000));
rmap_s(x.^2+y.^2<rmin^2) = 0; imagesc_env(rmap_s,-rm:rm,-rm:rm,2);
subplot(5,5,15); ac_s = xcorr2(rmap_s); imagesc_env(ac_s,-2*rm:2*rm,-2*rm:2*rm);
caxis([0 max(max(ac_s))*cscale]); acsum_s = acsum_s + ac_s;

%subplot(5,5,16); hold on; env_patch(2); text(-100,85,'20 cells'); axis off;
for j = 3:20
    [rmap,~] = model_rmap_ac(y,x,lam,psi,clist(j-2,:),0,rm); rmap(x.^2+y.^2<rmin^2) = 0; 
    ac = xcorr2(rmap); acsum = acsum + ac;
    [rmap_s,~] = model_shuffled_rmap_ac(y,x,lam,psi,clist(j-2,:),0,rm,thre,randi(1000)); rmap_s(x.^2+y.^2<rmin^2) = 0;
    ac_s = xcorr2(rmap_s); acsum_s = acsum_s + ac_s;
end
ax = subplot(5,5,17); axis off;
ax.YLabel.Visible = 'on'; ylabel(["Annulus","Population"],'Rotation',0);
subplot(5,5,19); imagesc_env(acsum,-2*rm:2*rm,-2*rm:2*rm);
caxis([0 max(max(acsum))*cscale2]); title('Autocorrelation')
subplot(5,5,20); imagesc_env(acsum_s,-2*rm:2*rm,-2*rm:2*rm);
caxis([0 max(max(acsum_s))*cscale2]); title('Autocorrelation (Shuffled)')

ang = psi:pi/3:2*pi; t = 0:0.1:2*pi+0.1; t2 = psi:0.01:psi+pi/6;
subplot(5,5,22); hold on; plot(lam*cos(t),lam*sin(t),'Color',[17 17 17]/20);
plot(sqrt(3)*lam*cos(t),sqrt(3)*lam*sin(t),'Color',[17 17 17]/20);
plot([0,lam*cos(psi)],[0,lam*sin(psi)],'k','LineWidth',2); 
plot([0,sqrt(3)*lam*cos(psi+pi/6)],[0,sqrt(3)*lam*sin(psi+pi/6)],'k','LineWidth',2); 
plot(lam*cos(t2),lam*sin(t2),'k');
plot([0,lam*cos(ang),sqrt(3)*lam*cos(ang+pi/6)],[0,lam*sin(ang),sqrt(3)*lam*sin(ang+pi/6)],'r.','MarkerSize',12);
text(lam,4*lam/5,'30^\circ'); text(lam/3,-lam/6,'\lambda'); 
text(0,1.6*lam,'$\sqrt{3}\lambda$','interpreter','latex');
axis equal; axis off; title('Hexagonal');
subplot(5,5,23); hold on; imagesc_env(acsum,-2*rm:2*rm,-2*rm:2*rm);
plot(lam*cos(t),lam*sin(t),'k'); plot(sqrt(3)*lam*cos(t),sqrt(3)*lam*sin(t),'k'); xlabel('lag (cm)');
caxis([0 max(max(acsum))*cscale2]); xlim(1.2*[-rm rm]); ylim(1.2*[-rm rm]); title('Zoom-in');
subplot(5,5,24); rmap(mask==1) = 1; imagesc_env(rmap,-rm:rm,-rm:rm,2); title('Track');
subplot(5,5,25); ac = xcorr2(rmap); imagesc_env(ac,-2*rm:2*rm,-2*rm:2*rm); 
caxis([0 max(max(ac))*cscale2*0.85]); title('Autocorrelation'); xlabel('lag (cm)');

set(findall(gcf,'-property','FontSize'),'FontSize',10);
set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,...
    'PaperPosition',[0 0 screenposition(3:4)],...
    'PaperSize',[screenposition(3:4)]);
print -dpdf fig1_theory