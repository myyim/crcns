function [rmap,spk,dur] = smoothratemap_github(trackpos,trackf,sig,mask,theta)
% 
if nargin < 3
    sig = 5;    % standard deviation of gaussian kernel
end
cutoff = sig; % cutoff of the gaussian kernel
if nargin < 4
    rmax = ceil(max(sqrt(trackpos(:,1).^2+trackpos(:,2).^2)));
    mask = ones(2*rmax+1,2*rmax+1); % minimum environment containing all data
elseif mod(size(mask,1),2) == 0 || mod(size(mask,2),2) == 0
    error('Dimensions of the mask should be an odd number')
end
if nargin < 5   
    theta = 0;  % counterclockwise rotation
end
if theta ~= 0
    trackpos = trackpos*rotation_matrix(-theta); 
    % minus sign for counterclockwise wuth multiplication from the right
    trackf = trackf*rotation_matrix(-theta);
end
% convolution of every point of locations and spikes
xm = floor(size(mask,1)/2); % the mask matrix can be rectangular
ym = floor(size(mask,2)/2);
dur = histcounts2(trackpos(:,1),trackpos(:,2),-xm:2.5:xm+1,-ym:2.5:ym+1);    % time spent on each bin in 2D
spk = histcounts2(trackf(:,1),trackf(:,2),-xm:2.5:xm+1,-ym:2.5:ym+1); 
rmap = spk./(dur*0.04); % dt=0.04; normalization=2*pi*sig^2
mask = isnan(rmap);
rmap(mask) = 0;
rmap = conv2(rmap,gauss2d(5,5,2.5),'same');
rmap(mask) = nan;
end
