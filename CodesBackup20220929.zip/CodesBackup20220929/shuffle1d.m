function acs = shuffle1d(ac)

end