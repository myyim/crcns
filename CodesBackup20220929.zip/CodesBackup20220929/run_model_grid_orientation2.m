close all; clear all;
figpath = './figures/models/';
%addpath('models');
xm = 75; ym = 75; % the size is 2rx X 2ry
dmax = max([xm ym]);
lam = 41;   % grid period
psi = 0.26; %0.31; % grid orientation
c = [8,19]; % grid center
[y,x] = meshgrid(-ym:ym,-xm:xm);    
[ycoor,xcoor] = meshgrid(-2*ym:2*ym,-2*xm:2*xm);

figure(1); set(gcf,'Position',[0 0 1100 600]);
sgtitle(['\lambda=',num2str(lam),'; \psi=',num2str(psi),'; c=[',num2str(c(1)),',',num2str(c(2)),']']);
% First row: 2D
thre = 0;
subplot(341); rmap = gridcell(y,x,1,lam,psi,c); rmap(x.^2+y.^2>75^2) = 0;
imagesc_env(rmap,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title(['ratemap: 2D']);
ac0 = xcorr2(rmap);
[rad,frad,ac0r,deriv] = max_activity_ring(ac0);
rmap = gridcell(y,x,1,lam,psi+pi/3,rotation_matrix(pi/3)*c',thre); rmap(x.^2+y.^2>75^2) = 0;
ac60 = xcorr2(rmap); ac60(xcoor.^2+ycoor.^2<frad^2) = 0; ac60(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0;
rmap = gridcell(y,x,1,lam,psi+2*pi/3,rotation_matrix(2*pi/3)*c',thre); rmap(x.^2+y.^2>75^2) = 0;
ac120 = xcorr2(rmap); ac120(xcoor.^2+ycoor.^2<frad^2) = 0; ac120(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0;
rmap = gridcell(y,x,1,lam,psi+pi/6,rotation_matrix(pi/6)*c',thre); rmap(x.^2+y.^2>75^2) = 0;
ac30 = xcorr2(rmap); ac30(xcoor.^2+ycoor.^2<frad^2) = 0; ac30(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0;
rmap = gridcell(y,x,1,lam,psi+pi/2,rotation_matrix(pi/2)*c',thre); rmap(x.^2+y.^2>75^2) = 0;
ac90 = xcorr2(rmap); ac90(xcoor.^2+ycoor.^2<frad^2) = 0; ac90(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0;
rmap = gridcell(y,x,1,lam,psi+5*pi/6,rotation_matrix(5*pi/6)*c',thre); rmap(x.^2+y.^2>75^2) = 0;
ac150 = xcorr2(rmap); ac150(xcoor.^2+ycoor.^2<frad^2) = 0; ac150(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0;
[score,cor] = gridness(ac0,ac30,ac60,ac90,ac120,ac150,rad,frad);
ori = gridorientation(ac0,rad,frad);
subplot(342); hold on;
imagesc_env(ac0,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; caxis([0 max(ac0(x.^2+y.^2>=frad^2))]); title('autocorr at 0^{\circ}'); % the original AC
ac0(xcoor.^2+ycoor.^2<frad^2) = 0; ac0(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0; xlim([-xm xm]); ylim([-ym ym]);
plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
plot(frad*cos(0:0.01:2*pi+0.01),frad*sin(0:0.01:2*pi+0.01),'w');
plot((2*rad-frad)*cos(0:0.01:2*pi+0.01),(2*rad-frad)*sin(0:0.01:2*pi+0.01),'w');
subplot(343); hold on; 
plot([0,dmax],[0,0],'k:'); plot(ac0r,'k');
plot(rad*ones(1,2),[0,ac0r(rad)],'r'); plot(frad*ones(1,2),[0,ac0r(frad)],'b');
%plot(71*ones(1,2),[0,ac0r(71)],'r');
xlabel('radius'); ylabel('mean autocorr'); xlim([0 2*dmax]); 
ylim([0 max(ac0r(20:end))*1.5]);
%title([num2str(deriv),': \color{blue}',num2str(frad),'; \color{red}',num2str(rad),', 68\color{black}; ',num2str(round(ori)),'^{\circ}; g:',num2str(score,2)]);
title([num2str(deriv),': \color{blue}',num2str(frad),'; \color{red}',num2str(rad),'\color{black}; ',num2str(round(ori)),'^{\circ}']);
subplot(344); plot(0:30:150,cor,'ko-'); title(['gridness = ',num2str(score,3)]);

% Second row: circular track
rmap = gridcell(y,x,1,lam,psi,c,thre);
rmap(x.^2+y.^2<60^2) = 0; rmap(x.^2+y.^2>75^2) = 0; ac0 = xcorr2(rmap);
[rad,frad,ac0r,deriv] = max_activity_ring(ac0);
subplot(345); imagesc_env(rmap,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('ratemap: track');
rmap = gridcell(y,x,1,lam,psi+pi/3,rotation_matrix(pi/3)*c',thre); rmap(x.^2+y.^2<60^2) = 0; rmap(x.^2+y.^2>75^2) = 0;
ac60 = xcorr2(rmap); ac60(xcoor.^2+ycoor.^2<frad^2) = 0; ac60(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0;
rmap = gridcell(y,x,1,lam,psi+2*pi/3,rotation_matrix(2*pi/3)*c',thre); rmap(x.^2+y.^2<60^2) = 0; rmap(x.^2+y.^2>75^2) = 0;
ac120 = xcorr2(rmap); ac120(xcoor.^2+ycoor.^2<frad^2) = 0; ac120(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0;
rmap = gridcell(y,x,1,lam,psi+pi/6,rotation_matrix(pi/6)*c',thre); rmap(x.^2+y.^2<60^2) = 0; rmap(x.^2+y.^2>75^2) = 0;
ac30 = xcorr2(rmap); ac30(xcoor.^2+ycoor.^2<frad^2) = 0; ac30(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0;
rmap = gridcell(y,x,1,lam,psi+pi/2,rotation_matrix(pi/2)*c',thre); rmap(x.^2+y.^2<60^2) = 0; rmap(x.^2+y.^2>75^2) = 0;
ac90 = xcorr2(rmap); ac90(xcoor.^2+ycoor.^2<frad^2) = 0; ac90(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0;
rmap = gridcell(y,x,1,lam,psi+5*pi/6,rotation_matrix(5*pi/6)*c',thre); rmap(x.^2+y.^2<60^2) = 0; rmap(x.^2+y.^2>75^2) = 0;
ac150 = xcorr2(rmap); ac150(xcoor.^2+ycoor.^2<frad^2) = 0; ac150(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0;
[score,cor] = gridness(ac0,ac30,ac60,ac90,ac120,ac150,rad,frad);
ori = gridorientation(ac0,rad,frad);
subplot(346); hold on; ac0(xcoor.^2+ycoor.^2<frad^2) = 0; imagesc_env(ac0,-2*xm:2*xm,-2*ym:2*ym);
ac0(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0;
axis image; colormap(jet(256)); colorbar; caxis([0 max(ac0(x.^2+y.^2>=frad^2))]); title('autocorr at 0^{\circ}'); % the original AC
xlim([-xm xm]); ylim([-ym ym]);
plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
plot(frad*cos(0:0.01:2*pi+0.01),frad*sin(0:0.01:2*pi+0.01),'w');
plot((2*rad-frad)*cos(0:0.01:2*pi+0.01),(2*rad-frad)*sin(0:0.01:2*pi+0.01),'w');
subplot(347); hold on; 
plot([0,dmax],[0,0],'k:'); plot(ac0r,'k');
plot(rad*ones(1,2),[0,ac0r(rad)],'r'); plot(frad*ones(1,2),[0,ac0r(frad)],'b');
%plot(67*ones(1,2),[0,ac0r(67)],'r');
xlabel('radius'); ylabel('mean autocorr'); xlim([0 2*dmax]); ylim([0 max(ac0r(20:end))*1.5]);
title([num2str(deriv),': \color{blue}',num2str(frad),'; \color{red}',num2str(rad),'\color{black}; ',num2str(round(ori)),'^{\circ}']);
subplot(348); plot(0:30:150,cor,'ko-'); title(['gridness = ',num2str(score)]);

% Third row: thinner circular track
rmap = gridcell(y,x,1,lam,psi,c,thre);
rmap(x.^2+y.^2<64^2) = 0; rmap(x.^2+y.^2>71^2) = 0; ac0 = xcorr2(rmap);
[rad,frad,ac0r,deriv] = max_activity_ring(ac0);
subplot(349); imagesc_env(rmap,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('ratemap: thin track');
rmap = gridcell(y,x,1,lam,psi+pi/3,rotation_matrix(pi/3)*c',thre); rmap(x.^2+y.^2<64^2) = 0; rmap(x.^2+y.^2>71^2) = 0;
ac60 = xcorr2(rmap); ac60(xcoor.^2+ycoor.^2<frad^2) = 0; ac60(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0;
rmap = gridcell(y,x,1,lam,psi+2*pi/3,rotation_matrix(2*pi/3)*c',thre); rmap(x.^2+y.^2<64^2) = 0; rmap(x.^2+y.^2>71^2) = 0;
ac120 = xcorr2(rmap); ac120(xcoor.^2+ycoor.^2<frad^2) = 0; ac120(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0;
rmap = gridcell(y,x,1,lam,psi+pi/6,rotation_matrix(pi/6)*c',thre); rmap(x.^2+y.^2<64^2) = 0; rmap(x.^2+y.^2>71^2) = 0;
ac30 = xcorr2(rmap); ac30(xcoor.^2+ycoor.^2<frad^2) = 0; ac30(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0;
rmap = gridcell(y,x,1,lam,psi+pi/2,rotation_matrix(pi/2)*c',thre); rmap(x.^2+y.^2<64^2) = 0; rmap(x.^2+y.^2>71^2) = 0;
ac90 = xcorr2(rmap); ac90(xcoor.^2+ycoor.^2<frad^2) = 0; ac90(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0;
rmap = gridcell(y,x,1,lam,psi+5*pi/6,rotation_matrix(5*pi/6)*c',thre); rmap(x.^2+y.^2<64^2) = 0; rmap(x.^2+y.^2>71^2) = 0;
ac150 = xcorr2(rmap); ac150(xcoor.^2+ycoor.^2<frad^2) = 0; ac150(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0;
[score,cor] = gridness(ac0,ac30,ac60,ac90,ac120,ac150,rad,frad);
ori = gridorientation(ac0,rad,frad);
subplot(3,4,10); hold on; ac0(xcoor.^2+ycoor.^2<frad^2) = 0; imagesc_env(ac0,-2*xm:2*xm,-2*ym:2*ym);
ac0(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0;
axis image; colormap(jet(256)); colorbar; caxis([0 max(ac0(x.^2+y.^2>=frad^2))]); title('autocorr at 0^{\circ}'); % the original AC
xlim([-xm xm]); ylim([-ym ym]);
plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
plot(frad*cos(0:0.01:2*pi+0.01),frad*sin(0:0.01:2*pi+0.01),'w');
plot((2*rad-frad)*cos(0:0.01:2*pi+0.01),(2*rad-frad)*sin(0:0.01:2*pi+0.01),'w');
subplot(3,4,11); hold on; 
plot([0,dmax],[0,0],'k:'); plot(ac0r,'k');
plot(rad*ones(1,2),[0,ac0r(rad)],'r'); plot(frad*ones(1,2),[0,ac0r(frad)],'b');
%plot(67*ones(1,2),[0,ac0r(67)],'r');
xlabel('radius'); ylabel('mean autocorr'); xlim([0 2*dmax]); ylim([0 max(ac0r(20:end))*1.5]);
title([num2str(deriv),': \color{blue}',num2str(frad),'; \color{red}',num2str(rad),'\color{black}; ',num2str(round(ori)),'^{\circ}']);
subplot(3,4,12); plot(0:30:150,cor,'ko-'); title(['gridness = ',num2str(score)]);
%saveas(gcf,[figpath,'gridscore_ratemap_extract',num2str(lam),'ori',num2str(psi),'c=[',num2str(c(1)),',',num2str(c(2)),'].png']);