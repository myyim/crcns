close all; clear all;
%% 6 animals
an = {'MEC2','MEC1','MEC3','MEC4','1RS_','2BS_'};
sig = 3;

%% which datapath dp?
% 1: Large Arena matlab files (all 64 cells)
% 2: Large Circular track light matlab files (all 64 cells)
% 3: Large Circular track dark matlab files (35 cells)
% 4: Small Arena matlab files (29 cells)
% 5: Small Circular track matlab files (29 cells)

%% load paths and data
datapath = './Jacob_Sargolini_All_Environments/'; % update your path here!
allpath = genpath(datapath);
addpath(allpath);
addpath('./gridness/');
load('./CellsID.mat');
load('./fitcirculartrack.mat'); % load data pall (fitted parameters)
figpath = './figures/Jacob_Sargolini_gridness_circular_light/';
if ~exist(figpath)
    mkdir(figpath);
end
addpath(figpath);

%% create a struct for storing all the autocorrelations
ac = struct('A1',{},'A2',{},'A3',{},'A4',{},'A5',{},'A6',{});
for j = 1:6
    eval(['ac(1).A',num2str(j),'= struct(''E1'',{},''E2'',{},''E3'',{},''E4'',{},''E5'',{});']);
    for k = 1:5
        eval(['ac(1).A',num2str(j),'(1).E',num2str(k),'= struct(''R0'',{},''R30'',{},''R60'',{},''R90'',{},''R120'',{},''R150'',{});']);
    end
end

for dp = 1:5
    disp(['dp = ',num2str(dp)]);
    if dp == 1
        %addpath([datapath,'Large Arena matlab files/']);
        filename = 'CellsID.Arena';
    elseif dp == 2
        %addpath([datapath,'Large Circular track light matlab files/']);
        filename = 'CellsID.CircularTrackLight';
    elseif dp == 3
        %addpath([datapath,'Large Circular track dark matlab files/']);
        filename = 'CellsID.CiruclarTrackDark';
    elseif dp == 4
        %addpath([datapath,'Small Arena matlab files/']);
        filename = 'CellsID.SmallArena';
    elseif dp == 5
        %addpath([datapath,'Small Circular track matlab files/']);
        filename = 'CellsID.SmallCircularTrack';
    end
    for j = 1:64
        eval(['fname = ',filename,'(j);']);
        if fname == ""
            continue
        end
        disp(['cell = ',num2str(j)]);
        tID = CellsID.tetrode(j);
        cID = CellsID.cell(j);
        fname = char(fname);
        if fname(1) == 'M'
            if dp == 1
                fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];          
            else
                fname = [fname(1:11),'_t',num2str(tID),'_c',num2str(cID)];
            end
        else
            fname = [fname(1:16),'_t',num2str(tID),'_c',num2str(cID)];
        end
        aid = find(strcmp(fname(1:4),an)==1);
        [trackpos,trackf,~] = getdata_sargolini(fname,tID,cID,1,pall(j,:)); % pall stores the fitted parameters
        [ac0,ac30,ac60,ac90,ac120,ac150] = data2ac(trackpos,trackf,sig,300,0);
        disp(size(ac0));
        for k = 0:5
            eval(['ac.A',num2str(aid),'.E',num2str(dp),'(j).R',num2str(k*30),'= ac',num2str(k*30),';']);
        end
    %     s = size(ac0); id = (s-301)/2;
    %     ac0 = ac0(id(1)+1:s(1)-id(1),id(2)+1:s(2)-id(2));
    %     ac30 = ac30(id(1)+1:s(1)-id(1),id(2)+1:s(2)-id(2));
    %     ac60 = ac60(id(1)+1:s(1)-id(1),id(2)+1:s(2)-id(2));
    %     ac90 = ac90(id(1)+1:s(1)-id(1),id(2)+1:s(2)-id(2));
    %     ac120 = ac120(id(1)+1:s(1)-id(1),id(2)+1:s(2)-id(2));
    %     ac150 = ac150(id(1)+1:s(1)-id(1),id(2)+1:s(2)-id(2));
    %     ac_array(aid,:,:,:) = ac_array(aid,:,:,:) + [ac0;ac30;ac60;ac90;ac120;ac150];
    end
end
save(['ac_struct.mat'],'ac');

% for j = 1:6
%     figure; set(gcf,'Position',[0 0 1100 700]);
%     subplot(344); hold on; 
%     plot([0,150],[0,0],'k:'); plot(ac0r,'k'); plot(1.5:150,dac0r,'Color',[0.8 0.8 0.8]); 
%     plot(rad*ones(1,2),[0,ac0r(rad)],'r'); plot(frad*ones(1,2),[0,ac0r(frad)],'b');
%     xlabel('radius'); ylabel('mean autocorr along a circle'); xlim([0 150]); 
%     if deriv == 1
%         title(['1st: \color{blue}',num2str(frad),'; \color{red}',num2str(rad)]);
%     elseif deriv == 2
%         title(['2nd: \color{blue}',num2str(frad),'; \color{red}',num2str(rad)]);
%     else
%         title(['Assigned: \color{blue}',num2str(frad),'; \color{red}',num2str(rad)]);
%     end
%     subplot(345); hold on;
%     imagesc_env(ac,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; caxis([0 max(ac(xcoor.^2+ycoor.^2>=frad^2))]); title('autocorr at 0^{\circ}'); % the original AC
%     plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
%     plot(frad*cos(0:0.01:2*pi+0.01),frad*sin(0:0.01:2*pi+0.01),'w');
%     plot((2*rad-frad)*cos(0:0.01:2*pi+0.01),(2*rad-frad)*sin(0:0.01:2*pi+0.01),'w');
%     subplot(346); hold on; imagesc_env(ac0,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 0^{\circ}'); % the original AC
%     subplot(347); hold on; imagesc_env(ac60,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 60^{\circ}');
%     subplot(348); hold on; imagesc_env(ac120,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 120^{\circ}'); 
%     subplot(349); hold on; imagesc_env(ac30,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 30^{\circ}');
%     subplot(3,4,10); hold on; imagesc_env(ac90,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 90^{\circ}'); 
%     subplot(3,4,11); hold on; imagesc_env(ac150,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; title('autocorr at 150^{\circ}'); 
%     subplot(3,4,12); plot(0:30:150,cor,'ko-'); title(['gridness = ',num2str(score)]);
%     sgtitle(an(j));
%     saveas(gcf,[figpath,'cell',num2str(j),'gridscore','.png']);
% end
