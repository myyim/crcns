clear all; close all;
%% Which datapath?
% 1: Large Arena matlab files (all 64 cells)
% 2: Large Circular track light matlab files (all 64 cells)
% 3: Large Circular track dark matlab files (35 cells)
% 4: Small Arena matlab files (29 cells)
% 5: Small Circular track matlab files (29 cells)
dp = 5;
coord = 1; %0: untouched/ 1: cartesian with param (default)/ 2: cartesian autocenter

%% set path and get directories
datapath = './Jacob_Sargolini_All_Environments/'; % update your path here!
allpath = genpath(datapath);
addpath(allpath);
if dp == 1
    %addpath([datapath,'Large Arena matlab files/']);
    filename = 'CellsID.Arena';
elseif dp == 2
    %addpath([datapath,'Large Circular track light matlab files/']);
    filename = 'CellsID.CircularTrackLight';
elseif dp == 3
    %addpath([datapath,'Large Circular track dark matlab files/']);
    filename = 'CellsID.CiruclarTrackDark';
elseif dp == 4
    %addpath([datapath,'Small Arena matlab files/']);
    filename = 'CellsID.SmallArena';
elseif dp == 5
    %addpath([datapath,'Small Circular track matlab files/']);
    filename = 'CellsID.SmallCircularTrack';
end
figpath = './figures/Jacob_Sargolini_ratemap/';
if ~exist(figpath)
    mkdir(figpath);
end
addpath(figpath);
load('./CellsID.mat');
load('./fitcirculartrack.mat');

%% loop over all cells
count = 0;
for j = 1:64    % filenames
    eval(['fname = ',filename,'(j);']);
    if fname == ""
        continue
    end
    tID = CellsID.tetrode(j);
    cID = CellsID.cell(j);
    count = count + 1;
    if mod(count,4) == 1
        figure;
        set(gcf,'Position',[0 0 1000 750]);
    end
    fname = char(fname);
    if fname(1) == 'M'
        if dp == 1
            fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];          
        else
            fname = [fname(1:11),'_t',num2str(tID),'_c',num2str(cID)];
        end
    else
        fname = [fname(1:16),'_t',num2str(tID),'_c',num2str(cID)];
    end
    [trackpos,trackf,~] = getdata_sargolini(fname,tID,cID,coord,pall(j,:));
    subplot(4,4,4*mod(count-1,4)+1); hold on; axis image;
    plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
    plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2);
    %set(gca,'visible','off');
    title(fname,'Interpreter', 'none');
    subplot(4,4,4*mod(count-1,4)+2); hold on; axis image;
    %midpos = min(trackpos)+(max(trackpos)-min(trackpos))/2; % to be
    %removed
    [rmap,~,~] = smoothratemap_replicate(trackpos,trackf);
    rmap_max = [floor(size(rmap,1)/2), floor(size(rmap,2)/2)];
    alpha = ones(size(rmap')); alpha(isnan(rmap')) = 0;
    imagesc(-rmap_max:rmap_max,-rmap_max:rmap_max,rmap','AlphaData',alpha); 
    colorbar; colormap(jet(256)); caxis([0 max(rmap,[],'all')]);
    set(gca,'color',[1 1 1]); set(gca,'YDir','normal'); set(gca,'visible','off'); 
    if exist([fname,'.png'], 'file') == 2
        subplot(4,2,2*mod(count-1,4)+2);
        img = imread([fname,'.png']);
        imshow(img);
    end
    if mod(count,4) == 0
        saveas(gcf,[figpath,'env',num2str(dp),'ratemap',num2str(count/4),'.png']);
    end
end 
saveas(gcf,[figpath,'env',num2str(dp),'ratemap',num2str(ceil(count/4)),'.png']);