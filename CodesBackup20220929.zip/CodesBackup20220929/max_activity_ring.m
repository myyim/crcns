function [rad,frad,ac0r,deriv] = max_activity_ring(ac,rad_min,rad_max)

% size of ac
[xm,ym] = size(ac); xm = (xm-1)/2; ym = (ym-1)/2; d = min([xm,ym]);

% define parameters if not specified
if nargin < 3
    rad_max = d;
end
if nargin < 2
    rad_min = 25;
end
    
% Locate the ring in ac0 with max activity
[ycoor,xcoor] = meshgrid(-ym:ym,-xm:xm); % coordinates of the grid, y by x
topright = sqrt((xcoor+0.5).^2+(ycoor+0.5).^2);
topleft = sqrt((xcoor-0.5).^2+(ycoor+0.5).^2);
bottomleft = sqrt((xcoor-0.5).^2+(ycoor-0.5).^2);
bottomright = sqrt((xcoor+0.5).^2+(ycoor-0.5).^2);
rtensor(:,:,1) = topright; rtensor(:,:,2) = topleft; rtensor(:,:,3) = bottomleft; rtensor(:,:,4) = bottomright;
rmin = min(rtensor,[],3); rmax = max(rtensor,[],3);
ac0r = zeros(1,d);  % average autocorrelation along a circle (index = radius) 
for rad = 1:d
    ringon = (rad>=rmin).*(rad<=rmax); % define the bins on the circle
    ac0r(rad) = sum(ac(ringon==1))/sum(sum(ringon==1));
end
dac0r = ac0r(2:end)-ac0r(1:end-1); % difference
dac0r(1:rad_min-1) = 0; dac0r(rad_max+1:end) = 0;

npt = 3; rad = 0;
while npt > 0 && rad < rad_min
    sgn = (dac0r(1:end-1)>0).*(dac0r(2:end)<0); % one point, less strict 
    if npt == 2
        sgn = [0 dac0r(1:end-2)>0].*sgn.*[dac0r(3:end)<0 0]; % two points
    elseif npt == 3
        sgn = [0 0 dac0r(1:end-3)>0].*sgn.*[dac0r(4:end)<0 0 0]; % three points, stricter
    end
    if sum(sgn) ~= 0   
        rad = find(sgn==1); rad = rad(1)+1;   % radius of the circle
        npt_min = 3;
        frad  = rad;
        while npt_min > 0 && rad-frad < 15
            sgn = (dac0r(1:end-1)<0).*(dac0r(2:end)>0); % one point, find the min
            if npt_min == 2
                sgn = [0 dac0r(1:end-2)<0].*sgn.*[dac0r(3:end)>0 0]; % find the min
            elseif npt_min == 3
                sgn = [0 0 dac0r(1:end-3)<0].*sgn.*[dac0r(4:end)>0 0 0]; % find the min
            end
            if sum(sgn) ~= 0
                frad = find(sgn==1); frad = frad(1);   % local minimum
            end
            npt_min = npt_min - 1;
        end
        if rad-frad < 15
            frad = rad-15;
        end
    end
    if sum(sgn) == 0 || rad < rad_min
        npt = npt - 1;
    end
end

% The radius with max average autocorrelation or with min decrease in
% autocorrelation in case of no max
% sgn = [0 dac0r(1:end-2)>=0].*(dac0r(1:end-1)>=0).*(dac0r(2:end)<0).*[dac0r(3:end)<0 0];
% two points with positive slope followed by another two with negative
% slope - this give a local maximum
%sgn = (dac0r(1:end-1)>=0).*(dac0r(2:end)<0); % one point instead of two, less strict 
% deriv = 1; rad = 0;
% if sum(sgn) ~= 0   
%     rad = find(sgn==1); rad = rad(1)+1;   % radius of the circle (first order difference)
%     sgn = [0 dac0r(1:end-2)<=0].*(dac0r(1:end-1)<=0).*(dac0r(2:end)>0).*[dac0r(3:end)>0 0];
%     if sum(sgn) == 0
%         frad = rad-15; % when there is no local minimum
%     else
%         frad = find(sgn==1); frad = frad(1);   % local minimum
%         if rad-frad < 15
%             frad = rad-15;
%         end
%     end
% else
%     sgn = (dac0r(1:end-1)>=0).*(dac0r(2:end)<0); % one point instead of two, less strict 
%     dac0r = conv(dac0r,ones(1,3)/3,'same');
%     sgn = [0 dac0r(1:end-2)>=0].*(dac0r(1:end-1)>=0).*(dac0r(2:end)<0).*[dac0r(3:end)<0 0];
%     if sum(sgn) ~= 0 
%         rad = find(sgn==1); rad = rad(1)+1;   % radius of the circle (first order difference)
%         sgn = [0 dac0r(1:end-2)<=0].*(dac0r(1:end-1)<=0).*(dac0r(2:end)>0).*[dac0r(3:end)>0 0];
%         if sum(sgn) == 0
%             frad = rad-15; % when there is no local minimum
%         else
%             frad = find(sgn==1); frad = frad(1);   % local minimum
%             if rad-frad < 15
%                 frad = rad-15;
%             end
%         end           
%     end
%     ddac0r = dac0r(2:end)-dac0r(1:end-1); % difference of difference
%     sgn = [0 ddac0r(1:end-2)>=0].*(ddac0r(1:end-1)>=0).*(ddac0r(2:end)<0).*[ddac0r(3:end)<0 0]; % 2 points
%     %sgn = (ddac0r(1:end-1)>=0).*(ddac0r(2:end)<0); % 1 point
%     if sum(sgn) == 0
%         rad = 0;    % will be assigned
%     else
%         %rad = find(sgn==1); rad = rad(1)+2;   % radius of the circle (second order difference) 
%         %frad = rad-10; %ceil(rad/2);         % field size
%         [~,rad] = min(ddac0r(10:end)); rad = rad + 12; 
%         [~,frad] = max(ddac0r(10:end)); frad = frad + 12; 
%         %deriv = 2;
%     end
%    disp(rad);
%    figure(10); hold on; plot(dac0r); plot(ddac0r);
% end
if rad < 25 % assigned values
    rad = 40;
    frad = 25;
    deriv = 0;
else
    deriv = npt;
end
end