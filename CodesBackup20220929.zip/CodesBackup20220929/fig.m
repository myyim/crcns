close all; clear all;

% parameters for figure 1
xm = 75; ym = 75; % the size is 2rx X 2ry
rmin = 60; % inner radius
rad = (xm+rmin)/2; % center radius
lam = 45;   % grid period
psi = 0.26; % grid orientation
clist = randi(lam,[18,2]);  % grid center of 20 cells
c1 = [3,7]; % grid center
c2 = [8,23]; % grid center
thre = 0.2;   % for bump detection
[y,x] = meshgrid(-ym:ym,-xm:xm);
[ycoor,xcoor] = meshgrid(-2*ym:2*ym,-2*xm:2*xm);
mask = ones(2*ym+1,2*xm+1); mask(x.^2+y.^2<rmin^2) = 0; mask(x.^2+y.^2>xm^2) = 0;

% parameters for figure 2

% functions for figure 1
% env_patch, model_rmap_ac, shuffled_identical_circular_fields, shuffledfields

figure(1); set(gcf,'Position',[0 0 1200 1000]);
subplot(551); env_patch(1); axis off; % title('2D env');
subplot(552);[rmap,ac] = model_rmap_ac(y,x,lam,psi,c1,0,xm); imagesc_env(rmap,-xm:xm,-ym:ym,1); title('ratemap');
subplot(553); imagesc_env(ac,-2*xm:2*xm,-2*ym:2*ym); colormap(jet(256)); title('autocorrelation');
caxis([0 max(max(ac))*0.6]); xlim([-xm xm]); ylim([-ym ym]);
subplot(554);[rmap_s,ac_s] = model_shuffled_rmap_ac(y,x,lam,psi,c1,0,xm,thre,1);
imagesc_env(rmap_s,-xm:xm,-ym:ym,1); title('shuffled ratemap');
subplot(555); imagesc_env(ac_s,-2*xm:2*xm,-2*ym:2*ym); title('autocorrelation');
caxis([0 max(max(ac_s))*0.6]); xlim([-xm xm]); ylim([-ym ym]);

subplot(556); env_patch(2); axis off; % title('track');
subplot(557); rmap(x.^2+y.^2<rmin^2) = 0; imagesc_env(rmap,-xm:xm,-ym:ym,1);
subplot(558); ac = xcorr2(rmap); imagesc_env(ac,-2*xm:2*xm,-2*ym:2*ym); 
caxis([0 max(max(ac))*0.6]); xlim([-xm xm]); ylim([-ym ym]); acsum = ac;
subplot(559); rmap_s(x.^2+y.^2<rmin^2) = 0; imagesc_env(rmap_s,-xm:xm,-ym:ym,1);
subplot(5,5,10); ac_s = xcorr2(rmap_s);imagesc_env(ac_s,-2*xm:2*xm,-2*ym:2*ym);
caxis([0 max(max(ac_s))*0.6]); xlim([-xm xm]); ylim([-ym ym]); acsum_s = ac_s;

subplot(5,5,11); env_patch(2); axis off;
subplot(5,5,12); [rmap,~] = model_rmap_ac(y,x,lam,psi,c2,0,xm); 
rmap(x.^2+y.^2<rmin^2) = 0; imagesc_env(rmap,-xm:xm,-ym:ym,1);
subplot(5,5,13); ac = xcorr2(rmap); imagesc_env(ac,-2*xm:2*xm,-2*ym:2*ym); 
caxis([0 max(max(ac))*0.6]); xlim([-xm xm]); ylim([-ym ym]); acsum = acsum + ac;
subplot(5,5,14); [rmap_s,~] = model_shuffled_rmap_ac(y,x,lam,psi,c2,0,xm,thre,2);
rmap_s(x.^2+y.^2<rmin^2) = 0; imagesc_env(rmap_s,-xm:xm,-ym:ym,1);
subplot(5,5,15); ac_s = xcorr2(rmap_s); imagesc_env(ac_s,-2*xm:2*xm,-2*ym:2*ym);
caxis([0 max(max(ac_s))*0.6]); xlim([-xm xm]); ylim([-ym ym]); acsum_s = acsum_s + ac_s;

subplot(5,5,16); hold on; env_patch(2); text(-100,85,'20 cells'), axis off;
for j = 3:20
    [rmap,~] = model_rmap_ac(y,x,lam,psi,clist(j-2),0,xm); rmap(x.^2+y.^2<rmin^2) = 0; 
    ac = xcorr2(rmap); acsum = acsum + ac;
    [rmap_s,~] = model_shuffled_rmap_ac(y,x,lam,psi,clist(j-2),0,xm,thre,j); rmap_s(x.^2+y.^2<rmin^2) = 0;
    ac_s = xcorr2(rmap_s); acsum_s = acsum_s + ac_s;
end
subplot(5,5,18); imagesc_env(acsum,-2*xm:2*xm,-2*ym:2*ym);
caxis([0 max(max(acsum))*0.6]); xlim([-xm xm]); ylim([-ym ym]);
subplot(5,5,20); imagesc_env(acsum_s,-2*xm:2*xm,-2*ym:2*ym);
caxis([0 max(max(acsum_s))*0.6]); xlim([-xm xm]); ylim([-ym ym]);

subplot(5,5,22); rmap(mask==1) = 1; imagesc_env(rmap,-xm:xm,-ym:ym,1);
subplot(5,5,23); ac = xcorr2(rmap); imagesc_env(ac,-2*xm:2*xm,-2*ym:2*ym); 
caxis([0 max(max(ac))*0.6]); xlim([-xm xm]); ylim([-ym ym]);
subplot(5,5,24); 
saveas(1,'fig1.pdf');

% figure(2); set(gcf,'Position',[0 0 1200 1000]);
% subplot(5,8,1); title('2D env');
% subplot(5,8,2); title('cell 1 trajectory');
% subplot(5,8,3); title('ratemap');
% subplot(5,8,4); title('autocorr');
% subplot(5,8,5); title('cell 2 trajectory');
% subplot(5,8,6); title('ratemap');
% subplot(5,8,7); title('autocorr');
% subplot(5,7,8); title('autocorr sum');
% 
% subplot(5,8,9); title('track light');
% subplot(5,8,10); title('cell 1 trajectory');
% subplot(5,8,11); title('ratemap');
% subplot(5,8,12); title('autocorr');
% subplot(5,8,13); title('cell 2 trajectory');
% subplot(5,8,14); title('ratemap');
% subplot(5,8,15); title('autocorr');
% subplot(5,8,16); title('autocorr sum');
% 
% subplot(5,8,17); title('track dark');
% subplot(5,8,18); title('cell 1 trajectory');
% subplot(5,8,19); title('ratemap');
% subplot(5,8,20); title('autocorr');
% subplot(5,8,21); title('cell 2 trajectory');
% subplot(5,8,22); title('ratemap');
% subplot(5,8,23); title('autocorr');
% subplot(5,8,24); title('autocorr sum');
% 
% subplot(5,8,25); title('light+dark');
% subplot(5,8,26); title('cell 1 trajectory');
% subplot(5,8,27); title('ratemap');
% subplot(5,8,28); title('autocorr');
% subplot(5,8,29); title('cell 2 trajectory');
% subplot(5,8,30); title('ratemap');
% subplot(5,8,31); title('autocorr');
% subplot(5,8,32); title('autocorr sum');
% 
% subplot(5,2,9); title('spacings/orientations'); xlabel('cell ID');
% subplot(5,2,10); title('spacings/orientations'); xlabel('environment');
% saveas(2,'fig2.png');
% 
% figure(3); set(gcf,'Position',[0 0 1200 1600]);
% subplot(7,8,1); title('2D env');
% subplot(7,8,2); title('cell 1 trajectory');
% subplot(7,8,3); title('ratemap');
% subplot(7,8,4); title('autocorr');
% subplot(7,8,5); title('cell 2 trajectory');
% subplot(7,8,6); title('ratemap');
% subplot(7,8,7); title('autocorr');
% subplot(7,8,8); title('autocorr sum');
% 
% subplot(7,8,9); title('track light');
% subplot(7,8,10); title('cell 1 trajectory');
% subplot(7,8,11); title('ratemap');
% subplot(7,8,12); title('autocorr');
% subplot(7,8,13); title('cell 2 trajectory');
% subplot(7,8,14); title('ratemap');
% subplot(7,8,15); title('autocorr');
% subplot(7,8,16); title('autocorr sum');
% 
% subplot(7,8,17); title('track dark');
% subplot(7,8,18); title('cell 1 trajectory');
% subplot(7,8,19); title('ratemap');
% subplot(7,8,20); title('autocorr');
% subplot(7,8,21); title('cell 2 trajectory');
% subplot(7,8,22); title('ratemap');
% subplot(7,8,23); title('autocorr');
% subplot(7,8,24); title('autocorr sum');
% 
% subplot(4,3,7); title('spacings/orientations'); xlabel('cell ID');
% subplot(4,3,8); title('dendrogram');
% subplot(7,3,19); title('module 1 spacings/orientations'); xlabel('environment');
% subplot(7,3,20); title('module 2 spacings/orientations'); xlabel('environment');
% 
% subplot(7,8,31); title('module 1 sum');
% subplot(7,8,32); title('module 2 sum');
% subplot(7,8,39); title('track light');
% subplot(7,8,40); title('track light');
% subplot(7,8,47); title('track dark');
% subplot(7,8,48); title('track dark');
% subplot(7,8,55); title('light+dark');
% subplot(7,8,56); title('light+dark');
% 
% saveas(3,'fig3.png');
% 
% figure(4); set(gcf,'Position',[0 0 1200 1000]);
% subplot(4,8,1); title('trajectory light');
% subplot(4,4,2); title('linearized');
% subplot(4,8,5); title('trajectory dark');
% subplot(4,4,4); title('linearized');
% subplot(4,4,6); title('ratemap');
% subplot(4,4,8); title('ratemap');
% subplot(4,4,10); title('autocorr');
% subplot(4,4,12); title('autocorr');
% subplot(4,4,14); title('autocorr sum');
% subplot(4,4,16); title('autocorr sum');
% 
% saveas(4,'fig4.png');
