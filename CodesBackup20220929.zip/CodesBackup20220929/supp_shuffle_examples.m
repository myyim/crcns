close all; clear all;

%% parameters
norm = 2; % 0: no normalization; 1: overall peak; 2: peak within donut
r = 150;
halfw = 5;
[ycoor,xcoor] = meshgrid(-r:r,-r:r);
an = {'MEC2','MEC1','MEC3','MEC4','1RS_','2BS_'};
sig = 3;
cscale = 0.2; cscale2 =0.1;
load('./ac_struct.mat');

%% codes needed
codepath = './codes/'; % update your path here!
allpath = genpath(codepath); addpath(allpath);
load('./CellsID.mat');
load('./fitcirculartrack.mat');

%% figure
datapath = './Jacob_Sargolini_All_Environments/'; % update your path here!
allpath = genpath(datapath); addpath(allpath);
codepath = './codes/'; % update your path here!
allpath = genpath(codepath); addpath(allpath);
datapath = './data/'; % update your path here!
allpath = genpath(datapath); addpath(allpath);

figure(1); set(gcf,'Position',[0 0 1000 1200]);
figure(2); set(gcf,'Position',[0 0 1000 1200]);

load('ac_struct.mat');
for dp = [1,3]
    if dp == 1
        %addpath([datapath,'Large Arena matlab files/']);
        filename = 'CellsID.Arena';
        idx = [1,3];
    elseif dp == 2
        %addpath([datapath,'Large Circular track light matlab files/']);
        filename = 'CellsID.CircularTrackLight';
    elseif dp == 3
        %addpath([datapath,'Large Circular track dark matlab files/']);
        filename = 'CellsID.CiruclarTrackDark';
        idx = [21,23];
    end
    for j = idx
        if mod(j,10) == 3
            is_second = 1;
        else
            is_second = 0;
        end
        eval(['fname = ',filename,'(j);']);
        tID = CellsID.tetrode(j);
        cID = CellsID.cell(j);
        fname = char(fname);
        if fname(1) == 'M'
            if dp == 1
                fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];          
            else
                fname = [fname(1:11),'_t',num2str(tID),'_c',num2str(cID)];
            end
        else
            fname = [fname(1:16),'_t',num2str(tID),'_c',num2str(cID)];
        end
        aid = find(strcmp(fname(1:4),an)==1);
        [trackpos,trackf,~] = getdata_sargolini(fname,tID,cID,1,pall(j,:)); % pall stores the fitted parameters            
        rmap = rmap_A(aid).E(dp).GC(j).rmap;
        ac = ac_A(aid).E(dp).GC(j).ac;
        figure((dp+1)/2); sgtitle(['rat ',num2str(aid),'; E',num2str(dp)]);
        subplot(4,4,1+8*is_second);hold on; axis image; title(['cell ',num2str(mod(j,19))]);
        plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
        plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); axis off;
        subplot(4,4,2+8*is_second); hold on; axis image;
        r = (size(rmap,2)-1)/2; imagesc_env(rmap,-r:r,-r:r,1); title('rate map');
        colormap(jet(256)); caxis([0 cscale*max(rmap,[],'all')]); %colorbar;
        %set(gca,'color',[1 1 1]); set(gca,'YDir','normal'); set(gca,'visible','off');
        %rad = sqrt(trackpos(:,1).^2+trackpos(:,2).^2); 
        %rad2 = sqrt(trackf(:,1).^2+trackf(:,2).^2); 
        subplot(4,4,6+8*is_second); hold on; axis image;
        r = (size(ac,2)-1)/2; imagesc_env(ac',-r:r,-r:r); title('autocorrelation');
        xlim([-150 150]); ylim([-150 150]); colormap(jet(256)); %colorbar;
        if dp == 1
            caxis([0 2*cscale*max(ac,[],'all')]);
        else
            caxis([0 2*cscale2*max(ac,[],'all')]);
        end
    end
end

for s = 1:2
    load(['ac_struct_s',num2str(s),'.mat']);
    for dp = [1,3]
        if dp == 1
            idx = [1,3];
        elseif dp == 3
            idx = [21,23];
        end
        for j = idx
            if mod(j,10) == 3
                is_second = 1;
            else
                is_second = 0;
            end
            if j < 20
                aid = 1;
            else
                aid = 2;
            end
            rmap = rmap_A(aid).E(dp).GC(j).rmap;
            ac = ac_A(aid).E(dp).GC(j).ac;
            figure((dp+1)/2); 
            subplot(4,4,2+8*is_second+s); hold on; axis image;
            r = (size(rmap,2)-1)/2; imagesc_env(rmap,-r:r,-r:r,1); title(['shuffle ',num2str(s)]);
            colormap(jet(256)); caxis([0 cscale*max(rmap,[],'all')]);%colorbar; 
            set(gca,'color',[1 1 1]); %set(gca,'YDir','normal'); set(gca,'visible','off');
            subplot(4,4,6+8*is_second+s); hold on; axis image;
            r = (size(ac,2)-1)/2; imagesc_env(ac',-r:r,-r:r);
            xlim([-150 150]); ylim([-150 150]); colormap(jet(256)); %colorbar;
            if dp == 1
                caxis([0 2*cscale*max(ac,[],'all')]);
            else
                caxis([0 2*cscale2*max(ac,[],'all')]);
            end
        end
    end  
end

figure(1);
set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,...
    'PaperPosition',[0 0 screenposition(3:4)],...
    'PaperSize',[screenposition(3:4)]);
print -dpdf supp_shuffle_example1

figure(2);
set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,...
    'PaperPosition',[0 0 screenposition(3:4)],...
    'PaperSize',[screenposition(3:4)]);
print -dpdf supp_shuffle_example2
