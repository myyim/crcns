close all; clear all;

% parameters for figure 2
ID1 = 4; ID2 = 9; % ID of the two examples
cscale = 0.2; cscale2 = 0.05; cscale3 = 0.02; % fraction of max as the upper limit of colorbar
rm = 75; % the square size is 2rm X 2rm
idx = [1:5,7:19];  % animal 1
[y,x] = meshgrid(-rm:rm,-rm:rm);

% functions for figure 2
% env_patch, getdata, imagesc_env

% data for figure 2
datapath = './Jacob_Sargolini_All_Environments/'; % update your path here!
allpath = genpath(datapath); addpath(allpath);
% codepath = './codes/'; % update your path here!
% allpath = genpath(codepath); addpath(allpath);
% datapath = './data/'; % update your path here!
% allpath = genpath(datapath); addpath(allpath);
load('CellsID.mat');
load('fitcirculartrack.mat'); % pall (fitted parameters)
load('ac_struct.mat');
load('gridcells_spac_ori.mat'); % from run_grid3orientations_data
load('a1_gridcells_summary_spac_ori.mat'); % from run_grid3orientations
load('a1_summary_ac.mat'); load('a1_gscores.mat');     % from run_gridness_norm

figure(2); set(gcf,'Position',[0 0 1400 1400]);
fname = CellsID.Arena(ID1); tID = CellsID.tetrode(ID1); cID = CellsID.cell(ID1);
fname = char(fname); fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];  
[trackpos,trackf,~] = getdata(fname,1,pall(ID1,:));
rmap = rmap_A(1).E(1).GC(ID1).rmap; ac = ac_A(1).E(1).GC(ID1).ac;
subplot(5,8,1); env_patch(1); axis off;
subplot(5,8,2); hold on; plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); axis equal;
axis off; title(['rat 1 cell ',num2str(ID1)]); 
subplot(5,8,3); r = (size(rmap,2)-1)/2; imagesc_env(rmap,-r:r,-r:r,1);
colormap(jet(256)); caxis([0 max(rmap,[],'all')*cscale]); title('ratemap');
subplot(5,8,4); r = (size(ac,2)-1)/2; imagesc_env(ac,-r:r,-r:r); title('autocorrelation');
caxis([0 max(ac,[],'all')*cscale]);
fname = CellsID.Arena(ID2); tID = CellsID.tetrode(ID2); cID = CellsID.cell(ID2);
fname = char(fname); fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];  
[trackpos,trackf,~] = getdata(fname,1,pall(ID2,:));
rmap = rmap_A(1).E(1).GC(ID2).rmap; ac = ac_A(1).E(1).GC(ID2).ac;
subplot(5,8,5); hold on; plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); axis equal;
axis off; title(['rat 1 cell ',num2str(ID2)]);  
subplot(5,8,6); r = (size(rmap,2)-1)/2; imagesc_env(rmap,-r:r,-r:r,1);
caxis([0 max(rmap,[],'all')*cscale]); title('ratemap');
subplot(5,8,7); r = (size(ac,2)-1)/2; imagesc_env(ac,-r:r,-r:r); title('autocorrelation');
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(ac,[],'all')*cscale]);
subplot(5,8,8); imagesc_env(a1_ac1,-r:r,-r:r); title(['gridness: ',num2str(a1_gscores(1),2)]);
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(a1_ac1,[],'all')*cscale]);

fname = CellsID.CircularTrackLight(ID1); tID = CellsID.tetrode(ID1); cID = CellsID.cell(ID1);
fname = char(fname); fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];  
[trackpos,trackf,~] = getdata(fname,1,pall(ID1,:));
rmap = rmap_A(1).E(2).GC(ID1).rmap; ac = ac_A(1).E(2).GC(ID1).ac;
subplot(5,8,9); env_patch(2); axis off;
subplot(5,8,10); hold on;  plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); axis equal; axis off;
subplot(5,8,11); r = (size(rmap,2)-1)/2; imagesc_env(rmap,-r:r,-r:r,1);
caxis([0 max(rmap,[],'all')*cscale]);
subplot(5,8,12); r = (size(ac,2)-1)/2; imagesc_env(ac,-r:r,-r:r);
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(ac,[],'all')*cscale2]);
fname = CellsID.CircularTrackLight(ID2); tID = CellsID.tetrode(ID2); cID = CellsID.cell(ID2);
fname = char(fname); fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];  
[trackpos,trackf,~] = getdata(fname,1,pall(ID2,:));
rmap = rmap_A(1).E(2).GC(ID2).rmap; ac = ac_A(1).E(2).GC(ID2).ac;
subplot(5,8,13); hold on; plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); axis equal; axis off;
subplot(5,8,14); r = (size(rmap,2)-1)/2; imagesc_env(rmap,-r:r,-r:r,1);
caxis([0 max(rmap,[],'all')*cscale]); 
subplot(5,8,15); r = (size(ac,2)-1)/2; imagesc_env(ac,-r:r,-r:r); 
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(ac,[],'all')*cscale2]);
subplot(5,8,16); r = (size(a1_ac2,2)-1)/2; imagesc_env(a1_ac2,-r:r,-r:r); title(['gridness: ',num2str(a1_gscores(2),2)]);
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(a1_ac2,[],'all')*cscale3]);

fname = CellsID.CiruclarTrackDark(ID1); tID = CellsID.tetrode(ID1); cID = CellsID.cell(ID1);
fname = char(fname); fname = [fname(1:10),'d_t',num2str(tID),'_c',num2str(cID)];  
[trackpos,trackf,~] = getdata(fname,1,pall(ID1,:));
rmap = rmap_A(1).E(3).GC(ID1).rmap; ac = ac_A(1).E(3).GC(ID1).ac;
subplot(5,8,17); env_patch(3); axis off;
subplot(5,8,18); hold on; plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); axis equal; axis off;
subplot(5,8,19); r = (size(rmap,2)-1)/2; imagesc_env(rmap,-r:r,-r:r,1);
caxis([0 max(rmap,[],'all')*cscale]);
subplot(5,8,20); r = (size(ac,2)-1)/2; imagesc_env(ac,-r:r,-r:r);
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(ac,[],'all')*cscale2]);
fname = CellsID.CiruclarTrackDark(ID2); tID = CellsID.tetrode(ID2); cID = CellsID.cell(ID2);
fname = char(fname); fname = [fname(1:10),'d_t',num2str(tID),'_c',num2str(cID)];  
[trackpos,trackf,~] = getdata(fname,1,pall(ID2,:));
rmap = rmap_A(1).E(3).GC(ID2).rmap; ac = ac_A(1).E(3).GC(ID2).ac;
subplot(5,8,21); hold on; plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); axis equal; axis off;
subplot(5,8,22); r = (size(rmap,2)-1)/2; imagesc_env(rmap,-r:r,-r:r,1);
caxis([0 max(rmap,[],'all')*cscale]); 
subplot(5,8,23); r = (size(ac,2)-1)/2; imagesc_env(ac,-r:r,-r:r); 
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(ac,[],'all')*cscale2]);
subplot(5,8,24); imagesc_env(a1_ac3,-r:r,-r:r); title(['gridness: ',num2str(a1_gscores(3),2)]);
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(a1_ac3,[],'all')*cscale3]);

% subplot(5,8,31); title('light+dark');
subplot(5,8,32); imagesc_env(a1_ac4,-r:r,-r:r); title(['gridness: ',num2str(a1_gscores(4),2)]);
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(a1_ac4,[],'all')*cscale3]);
 
subplot(3,3,7); hold on; yyaxis left;
plot([0 19],a1_sum_oris(1,1)*ones(2),'-','LineWidth',0.1);
plot([0 19],a1_sum_oris(1,2)*ones(2),'-','LineWidth',0.1);
plot([0 19],a1_sum_oris(1,3)*ones(2),'-','LineWidth',0.1);
yyaxis right; plot([0 19],mean(a1_sum_spacs(1,:),2)*ones(2),'-','LineWidth',0.1);
yyaxis left;
for j = 1:18
    plot(j*ones(1,3),a1_oris(j,:),'x');
end 
ylim([0 185]); ylabel('inferred orientations (^{\circ})');
yyaxis right; plot(mean(a1_spacs,2),'o'); ylim([30 60]);
ylabel('inferred spacing (cm)'); xlabel('cell ID'); xlim([0,19]); xticks([1,5,10,15]);
subplot(3,3,8); hold on; yyaxis left;
plot([0 5],a1_sum_oris(1,1)*ones(2),'-','LineWidth',0.1);
plot([0 5],a1_sum_oris(1,2)*ones(2),'-','LineWidth',0.1);
plot([0 5],a1_sum_oris(1,3)*ones(2),'-','LineWidth',0.1);
plot([2 4],(a1_sum_oris(1,1)+a1_sum_oris(1,2))/2*ones(2),'--','LineWidth',0.1);
plot([2 4],(a1_sum_oris(1,2)+a1_sum_oris(1,3))/2*ones(2),'--','LineWidth',0.1);
plot([2 4],(a1_sum_oris(1,1)+a1_sum_oris(1,3)+180)/2*ones(2),'--','LineWidth',0.1);
yyaxis right; plot([0 5],mean(a1_sum_spacs(1,:),2)*ones(2),'-','LineWidth',0.1);
plot([2 4],sqrt(3)*mean(a1_sum_spacs(1,:),2)*ones(2),'--','LineWidth',0.1);
yyaxis left;
for j = 1:4
    plot(j*ones(1,3),a1_sum_oris(j,:),'x');
end 
ylabel('inferred orientations (^{\circ})');
yyaxis right; plot(mean(a1_sum_spacs,2),'o'); ylim([38 80]);
ylabel('inferred spacing (cm)'); xlabel('environment');
xticks(1:4); xlim([0.5,4.5]); xticklabels({'E1','E2','E3','E2 & 3'});
saveas(2,'fig2.png'); saveas(2,'fig2.pdf'); 
