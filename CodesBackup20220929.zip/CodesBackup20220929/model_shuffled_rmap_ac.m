function [rmap,ac] = model_shuffled_rmap_ac(y,x,lam,psi,c,r_inner,r_outer,thre,seed)
% [rmap,ac] = model_shuffled_rmap_ac(y,x,lam,psi,c,r_inner,r_outer,thre,seed)
if nargin < 9
    seed = 1;
end
if nargin < 8
    thre = 0.2;
end
if nargin < 7
    r_outer = 2*max(size(y));   % no outer bound
end
if nargin < 6
    r_inner = 0;   % no inner bound
end
if nargin < 5
    c = [0,0];   % centered at [0,0]
end
rng(seed);
rmap = gridcell(y,x,1,lam,psi,c);  % from left to right in a matrix is in the direction of increasing the second coordinate, thus (y,x)
rmap = shuffled_identical_circular_fields(rmap,thre,seed);
rmap(x.^2+y.^2<r_inner^2) = 0; rmap(x.^2+y.^2>r_outer^2) = 0; % inner and outer radii
ac = xcorr2(rmap);

end