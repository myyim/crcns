close all; clear all;

% parameters
cscale = 0.2; cscale2 = 0.05; cscale3 = 0.02; % fraction of max as the upper limit of colorbar
rm = 75; % the square size is 2rm X 2rm

% functions
% env_patch, getdata, imagesc_env

% data
datapath = './Jacob_Sargolini_All_Environments/'; % update your path here!
allpath = genpath(datapath); addpath(allpath);
codepath = './codes/'; % update your path here!
allpath = genpath(codepath); addpath(allpath);
datapath = './data/'; % update your path here!
allpath = genpath(datapath); addpath(allpath);

load('gridcells_spac_ori.mat'); % from run_grid3orientations_data
load('a1_gridcells_summary_spac_ori.mat'); % from run_grid3orientations
load('a1_summary_ac.mat'); load('a1_gscores.mat');     % from run_gridness_norm

figure; set(gcf,'Position',[0 0 1400 1400]); colormap(jet(256)); 
subplot(4,4,2); r = (size(a1_ac1,2)-1)/2; imagesc_env(a1_ac1,-r:r,-r:r); title(['gridness: ',num2str(a1_gscores(1),2)]);
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(a1_ac1,[],'all')*cscale]); ylabel('E_1','Rotation',0);

subplot(4,4,6); r = (size(a1_ac2,2)-1)/2; imagesc_env(a1_ac2,-r:r,-r:r); title(['gridness: ',num2str(a1_gscores(2),2)]);
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(a1_ac2,[],'all')*cscale3]); ylabel('E_2','Rotation',0);

subplot(4,4,10); r = (size(a1_ac3,2)-1)/2; imagesc_env(a1_ac3,-r:r,-r:r); title(['gridness: ',num2str(a1_gscores(3),2)]);
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(a1_ac3,[],'all')*cscale3]); ylabel('E_3','Rotation',0);

subplot(4,4,14); r = (size(a1_ac4,2)-1)/2; imagesc_env(a1_ac4,-r:r,-r:r); title(['gridness: ',num2str(a1_gscores(4),2)]);
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(a1_ac4,[],'all')*cscale3]); ylabel('E_2 + E_3','Rotation',0);
xlabel('lag (cm)');

subplot(3,2,2); hold on; yyaxis left;
plot([0 19],a1_sum_oris(1,1)*ones(2),'-','LineWidth',0.1);
plot([0 19],a1_sum_oris(1,2)*ones(2),'-','LineWidth',0.1);
plot([0 19],a1_sum_oris(1,3)*ones(2),'-','LineWidth',0.1);
yyaxis right; plot([0 19],mean(a1_sum_spacs(1,:),2)*ones(2),'-','LineWidth',0.1);
yyaxis left;
for j = 1:18
    plot(j*ones(1,3),a1_oris(j,:),'x');
end 
ylim([0 185]); ylabel('E_1-inferred orientations (^{\circ})');
yyaxis right; plot(mean(a1_spacs,2),'o'); ylim([30 60]);
ylabel('E_1-inferred spacing (cm)'); xlabel('cell ID'); xlim([0,19]); xticks([1,5,10,15]);
subplot(3,2,4); hold on; yyaxis left;
plot([0 5],a1_sum_oris(1,1)*ones(2),'-','LineWidth',0.1);
plot([0 5],a1_sum_oris(1,2)*ones(2),'-','LineWidth',0.1);
plot([0 5],a1_sum_oris(1,3)*ones(2),'-','LineWidth',0.1);
plot([2 4],(a1_sum_oris(1,1)+a1_sum_oris(1,2))/2*ones(2),'--','LineWidth',0.1);
plot([2 4],(a1_sum_oris(1,2)+a1_sum_oris(1,3))/2*ones(2),'--','LineWidth',0.1);
plot([2 4],(a1_sum_oris(1,1)+a1_sum_oris(1,3)+180)/2*ones(2),'--','LineWidth',0.1);
yyaxis right; plot([0 5],mean(a1_sum_spacs(1,:),2)*ones(2),'-','LineWidth',0.1);
plot([2 4],sqrt(3)*mean(a1_sum_spacs(1,:),2)*ones(2),'--','LineWidth',0.1);
yyaxis left;
for j = 1:4
    plot(j*ones(1,3),a1_sum_oris(j,:),'x');
end 
ylabel('Pop-inferred orientations (^{\circ})');
yyaxis right; plot(mean(a1_sum_spacs,2),'o'); ylim([38 80]);
ylabel('Pop-inferred spacing (cm)'); xlabel('environment');
xticks(1:4); xlim([0.5,4.5]); xticklabels({'E_1','E_2','E_3','E_2 + E_3'});

set(findall(gcf,'-property','FontSize'),'FontSize',10);
set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,...
    'PaperPosition',[0 0 screenposition(3:4)],...
    'PaperSize',[screenposition(3:4)]);
print -dpdf fig4_rat1