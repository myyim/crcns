function [rad,frad,rad2,frad2,acr] = max_activity_ring_psd(ac)

% Locate the ring in ac0 with max activity
[xm,ym] = size(ac); xm = (xm-1)/2; ym = (ym-1)/2; d = min([xm,ym]);
[ycoor,xcoor] = meshgrid(-ym:ym,-xm:xm); % coordinates of the grid, y by x
topright = sqrt((xcoor+0.5).^2+(ycoor+0.5).^2);
topleft = sqrt((xcoor-0.5).^2+(ycoor+0.5).^2);
bottomleft = sqrt((xcoor-0.5).^2+(ycoor-0.5).^2);
bottomright = sqrt((xcoor+0.5).^2+(ycoor-0.5).^2);
rtensor(:,:,1) = topright; rtensor(:,:,2) = topleft; rtensor(:,:,3) = bottomleft; rtensor(:,:,4) = bottomright;
rmin = min(rtensor,[],3); rmax = max(rtensor,[],3);
acr = zeros(1,d);  % average autocorrelation along a circle (index = radius) 
for rad = 1:d
    ringon = (rad>=rmin).*(rad<=rmax); % define the bins on the circle
    acr(rad) = sum(ac(ringon==1))/sum(sum(ringon==1));
end
dacr = acr(2:end)-acr(1:end-1); % difference
sgn = (dacr(1:end-1)<0).*(dacr(2:end)>0);
frad = find(sgn==1); frad = frad(1)+1;
sgn = (dacr(1:end-1)>0).*(dacr(2:end)<0);
rad = find(sgn==1); rad = rad(1)+1;
acr0 = acr; acr0(1:rad-1) = 0; dacr = acr0(2:end)-acr0(1:end-1); % difference
sgn = (dacr(1:end-1)<0).*(dacr(2:end)>0);
frad2 = find(sgn==1); frad2 = frad2(1)+1;
acr0(rad:frad2) = 0; dacr = acr0(2:end)-acr0(1:end-1); % difference
sgn = (dacr(1:end-1)>0).*(dacr(2:end)<0);
rad2 = find(sgn==1); rad2 = rad2(1)+1;
% dacr = acr0(2:end)-acr0(1:end-1); % difference
% sgn = (dacr(1:end-1)<=0).*(dacr(2:end)>0);
% frad = find(sgn==1); frad = frad(1)+1;
% [~,rad] = max(acr0);
end