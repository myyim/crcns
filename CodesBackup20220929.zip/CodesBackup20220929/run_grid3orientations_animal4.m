close all; clear all;
norm = 2; % 0: no normalization; 1: overall peak; 2: peak within donut
r = 150;
halfw = 3;
[ycoor,xcoor] = meshgrid(-r:r,-r:r);
load('./ac_struct64.mat');
% animal
a = 4;
idx = [40]; % animal 4

figpath = './figures/Jacob_Sargolini_orientations/';
if ~exist(figpath)
    mkdir(figpath);
end
addpath(figpath);

figure(1); set(gcf,'Position',[0 0 1100 600]); subplot(211); hold on;
yyaxis left;
%for j = 0:6
%    plot([0 19],j*30*ones(2),'k--','LineWidth',0.01);
%end
figure(2); set(gcf,'Position',[0 0 1100 600]);
figure(3); set(gcf,'Position',[0 0 1100 600]);
figure(4); set(gcf,'Position',[0 0 1100 600]);
figure(5); set(gcf,'Position',[0 0 1100 600]);

aE0 = zeros(2*r+1,2*r+1);
a2_sum_rad = []; a2_sum_spacs = []; a2_sum_oris = [];
for e = 1:2 % environment
    a0 = zeros(2*r+1,2*r+1);
    for i = 1:size(idx,2)    % cell ID
        ac = ac_A(a).E(e).GC(idx(i)).ac;
        s = size(ac,1); 
        if s < 2*r+1    % zero-padding when size of ac is smaller than r
            temp = zeros(2*r+1,2*r+1);
            temp((2*r+1-s)/2+1:2*r+1-(2*r+1-s)/2,(2*r+1-s)/2+1:2*r+1-(2*r+1-s)/2) = ac;
            ac = temp;
        else
            ac = ac((s+1)/2-r:(s+1)/2+r,(s+1)/2-r:(s+1)/2+r);   % reshape ac
        end
        [rad,frad,ac0r,deriv] = max_activity_ring(ac,30);
        if norm == 0
            acmax = 1;
        elseif norm == 1
            acmax = max(max(ac));
        elseif norm == 2
            ringplot = ac; ringplot(xcoor.^2+ycoor.^2<frad^2) = 0; ringplot(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0; % extract the ring
            acmax = max(max(ringplot));
        end
        if acmax ~= 0
            a0 = a0 + ac/acmax;
        end   
        if e == 1
            [oris,xs,ys,ath] = grid3orientations(ac,rad,rad-halfw);
            figure(1); subplot(211);
            yyaxis left;
            if a == 4
                plot(i*ones(size(oris,2),1),oris,'x'); 
            elseif a == 2
                oris2 = oris; 
                if any(oris<20)
                    oris2 = [oris2 oris2(find(oris2<20))+180];
                end
                plot(i*ones(size(oris2,2),1),oris2,'x');
            end
            yyaxis right;
            plot(i,mean(sqrt(xs.^2+ys.^2)),'o'); 
            ylabel('peak radius (cm)');
            figure(2); subplot(4,5,i); hold on;
            imagesc_env(ac/acmax,-r:r,-r:r); plot(xs,ys,'w+','MarkerSize',8);
            %plot(frad*cos(0:0.01:2*pi+0.01),frad*sin(0:0.01:2*pi+0.01),'w');
            plot((rad-halfw)*cos(0:0.01:2*pi+0.01),(rad-halfw)*sin(0:0.01:2*pi+0.01),'w');
            %plot((2*rad-frad)*cos(0:0.01:2*pi+0.01),(2*rad-frad)*sin(0:0.01:2*pi+0.01),'w');
            plot((rad+halfw)*cos(0:0.01:2*pi+0.01),(rad+halfw)*sin(0:0.01:2*pi+0.01),'w');
            titlestring = [num2str(rad),'; ',num2str(round(mean(sqrt(xs.^2+ys.^2)))),'; ']; 
            for j = 1:size(oris,2)
                titlestring = [titlestring,num2str(oris(j)),'^{\circ} ']; 
            end
            title(titlestring); axis image; colormap(jet(256)); colorbar; caxis([0 1]); 
            xlim([-80 80]); ylim([-80 80]); 
            figure(3); subplot(4,5,i); hold on;
            imagesc_env(ath,-r:r,-r:r); plot(xs,ys,'w+','MarkerSize',8);
            plot((rad-halfw)*cos(0:0.01:2*pi+0.01),(rad-halfw)*sin(0:0.01:2*pi+0.01),'w');
            plot((rad+halfw)*cos(0:0.01:2*pi+0.01),(rad+halfw)*sin(0:0.01:2*pi+0.01),'w');
            title(titlestring); axis image; colormap(jet(256)); colorbar; caxis([0 1]); 
            xlim([-80 80]); ylim([-80 80]);
            figure(4); subplot(4,5,i); hold on;
            plot(ac0r,'k'); plot(rad*ones(1,2),[0,ac0r(rad)],'r'); plot(frad*ones(1,2),[0,ac0r(frad)],'b');
            xlabel('radius'); ylabel('mean autocorr'); xlim([0 r]); ylim([0 2*ac0r(rad)]);
            title([num2str(deriv),': \color{blue}',num2str(frad),'; \color{red}',num2str(rad)]);
            end
        end
    
    figure(1);
    sgtitle(['animal ',num2str(a)]);
    title('individual cells in E1 (2D)');
    subplot(212); hold on; title('population responses');
    yyaxis right; ylabel('peak radius (cm)');
    [rad,frad,a0r,deriv] = max_activity_ring(a0,30,90);  % inner circle
    [oris,xs,ys] = grid3orientations(a0,rad,rad-halfw);
    %plot(e,mean(sqrt(xs.^2+ys.^2)),'o');
    a2_sum_rad = [a2_sum_rad; rad]; a2_sum_spacs = [a2_sum_spacs; sqrt(xs.^2+ys.^2)]; a2_sum_oris = [a2_sum_oris; oris];
    if e == 1
        %plot([2 4],sqrt(3)*mean(sqrt(xs.^2+ys.^2))*ones(2),'--','LineWidth',0.1);
        plot([5 7],3*mean(sqrt(xs.^2+ys.^2))*ones(2),'--','LineWidth',0.1);
    end
    yyaxis left; ylabel('peak orientations (^\circ)');
    if a == 4
        plot(e*ones(size(oris,2),1),oris,'x');
    elseif a == 2
        oris2 = oris; 
        if any(oris<20)
            oris2 = [oris2 oris2(find(oris2<20))+180];
        end
        plot(e*ones(size(oris2,2),1),oris2,'x');
    end
    if e == 1
        subplot(211); yyaxis left;
        plot([0 size(idx,2)+1],oris(1)*ones(2),'-','LineWidth',0.1);
        plot([0 size(idx,2)+1],oris(2)*ones(2),'-','LineWidth',0.1);
        plot([0 size(idx,2)+1],oris(3)*ones(2),'-','LineWidth',0.1);
        xlabel('cell ID'); ylabel('peak orientations (^\circ)');
        if a == 2
            ylim([20 200]);
        end
        subplot(212); yyaxis left;
        plot([0 8],oris(1)*ones(2),'-','LineWidth',0.1);
        plot([0 8],oris(2)*ones(2),'-','LineWidth',0.1);
        plot([0 8],oris(3)*ones(2),'-','LineWidth',0.1);
        plot([2 4],(oris(1)+oris(2))/2*ones(2),'--','LineWidth',0.1);
        plot([2 4],(oris(2)+oris(3))/2*ones(2),'--','LineWidth',0.1);
        %plot([2 4],(oris(1)+oris(3)+180)/2*ones(2),'--','LineWidth',0.1);
        plot([2 4],mod((oris(1)+oris(3)+180)/2,180)*ones(2),'--','LineWidth',0.1);
        if a == 2
            plot([2 4],mod((oris(1)+oris(3)+180)/2,180)*ones(2),'--','LineWidth',0.1);
            ylim([20 200]);
        end
    end
    figure(5); subplot(3,4,e); hold on;
    plot(a0r,'k'); plot(rad*ones(1,2),[0,a0r(rad)],'r'); plot(frad*ones(1,2),[0,a0r(frad)],'b');
    xlabel('radius'); ylabel('mean autocorr'); xlim([0 r]); ylim([0 2*a0r(rad)]);
    title([num2str(deriv),': \color{blue}',num2str(frad),'; \color{red}',num2str(rad)]);
    subplot(3,4,e+4); hold on;
    ringplot = a0; ringplot(xcoor.^2+ycoor.^2<frad^2) = 0; ringplot(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0; % extract the ring
    a0max = max(max(ringplot));
    imagesc_env(a0/a0max,-r:r,-r:r); plot(xs,ys,'w+','MarkerSize',8);
    plot((rad-halfw)*cos(0:0.01:2*pi+0.01),(rad-halfw)*sin(0:0.01:2*pi+0.01),'w');
    plot((rad+halfw)*cos(0:0.01:2*pi+0.01),(rad+halfw)*sin(0:0.01:2*pi+0.01),'w');
    titlestring = [num2str(rad),'; ',num2str(round(mean(sqrt(xs.^2+ys.^2)))),'; ']; 
    for j = 1:size(oris,2)
        titlestring = [titlestring,num2str(oris(j)),'^{\circ} ']; 
    end
    title(titlestring); axis image; colormap(jet(256)); colorbar; caxis([0 1]); 
    %xlim([-80 80]); ylim([-80 80]); 
    if e >= 2
        figure(1);
        [rad,frad,~,~] = max_activity_ring(a0,100);   % outer circle
        [oris,xs,ys] = grid3orientations(a0,rad,rad-halfw);
        %plot((e+3)*ones(size(oris,2),1),oris,'bx'); 
        yyaxis right; plot(e+3,mean(sqrt(xs.^2+ys.^2)),'o');
        figure(5); subplot(3,4,e+8); hold on;
        ringplot = a0; ringplot(xcoor.^2+ycoor.^2<frad^2) = 0; ringplot(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0; % extract the ring
        a0max = max(max(ringplot));
        imagesc_env(a0/a0max,-r:r,-r:r); plot(xs,ys,'w+','MarkerSize',8);
        plot((rad-halfw)*cos(0:0.01:2*pi+0.01),(rad-halfw)*sin(0:0.01:2*pi+0.01),'w');
        plot((rad+halfw)*cos(0:0.01:2*pi+0.01),(rad+halfw)*sin(0:0.01:2*pi+0.01),'w');
        titlestring = [num2str(rad),'; ',num2str(round(mean(sqrt(xs.^2+ys.^2)))),'; ']; 
        for j = 1:size(oris,2)
            titlestring = [titlestring,num2str(oris(j)),'^{\circ} ']; 
        end
        title(titlestring); axis image; colormap(jet(256)); colorbar; caxis([0 1]); 
        xlim([-150 150]); ylim([-150 150]); 
        subplot(3,4,e); plot(rad*ones(1,2),[0,a0r(rad)],'r');
    end
    % combine E2 & E3
    if e == 2 || e == 3
        aE0 = aE0 + a0;
    end
end
% E2 & E3
figure(1); subplot(212);
[rad,frad,aE0r,deriv] = max_activity_ring(aE0,30,90);  % inner circle
[oris,xs,ys] = grid3orientations(aE0,rad,rad-halfw);
a2_sum_rad = [a2_sum_rad; rad]; a2_sum_spacs = [a2_sum_spacs; sqrt(xs.^2+ys.^2)]; a2_sum_oris = [a2_sum_oris; oris];
yyaxis left; plot(4*ones(size(oris,2),1),oris,'x'); ylim([0,180]);
yyaxis right; plot(4,mean(sqrt(xs.^2+ys.^2)),'o'); ylim([35,140]);
figure(5); subplot(344); hold on;
plot(aE0r,'k'); plot(rad*ones(1,2),[0,aE0r(rad)],'r'); plot(frad*ones(1,2),[0,aE0r(frad)],'b');
xlabel('radius'); ylabel('mean autocorr'); xlim([0 r]); ylim([0 2*aE0r(rad)]);
title([num2str(deriv),': \color{blue}',num2str(frad),'; \color{red}',num2str(rad)]); 
subplot(348); hold on;
ringplot = aE0; ringplot(xcoor.^2+ycoor.^2<frad^2) = 0; ringplot(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0; % extract the ring
aE0max = max(max(ringplot));
imagesc_env(aE0/aE0max,-r:r,-r:r); plot(xs,ys,'w+','MarkerSize',8);
plot((rad-halfw)*cos(0:0.01:2*pi+0.01),(rad-halfw)*sin(0:0.01:2*pi+0.01),'w');
plot((rad+halfw)*cos(0:0.01:2*pi+0.01),(rad+halfw)*sin(0:0.01:2*pi+0.01),'w');
titlestring = [num2str(rad),'; ',num2str(round(mean(sqrt(xs.^2+ys.^2)))),'; ']; 
for j = 1:size(oris,2)
    titlestring = [titlestring,num2str(oris(j)),'^{\circ} ']; 
end
title(titlestring); axis image; colormap(jet(256)); colorbar; caxis([0 1]); 
%xlim([-80 80]); ylim([-80 80]); 
figure(1);
[rad,frad,~,deriv] = max_activity_ring(aE0,100);   % outer circle
[oris,xs,ys] = grid3orientations(aE0,rad,rad-halfw);
plot(7,mean(sqrt(xs.^2+ys.^2)),'o');
%yyaxis left; plot((4+3)*ones(size(oris,2),1),oris,'bx'); 
xlabel('environment');
xticks(1:7); xlim([0 8]);
xticklabels({'E1','E2','E3','E2 & 3','E2 out','E3 out','E2 & 3 out'});
figure(5); subplot(3,4,12); hold on;
ringplot = aE0; ringplot(xcoor.^2+ycoor.^2<frad^2) = 0; ringplot(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0; % extract the ring
aE0max = max(max(ringplot));
imagesc_env(aE0/aE0max,-r:r,-r:r); plot(xs,ys,'w+','MarkerSize',8);
plot((rad-halfw)*cos(0:0.01:2*pi+0.01),(rad-halfw)*sin(0:0.01:2*pi+0.01),'w');
plot((rad+halfw)*cos(0:0.01:2*pi+0.01),(rad+halfw)*sin(0:0.01:2*pi+0.01),'w');
titlestring = [num2str(rad),'; ',num2str(round(mean(sqrt(xs.^2+ys.^2)))),'; ']; 
for j = 1:size(oris,2)
    titlestring = [titlestring,num2str(oris(j)),'^{\circ} ']; 
end
title(titlestring); axis image; colormap(jet(256)); colorbar; caxis([0 1]); 
xlim([-150 150]); ylim([-150 150]); 
subplot(344); plot(rad*ones(1,2),[0,aE0r(rad)],'r');
% save(['a',num2str(a),'_gridcells_summary_spac_ori.mat'],'a2_sum_rad','a2_sum_spacs','a2_sum_oris');
saveas(1,[figpath,'grid3orientations_a',num2str(a),'norm',num2str(norm),'summary.png']);
% saveas(2,[figpath,'grid3orientations_a',num2str(a),'norm',num2str(norm),'e1.png']);
% saveas(3,[figpath,'grid3orientations_a',num2str(a),'norm',num2str(norm),'e1threshold.png']);
% saveas(4,[figpath,'grid3orientations_a',num2str(a),'norm',num2str(norm),'e1radius.png']);
% saveas(5,[figpath,'grid3orientations_a',num2str(a),'norm',num2str(norm),'pop.png']);