figpath = './figures/Jacob_Sargolini_shuffled/';
addpath(figpath);

% rat 1
disp('rat 1');
load('gridness_a1_shuffled_summary.mat');
v = [1.4447,0.49488,0.63461,0.82604];
figure; hold on; plot(score_listE2,score_listE3,'k.'); plot(v(2)*ones(2),[-1.3,1.3],'r'); plot([-1.3,1.3],v(3)*ones(2),'r');
axis image; xlabel('E2 score'); ylabel('E3 score'); saveas(gcf,[figpath,'pvalueE1.png']);
p = [sum(score_listE1>=v(1)) sum(score_listE2>=v(2)) sum(score_listE3>=v(3)) sum(score_listE23>=v(4))]/1000
p23 = sum((score_listE2>=v(2)).*(score_listE3>=v(3)))/1000
p23_deriv = sum((score_listE2>=v(2)).*(score_listE3>=v(3)).*(deriv_listE2>0).*(deriv_listE3>0))/sum((deriv_listE2>0).*(deriv_listE3>0))
score_listE1 = score_listE1(deriv_listE1>0); score_listE2 = score_listE2(deriv_listE2>0); 
score_listE3 = score_listE3(deriv_listE3>0); score_listE23 = score_listE23(deriv_listE23>0); 
p_deriv = [sum(score_listE1>=v(1)) sum(score_listE2>=v(2)) sum(score_listE3>=v(3)) sum(score_listE23>=v(4))]./[size(score_listE1,2) size(score_listE2,2) size(score_listE3,2) size(score_listE23,2)]
    
% % rat 2, module 1
% disp('rat 2, module 1');
% load('gridness_a2_split1_shuffled_summary.mat');
% v = [0.89352,-0.037425,0.28376,0.17494];
% figure; hold on; plot(score_listE2,score_listE3,'k.'); plot(v(2)*ones(2),[-1.3,1.3],'r'); plot([-1.3,1.3],v(3)*ones(2),'r');
% axis image; xlabel('E2 score'); ylabel('E3 score'); saveas(gcf,[figpath,'pvalueE23_a2split1.png']);
% p = [sum(score_listE1>=v(1)) sum(score_listE2>=v(2)) sum(score_listE3>=v(3)) sum(score_listE23>=v(4))]/1000
% p23 = sum((score_listE2>=v(2)).*(score_listE3>=v(3)))/1000
% p23_deriv = sum((score_listE2>=v(2)).*(score_listE3>=v(3)).*(deriv_listE2>0).*(deriv_listE3>0))/sum((deriv_listE2>0).*(deriv_listE3>0))
% score_listE1 = score_listE1(deriv_listE1>0); score_listE2 = score_listE2(deriv_listE2>0); 
% score_listE3 = score_listE3(deriv_listE3>0); score_listE23 = score_listE23(deriv_listE23>0); 
% p_deriv = [sum(score_listE1>=v(1)) sum(score_listE2>=v(2)) sum(score_listE3>=v(3)) sum(score_listE23>=v(4))]./[size(score_listE1,2) size(score_listE2,2) size(score_listE3,2) size(score_listE23,2)]
% 
% % rat 2, module 2
% disp('rat 2, module 2');
% load('gridness_a2_split2_shuffled_summary.mat');
% v = [1.2333,0.84242,0.1818,-0.0025795];
% figure; hold on; plot(score_listE2,score_listE3,'k.'); plot(v(2)*ones(2),[-1.3,1.3],'r'); plot([-1.3,1.3],v(3)*ones(2),'r');
% axis image; xlabel('E2 score'); ylabel('E3 score'); saveas(gcf,[figpath,'pvalueE23_a2split2.png']);
% p = [sum(score_listE1>=v(1)) sum(score_listE2>=v(2)) sum(score_listE3>=v(3)) sum(score_listE23>=v(4))]/1000
% p23 = sum((score_listE2>=v(2)).*(score_listE3>=v(3)))/1000
% p23_deriv = sum((score_listE2>=v(2)).*(score_listE3>=v(3)).*(deriv_listE2>0).*(deriv_listE3>0))/sum((deriv_listE2>0).*(deriv_listE3>0))
% score_listE1 = score_listE1(deriv_listE1>0); score_listE2 = score_listE2(deriv_listE2>0); 
% score_listE3 = score_listE3(deriv_listE3>0); score_listE23 = score_listE23(deriv_listE23>0); 
% p_deriv = [sum(score_listE1>=v(1)) sum(score_listE2>=v(2)) sum(score_listE3>=v(3)) sum(score_listE23>=v(4))]./[size(score_listE1,2) size(score_listE2,2) size(score_listE3,2) size(score_listE23,2)]
