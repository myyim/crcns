function [val,idx] = find_nth_max(mat,n)
if n > size(mat(:))
    error('n has to be smaller than the size of the matrix');
end
a = sort(mat(:),'descend');
val = a(n);
idx = find(mat==val);
end