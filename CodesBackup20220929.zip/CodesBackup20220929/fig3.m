close all; clear all;

% parameters for figure 3
ID1 = 20; ID2 = 21; % ID of the two examples
cscale = 0.25; cscale2 = 0.07; % fraction of max as the upper limit of colorbar
rm = 75; % the square size is 2rm X 2rm
idx = [20:26,28:35];  % animal 3
[y,x] = meshgrid(-rm:rm,-rm:rm);

% functions for figure 3
% env_patch, getdata, imagesc_env

% data for figure 3
datapath = './Jacob_Sargolini_All_Environments/'; % update your path here!
allpath = genpath(datapath); addpath(allpath);
% codepath = './codes/'; % update your path here!
% allpath = genpath(codepath); addpath(allpath);
% datapath = './data/'; % update your path here!
% allpath = genpath(datapath); addpath(allpath);
load('CellsID.mat');
load('fitcirculartrack.mat'); % pall (fitted parameters)
load('ac_struct.mat');
load('gridcells_spac_ori.mat'); % from run_grid3orientations_data
load('a2_gridcells_summary_spac_ori.mat'); % from run_grid3orientations
load('a2_summary_ac.mat'); load('a2_gscores.mat');     % from run_gridness_norm
load('a2M_gridcells_summary_spac_ori.mat'); 
% from run_grid3orientations_split
load('a2M_summary_ac.mat'); load('a2M_gscores.mat');     
% from run_gridness_norm_split

fname = CellsID.Arena(ID1); tID = CellsID.tetrode(ID1); cID = CellsID.cell(ID1);
fname = char(fname); fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];  
[trackpos,trackf,~] = getdata(fname,1,pall(ID1,:));
rmap = rmap_A(2).E(1).GC(ID1).rmap; ac = ac_A(2).E(1).GC(ID1).ac;
figure(3); set(gcf,'Position',[0 0 1200 1600]);
subplot(7,8,1); env_patch(1); axis off;
subplot(7,8,2); hold on; plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); axis equal;
axis off; title(['rat 2 cell ',num2str(ID1-19)]); 
subplot(7,8,3); r = (size(rmap,2)-1)/2; imagesc_env(rmap,-r:r,-r:r,1);
colormap(jet(256)); caxis([0 max(rmap,[],'all')*cscale]); title('ratemap');
subplot(7,8,4); r = (size(ac,2)-1)/2; imagesc_env(ac,-r:r,-r:r); title('autocorrelation');
caxis([0 max(ac,[],'all')*cscale]);
fname = CellsID.Arena(ID2); tID = CellsID.tetrode(ID2); cID = CellsID.cell(ID2);
fname = char(fname); fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];  
[trackpos,trackf,~] = getdata(fname,1,pall(ID2,:));
rmap = rmap_A(2).E(1).GC(ID2).rmap; ac = ac_A(2).E(1).GC(ID2).ac;
subplot(7,8,5); hold on; plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); axis equal;
axis off; title(['rat 2 cell ',num2str(ID2-19)]);  
subplot(7,8,6); r = (size(rmap,2)-1)/2; imagesc_env(rmap,-r:r,-r:r,1);
caxis([0 max(rmap,[],'all')*cscale]); title('ratemap');
subplot(7,8,7); r = (size(ac,2)-1)/2; imagesc_env(ac,-r:r,-r:r); title('autocorrelation');
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(ac,[],'all')*cscale]);
subplot(7,8,8); imagesc_env(a2_ac1,-r:r,-r:r); title(['gridness: ',num2str(a2_gscores(1),2)]);
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(a2_ac1,[],'all')*cscale]);

fname = CellsID.CircularTrackLight(ID1); tID = CellsID.tetrode(ID1); cID = CellsID.cell(ID1);
fname = char(fname); fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];  
[trackpos,trackf,~] = getdata(fname,1,pall(ID1,:));
rmap = rmap_A(2).E(2).GC(ID1).rmap; ac = ac_A(2).E(2).GC(ID1).ac;
subplot(7,8,9); env_patch(2); axis off;
subplot(7,8,10); hold on;  plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); axis equal; axis off;
subplot(7,8,11); r = (size(rmap,2)-1)/2; imagesc_env(rmap,-r:r,-r:r,1);
caxis([0 max(rmap,[],'all')*cscale2]);
subplot(7,8,12); r = (size(ac,2)-1)/2; imagesc_env(ac,-r:r,-r:r);
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(ac,[],'all')*cscale2]);
fname = CellsID.CircularTrackLight(ID2); tID = CellsID.tetrode(ID2); cID = CellsID.cell(ID2);
fname = char(fname); fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];  
[trackpos,trackf,~] = getdata(fname,1,pall(ID2,:));
rmap = rmap_A(2).E(2).GC(ID2).rmap; ac = ac_A(2).E(2).GC(ID2).ac;
subplot(7,8,13); hold on; plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); axis equal; axis off;
subplot(7,8,14); r = (size(rmap,2)-1)/2; imagesc_env(rmap,-r:r,-r:r,1);
caxis([0 max(rmap,[],'all')*cscale2]); 
subplot(7,8,15); r = (size(ac,2)-1)/2; imagesc_env(ac,-r:r,-r:r); 
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(ac,[],'all')*cscale2]);
subplot(7,8,16); r = (size(a2_ac2,2)-1)/2; imagesc_env(a2_ac2,-r:r,-r:r); title(['gridness: ',num2str(a2_gscores(2),2)]);
caxis([0 max(a2_ac2,[],'all')*cscale2]); xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]);

fname = CellsID.CiruclarTrackDark(ID1); tID = CellsID.tetrode(ID1); cID = CellsID.cell(ID1);
fname = char(fname); fname = [fname(1:10),'d_t',num2str(tID),'_c',num2str(cID)];  
[trackpos,trackf,~] = getdata(fname,1,pall(ID1,:));
rmap = rmap_A(2).E(3).GC(ID1).rmap; ac = ac_A(2).E(3).GC(ID1).ac;
subplot(7,8,17); env_patch(3); axis off;
subplot(7,8,18); hold on; plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); axis equal; axis off;
subplot(7,8,19); r = (size(rmap,2)-1)/2; imagesc_env(rmap,-r:r,-r:r,1);
caxis([0 max(rmap,[],'all')*cscale]);
subplot(7,8,20); r = (size(ac,2)-1)/2; imagesc_env(ac,-r:r,-r:r);
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(ac,[],'all')*cscale2]);
fname = CellsID.CiruclarTrackDark(ID2); tID = CellsID.tetrode(ID2); cID = CellsID.cell(ID2);
fname = char(fname); fname = [fname(1:10),'d_t',num2str(tID),'_c',num2str(cID)];  
[trackpos,trackf,~] = getdata(fname,1,pall(ID2,:));
rmap = rmap_A(2).E(3).GC(ID2).rmap; ac = ac_A(2).E(3).GC(ID2).ac;
subplot(7,8,21); hold on; plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); axis equal; axis off;
subplot(7,8,22); r = (size(rmap,2)-1)/2; imagesc_env(rmap,-r:r,-r:r,1);
caxis([0 max(rmap,[],'all')*cscale]); 
subplot(7,8,23); r = (size(ac,2)-1)/2; imagesc_env(ac,-r:r,-r:r); 
xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); caxis([0 max(ac,[],'all')*cscale2]);
subplot(7,8,24); imagesc_env(a2_ac3,-r:r,-r:r); title(['gridness: ',num2str(a2_gscores(3),2)]);
caxis([0 max(a2_ac3,[],'all')*cscale2]); %xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); 

a2_oris(a2_oris<20) = a2_oris(a2_oris<20) + 180;
[a2_oris,idx] = sort(a2_oris,2);
a2_spacs = mean(a2_spacs,2);
subplot(4,3,7); hold on; yyaxis left;
% plot([0 19],a2_sum_oris(1,1)*ones(2),'-','LineWidth',0.1);
% plot([0 19],a2_sum_oris(1,2)*ones(2),'-','LineWidth',0.1);
% plot([0 19],a2_sum_oris(1,3)*ones(2),'-','LineWidth',0.1);
% yyaxis right; plot([0 19],mean(a2_sum_spacs(1,:),2)*ones(2),'-','LineWidth',0.1);
% yyaxis left;
for j = 1:15
    plot(j*ones(1,3),a2_oris(j,:),'x');
end 
ylabel('inferred orientations (^{\circ})'); ylim([20 210]); 
yyaxis right; plot(a2_spacs,'o'); ylim([32 62]);
ylabel('inferred spacing (cm)'); xlabel('cell ID'); xlim([0,16]); xticks([1,5,10,15]);

subplot(4,3,8);
x1 = zscore(a2_spacs,0,1); x2 = zscore(a2_oris,0,1);
X = horzcat(x1,x2); Y = pdist(X);
Z = linkage(Y,'average');
h = dendrogram(Z,'ColorThreshold',2.5); 
xlabel('cell ID'); ylabel('distance'); yticks(0:4); title('2 modules'); % dendrogram
for j = [1:4,7,9,10,12]
    h(j).Color = '#1f77b4';   % #1f77b4
end
for j = [5,6,8,11]
    h(j).Color = '#ff7f0e';    % #ff7f0e
end
subplot(4,3,10); hold on; yyaxis left;
plot([0 5],a2M1_sum_oris(1,1)*ones(2),'-','LineWidth',0.1);
plot([0 5],a2M1_sum_oris(1,2)*ones(2),'-','LineWidth',0.1);
plot([0 5],a2M1_sum_oris(1,3)*ones(2),'-','LineWidth',0.1);
plot([1.8 4.2],(a2M1_sum_oris(1,1)+a2M1_sum_oris(1,2))/2*ones(2),'--','LineWidth',0.1);
plot([1.8 4.2],(a2M1_sum_oris(1,2)+a2M1_sum_oris(1,3))/2*ones(2),'--','LineWidth',0.1);
plot([1.8 4.2],(a2M1_sum_oris(1,1)+a2M1_sum_oris(1,3)+180)/2*ones(2)-180,'--','LineWidth',0.1);
yyaxis right; plot([0 5],mean(a2M1_sum_spacs(1,:),2)*ones(2),'-','LineWidth',0.1);
plot([1.8 4.2],sqrt(3)*mean(a2M1_sum_spacs(1,:),2)*ones(2),'--','LineWidth',0.1);
yyaxis left; ylim([0 220]);
for j = 1:4
    plot(j*ones(1,3),a2M1_sum_oris(j,:),'x');
end 
ylabel('inferred orientations (^{\circ})');
yyaxis right; plot(mean(a2M1_sum_spacs,2),'o'); ylim([35 90]);
ylabel('inferred spacing (cm)'); xlabel('environment');
xticks(1:4); xlim([0.5,4.5]); xticklabels({'E1','E2','E3','E2 & 3'});
subplot(4,3,11); 
hold on; yyaxis left;
plot([0 5],a2M2_sum_oris(1,1)*ones(2),'-','LineWidth',0.1);
plot([0 5],a2M2_sum_oris(1,2)*ones(2),'-','LineWidth',0.1);
plot([0 5],a2M2_sum_oris(1,3)*ones(2),'-','LineWidth',0.1);
plot([1.8 4.2],(a2M2_sum_oris(1,1)+a2M2_sum_oris(1,2))/2*ones(2),'--','LineWidth',0.1);
plot([1.8 4.2],(a2M2_sum_oris(1,2)+a2M2_sum_oris(1,3))/2*ones(2),'--','LineWidth',0.1);
plot([1.8 4.2],(a2M2_sum_oris(1,1)+a2M2_sum_oris(1,3)+180)/2*ones(2)-180,'--','LineWidth',0.1);
yyaxis right; plot([0 5],mean(a2M2_sum_spacs(1,:),2)*ones(2),'-','LineWidth',0.1);
plot([1.8 4.2],sqrt(3)*mean(a2M2_sum_spacs(1,:),2)*ones(2),'--','LineWidth',0.1);
yyaxis left; ylim([0 220]);
for j = 1:4
    plot(j*ones(1,3),a2M2_sum_oris(j,:),'x');
end 
ylabel('inferred orientations (^{\circ})');
yyaxis right; plot(mean(a2M2_sum_spacs,2),'o'); ylim([30 80]);
ylabel('inferred spacing (cm)'); xlabel('environment');
xticks(1:4); xlim([0.5,4.5]); xticklabels({'E1','E2','E3','E2 & 3'});

subplot(7,8,31); imagesc_env(a2M1_ac1,-r:r,-r:r); title(['gridness: ',num2str(a2M1_gscores(1),2)]);
caxis([0 max(a2M1_ac1,[],'all')*cscale]); %xlim([-2*rm,2*rm]); ylim([-2*rm,2*rm]); 
subplot(7,8,32); imagesc_env(a2M2_ac1,-r:r,-r:r); title(['gridness: ',num2str(a2M2_gscores(1),2)]);
caxis([0 max(a2M2_ac1,[],'all')*cscale]);
subplot(7,8,39); imagesc_env(a2M1_ac2,-r:r,-r:r); title(['gridness: ',num2str(a2M1_gscores(2),2)]);
caxis([0 max(a2M1_ac2,[],'all')*cscale2]);
subplot(7,8,40); imagesc_env(a2M2_ac2,-r:r,-r:r); title(['gridness: ',num2str(a2M2_gscores(2),2)]);
caxis([0 max(a2M2_ac2,[],'all')*cscale2]);
subplot(7,8,47); imagesc_env(a2M1_ac3,-r:r,-r:r); title(['gridness: ',num2str(a2M1_gscores(3),2)]);
caxis([0 max(a2M1_ac3,[],'all')*cscale2]);
subplot(7,8,48); imagesc_env(a2M2_ac3,-r:r,-r:r); title(['gridness: ',num2str(a2M2_gscores(3),2)]);
caxis([0 max(a2M2_ac3,[],'all')*cscale2]);
subplot(7,8,55); imagesc_env(a2M1_ac4,-r:r,-r:r); title(['gridness: ',num2str(a2M1_gscores(4),2)]);
caxis([0 max(a2M1_ac4,[],'all')*cscale2]);
subplot(7,8,56); imagesc_env(a2M2_ac4,-r:r,-r:r); title(['gridness: ',num2str(a2M2_gscores(4),2)]);
caxis([0 max(a2M2_ac4,[],'all')*cscale2]);

saveas(3,'fig3.png'); saveas(3,'fig3.pdf');