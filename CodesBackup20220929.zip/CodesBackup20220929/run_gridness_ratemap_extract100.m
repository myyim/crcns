close all; clear all;
figpath = './figures/';
xm = 75; ym = 75; % the size is 2rx X 2ry
dmax = max([xm ym]);
lam = 37;   % grid period
psi = 0.31; % grid orientation
[y,x] = meshgrid(-ym:ym,-xm:xm);    
[ycoor,xcoor] = meshgrid(-2*ym:2*ym,-2*xm:2*xm);
rng(1); num = 30; % number of realizations
figure; set(gcf,'Position',[0 0 900 900]);

% 2D
rmap = gridcell(y,x,1,lam,psi,[0,0]);  % from left to right in a matrix is in the direction of increasing the second coordinate, thus (y,x)
subplot(333); imagesc_env(rmap,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('2D ratemap');

% 100 realizations of random extraction
score_array = zeros(1,num);
acsum = zeros(size(ycoor));
for j = 1:num
    c = rand(1,2)*lam; % grid center
    [ac,~,rad,fsize,~,score] = gridscore_ratemap_extract(y,x,lam,psi,c);
    score_array(j) = score;
    acsum = acsum + ac;
    if j <= 3
        disp(score);
        rmap = gridcell(y,x,1,lam,psi,c); rmap(x.^2+y.^2<60^2) = 0; rmap(x.^2+y.^2>75^2) = 0;
        subplot(3,3,(j-1)*3+1); imagesc_env(rmap,-xm:xm,-ym:ym); axis image; colormap(jet(256)); colorbar; title('ratemap');
        subplot(3,3,(j-1)*3+2); hold on; imagesc_env(ac,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; caxis([0 max(ac(x.^2+y.^2>=fsize^2))]); 
        title('autocorr at 0^{\circ}'); xlim([-xm xm]); ylim([-ym ym]);
        plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
        plot(fsize*cos(0:0.01:2*pi+0.01),fsize*sin(0:0.01:2*pi+0.01),'w');
        plot((2*rad-fsize)*cos(0:0.01:2*pi+0.01),(2*rad-fsize)*sin(0:0.01:2*pi+0.01),'w');
    end
end
subplot(336); histogram(score_array,-1:0.1:2); xlabel('score'); title('gridness');
subplot(339); hold on; imagesc_env(acsum,-2*xm:2*xm,-2*ym:2*ym); axis image; colormap(jet(256)); colorbar; caxis([0 max(acsum(x.^2+y.^2>=fsize^2))]); 
xlim([-xm xm]); ylim([-ym ym]);
[~,rad,fsize,~,score] = gridscore_ac(acsum);
plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
plot(fsize*cos(0:0.01:2*pi+0.01),fsize*sin(0:0.01:2*pi+0.01),'w');
plot((2*rad-fsize)*cos(0:0.01:2*pi+0.01),(2*rad-fsize)*sin(0:0.01:2*pi+0.01),'w');
title(['sum, score=',num2str(score)]);
saveas(gcf,[figpath,'gridscore_ratemap_extract100_',num2str(lam),'n',num2str(num),'.png']);