close all; clear all;
rng(1);
norm = 1; % 0: no normalization; 1: overall peak; 
rad = 75-15/2; xc = 2*pi*rad; % circumference of the track
xl = ceil(5*xc); % length of linearized track
dt = 0.04;
sd_range = 0.05; % max spatialial frequency in PSD

%% set path and get directories
datapath = './Jacob_Sargolini_All_Environments/'; % update your path here!
allpath = genpath(datapath);
addpath(allpath);
load('./CellsID.mat');
load('./fitcirculartrack.mat'); % load data pall (fitted parameters)

%% animal
a = 6;
if a == 1
    idx = [1:5,7:19];  % animal 1 
elseif a == 2
    idx = [20:26,28:35]; % animal 2
elseif a == 3
    idx = [36];
elseif a == 4
    idx = [37:43];
elseif a == 5
    idx = [44:60,63];
else
    idx = [61,62,64];
end

figpath = './figures/Jacob_Sargolini_linear/';
if ~exist(figpath)
    mkdir(figpath);
end
addpath(figpath);

xsum = zeros(3,ceil(xc)); 
acsum = zeros(3,2*ceil(xc)-1); 
psdsum = zeros(3,2*ceil(xc)); 
xsum_l = zeros(3,2*xl); 
acsum_l = zeros(3,4*xl-1); 
psdsum_l = zeros(3,4*xl); 
xsum_s = zeros(3,ceil(xc)); 
acsum_s = zeros(3,2*ceil(xc)-1); 
psdsum_s = zeros(3,2*ceil(xc)); 
xsum_l_s = zeros(3,2*xl); 
acsum_l_s = zeros(3,4*xl-1); 
psdsum_l_s = zeros(3,4*xl); 

trackpos_struct = struct();
trackf_struct = struct();
ts_struct = struct();
for e = [2] % environment
    if e == 1
        filename = 'CellsID.Arena';
    elseif e == 2
        filename = 'CellsID.CircularTrackLight';
    elseif e == 3
        filename = 'CellsID.CiruclarTrackDark';
    elseif e == 4
        filename = 'CellsID.SmallArena';
    elseif e == 5
        filename = 'CellsID.SmallCircularTrack';
    end
    for i = 1:size(idx,2)    % cell ID
        figure; set(gcf,'Position',[0 0 1100 700]);
        eval(['fname = ',filename,'(idx(i));']);
        if fname == ""
            continue
        end
        tID = CellsID.tetrode(idx(i));
        cID = CellsID.cell(idx(i));
        fname = char(fname);
        if fname(1) == 'M'
            if e == 1
                fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];          
            else
                fname = [fname(1:11),'_t',num2str(tID),'_c',num2str(cID)];
            end
        else
            fname = [fname(1:16),'_t',num2str(tID),'_c',num2str(cID)];
        end
        load(fname);
        ts = PosMtx(:,1);
        fT = TTMtx(logical((TTMtx(:,2)==tID).*(TTMtx(:,3)==cID)),1);  % Timestamps of firing data with tetrode and cell ID
        fT = fT(logical((fT>=ts(1)).*(fT<=ts(end)))); 
        [trackpos,trackf,~] = getdata_sargolini(fname,tID,cID,1,pall(i,:));
        [trackpos_l,trackf_l,~] = getlinearized_sargolini(fname,tID,cID,pall(idx(i),:));
        fT_s = datasample(ts,size(fT,1),'Replace',false); % firing times of the shuffled
        trackf_s = [interp1(ts,trackpos(:,1),fT_s,'nearest') interp1(ts,trackpos(:,2),fT_s,'nearest')];
        trackf_l_s = interp1(ts,trackpos_l,fT_s,'nearest');
        trackpos_struct(idx(i)).array = trackpos_l;
        trackf_struct(idx(i)).array = trackf_l;
        ts_struct(idx(i)).array = ts;
        
        subplot(341); hold on; axis image; 
        plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
        plot(trackpos(1,1),trackpos(1,2),'go'); plot(trackpos(end,1),trackpos(end,2),'ms');
        title(fname,'Interpreter','none');
        subplot(345); hold on; axis image; plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
        plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2);
        if i == 2
            plot(trackf_s(:,1),trackf_s(:,2),'c.','MarkerSize',2);
        end
        subplot(342); hold on;
        xval = rad*mod(atan2(trackpos(:,2),trackpos(:,1)),2*pi);    % atan(Y,X)
        spk = rad*mod(atan2(trackf(:,2),trackf(:,1)),2*pi); 
        spk_s = rad*mod(atan2(trackf_s(:,2),trackf_s(:,1)),2*pi); 
        plot(xval,ts*dt,'.','Color',[17 17 17]/20); 
        plot(spk,fT*dt,'r.'); 
        if i == 2
            plot(spk_s,fT_s*dt,'c.');
        end
        ylim([0 max(ts*dt)]); xlim([0,ceil(xc)]); ylabel('time (s)'); xlabel('location (cm)');
        subplot(346); hold on;
        tb = histcounts(xval,0:ceil(xc)); tb = tb*dt;
        spkb = histcounts(spk,0:ceil(xc)); spkb_s = histcounts(spk_s,0:ceil(xc));
        ratemap = spkb./tb; ratemap(isnan(ratemap)) = 0;
        ratemap_s = spkb_s./tb; ratemap_s(isnan(ratemap_s)) = 0;
        plot(0.5:ceil(xc),ratemap,'k'); 
        if i == 2
            plot(0.5:ceil(xc),ratemap_s,'c');
        end
        xlim([0,ceil(xc)]); xlabel('location (m)'); ylabel('rate (spk/s)');
        
        subplot(322); hold on;
        plot(trackpos_l,ts*dt,'Color',[17 17 17]/20); plot(trackf_l,fT*dt,'r.');
        if i == 2
            plot(trackf_l_s,fT_s*dt,'c.');
        end
        for j = ceil(min(trackf_l)/xc):floor(max(trackf_l)/xc)
            plot(j*xc*ones(2),[0,max(ts*dt)],'b--');
        end
        ylim([0 max(ts*dt)]); xlim([min(trackpos_l)-1,max(trackpos_l)+1]);
        ylabel('time (s)'); xlabel('linearized location (cm)');
        
        subplot(324); hold on;
        tb_l = histcounts(trackpos_l,-xl:xl);    % time spent on each bin
        tb_l = tb_l*dt; % amount of time on each bin
        spkb_l = histcounts(trackf_l,-xl:xl); % spike count on each bin
        ratemap_l = spkb_l./tb_l;   % ratemap
        ratemap_l(isnan(ratemap_l)) = 0;    % remove nan when not explored
        plot(-xl+0.5:xl,ratemap_l,'k');
        spkb_l_s = histcounts(trackf_l_s,-xl:xl); % spike count on each bin
        ratemap_l_s = spkb_l_s./tb_l;   % ratemap
        ratemap_l_s(isnan(ratemap_l_s)) = 0;
        if i == 2
            plot(-xl+0.5:xl,ratemap_l_s,'c');
        end
        xlim([min(trackpos_l)-1,max(trackpos_l)+1]);
        for j = ceil(min(trackf_l)/xc):floor(max(trackf_l)/xc)
            plot(j*xc*ones(2),[0,max(ratemap_l)],'b--');
        end
        xlabel('linearized location (m)'); ylabel('rate (spk/s)');
        xsum(e,:) = xsum(e,:) + ratemap/max(ratemap);
        xsum_l(e,:) = xsum_l(e,:) + ratemap_l/max(ratemap_l);
        xsum_s(e,:) = xsum_s(e,:) + ratemap_s/max(ratemap_s);
        xsum_l_s(e,:) = xsum_l_s(e,:) + ratemap_l_s/max(ratemap_l_s);
        
        subplot(3,4,9); hold on;
        ac = xcorr(ratemap); s = (size(ac,2)-1)/2;
        ac_s = xcorr(ratemap_s); plot(-s:s,ac_s/max(ac_s),'c'); 
        plot(-s:s,ac/max(ac),'k'); 
        xlim([0,s+1]); title('norm autocorr of rate'); 
        xlabel('lag (cm)'); %ylim([0 max(ac(s+3:end))]);

        subplot(3,4,10); hold on;
        sd_s = ac2psd1d(ac_s); plot((0:2*s+1)/(2*s+1),sd_s,'c');
        sd = ac2psd1d(ac); plot((0:2*s+1)/(2*s+1),sd,'k');          
        xlim([0,sd_range]); title('PSD of rate'); 
        xlabel('spatial freq (cm^{-1})'); ylim([0 max(sd(5:end))]);
        acsum(e,:) = acsum(e,:) + ac/max(ac); 
        psdsum(e,:) = psdsum(e,:) + sd/max(sd); 
        acsum_s(e,:) = acsum_s(e,:) + ac_s/max(ac_s); 
        psdsum_s(e,:) = psdsum_s(e,:) + sd_s/max(sd_s); 

        subplot(3,4,11); hold on;
        ac = xcorr(ratemap_l); s = (size(ac,2)-1)/2; 
        ac_s = xcorr(ratemap_l_s); plot(-s:s,ac_s/max(ac_s),'c');
        plot(-s:s,ac/max(ac),'k');         
        plot(xc*ones(2),[0,1],'b--'); xlim([0,500]); title('norm autocorr linearized'); 
        xlabel('lag (cm)'); %ylim([0 max(ac(s+3:end))]);
        
        subplot(3,4,12); hold on;
        sd_s = ac2psd1d(ac_s); plot((0:2*s+1)/(2*s+1),sd_s,'c'); 
        sd = ac2psd1d(ac); plot((0:2*s+1)/(2*s+1),sd,'k'); 
        plot(ones(2)/xc,[0,max(sd(5:end))],'b--');
        xlim([0,sd_range]); title('PSD linearized'); 
        xlabel('spatial freq (cm^{-1})'); ylim([0 max(sd(5:end))]);
        acsum_l(e,:) = acsum_l(e,:) + ac/max(ac); 
        psdsum_l(e,:) = psdsum_l(e,:) + sd/max(sd);
        acsum_l_s(e,:) = acsum_l_s(e,:) + ac_s/max(ac_s); 
        psdsum_l_s(e,:) = psdsum_l_s(e,:) + sd_s/max(sd_s);
%         figure(e+9); subplot(4,5,i);
%         semilogy((0:4*xl-1)/(4*xl-1),ac2psd1d(ac)); xlim([0,sd_range]);
        saveas(gcf,[figpath,'gridness_linear_a',num2str(a),'e',num2str(e),'cell',num2str(idx(i)),'.png']);
    end
    figure; set(gcf,'Position',[0 0 1100 500]);
    subplot(241); hold on;
    plot(0:ceil(xc)-1,xsum_s(e,:),'c');
    plot(0:ceil(xc)-1,xsum(e,:),'k');
    xlim([0,ceil(xc)-1]);
    xlabel('location (cm)'); ylabel('rate sum'); title(['E',num2str(e)]);
    subplot(242); hold on;
    plot(1:ceil(xc)-1,acsum_s(e,ceil(xc)+1:end),'c');
    plot(1:ceil(xc)-1,acsum(e,ceil(xc)+1:end),'k'); 
    xlim([0,500]); xlabel('lag (cm)'); ylabel('autocorr (norm)'); %ylim([0 max(acsum(ceil(xc)+5:end))]);
    subplot(243); hold on;
    sd_s = ac2psd1d(acsum_s(e,:)); 
    plot((1:2*ceil(xc))/(2*ceil(xc)),sd_s,'c'); 
    sd = ac2psd1d(acsum(e,:)); 
    plot((1:2*ceil(xc))/(2*ceil(xc)),sd,'k');    
    xlim([0,sd_range]); title('PSD (autocorr)'); 
    xlabel('spatial freq (cm^{-1})'); ylim([0 max(sd(5:end))]);
    subplot(244); hold on;
    plot((1:2*ceil(xc))/(2*ceil(xc)),psdsum_s(e,:),'c');
    plot((1:2*ceil(xc))/(2*ceil(xc)),psdsum(e,:),'k');     
    xlim([0,sd_range]); title('PSD sum'); 
    xlabel('spatial freq (cm^{-1})'); ylim([0 max(psdsum(e,5:end))]);
      
    subplot(245); hold on;
    plot(-xl:xl-1,xsum_l_s(e,:),'c'); 
    plot(-xl:xl-1,xsum_l(e,:),'k'); 
    %xlim([-500,500]); 
    xlabel('linearized location (cm)'); ylabel('rate sum');
    subplot(246); hold on; 
    plot(1:2*xl-1,acsum_l_s(e,2*xl+1:end),'c'); 
    plot(1:2*xl-1,acsum_l(e,2*xl+1:end),'k');    
    xlim([0,500]); xlabel('lag (cm)'); ylabel('autocorr (norm)'); 
    plot(xc*ones(2),[0,max(acsum_l(e,2*xl+5:end))],'b--');
    %ylim([0 max(acsum_l(2*xl+5:end))]);
    subplot(247); hold on;
    sd_s = ac2psd1d(acsum_l_s(e,:)); 
    plot((0:4*xl-1)/(4*xl-1),sd_s,'c');
    sd = ac2psd1d(acsum_l(e,:)); 
    plot((0:4*xl-1)/(4*xl-1),sd,'k'); 
    plot(ones(2)/xc,[0,max(sd(5:end))],'b--');
    xlim([0,sd_range]); title('PSD (autocorr)'); 
    xlabel('spatial freq (cm^{-1})'); ylim([0 max(sd(5:end))]);
    subplot(248); hold on; 
    plot((0:4*xl-1)/(4*xl-1),psdsum_l_s(e,:),'c'); 
    plot((0:4*xl-1)/(4*xl-1),psdsum_l(e,:),'k'); 
    plot(ones(2)/xc,[0,max(sd(5:end))],'b--');
    xlim([0,sd_range]); title('PSD sum'); 
    xlabel('spatial freq (cm^{-1})'); ylim([0 max(psdsum_l(e,5:end))]);
    saveas(gcf,[figpath,'gridness_linear_a',num2str(a),'e',num2str(e),'.png']);
end
