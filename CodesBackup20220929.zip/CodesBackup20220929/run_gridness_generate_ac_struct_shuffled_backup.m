close all; clear all;
%% 6 animals
an = {'MEC2','MEC1','MEC3','MEC4','1RS_','2BS_'};
sig = 3; cscale = 0.4;
toplot = 1; % flag for plots

%% which datapath dp?
% 1: Large Arena matlab files (all 64 cells)
% 2: Large Circular track light matlab files (all 64 cells)
% 3: Large Circular track dark matlab files (35 cells)
% 4: Small Arena matlab files (29 cells)
% 5: Small Circular track matlab files (29 cells)

%% load paths and data
datapath = './Jacob_Sargolini_All_Environments/'; % update your path here!
allpath = genpath(datapath);
addpath(allpath);
addpath('./gridness/');
load('./CellsID.mat');
load('./fitcirculartrack.mat'); % load data pall (fitted parameters)
figpath = './figures/Jacob_Sargolini_shuffled/';
if ~exist(figpath)
    mkdir(figpath);
end
addpath(figpath);

if toplot
    for j = [1,20,21]    % number of cells
        figure(j); set(gcf,'Position',[0 0 800 1200]);
        if j < 20
            sgtitle(['Animal 1; Cell ',num2str(j)]);
        else
            sgtitle(['Animal 2; Cell ',num2str(j-19)]);
        end
    end
end

for s = 1:2
    % create a struct for storing all the autocorrelations
    ac = struct('A1',{},'A2',{});
    for j = 1:2     % number of animals, in E1-3, R0-150
        eval(['ac(1).A',num2str(j),'= struct(''E1'',{},''E2'',{},''E3'',{});']);
        for k = 1:5
            eval(['ac(1).A',num2str(j),'(1).E',num2str(k),'= struct(''R0'',{},''R30'',{},''R60'',{},''R90'',{},''R120'',{},''R150'',{});']);
        end
    end
    rmaps = struct('A1',{},'A2',{});
%     for j = 1:2 % number of animals, in E1-3
%         eval(['rmaps(1).A',num2str(j),'= struct(''E1'',{},''E2'',{},''E3'',{});']);
%     end
    for dp = 1:3    % environments 1-3
        disp(['dp = ',num2str(dp)]);
        if dp == 1
            %addpath([datapath,'Large Arena matlab files/']);
            filename = 'CellsID.Arena';
        elseif dp == 2
            %addpath([datapath,'Large Circular track light matlab files/']);
            filename = 'CellsID.CircularTrackLight';
        elseif dp == 3
            %addpath([datapath,'Large Circular track dark matlab files/']);
            filename = 'CellsID.CiruclarTrackDark';
        elseif dp == 4
            %addpath([datapath,'Small Arena matlab files/']);
            filename = 'CellsID.SmallArena';
        elseif dp == 5
            %addpath([datapath,'Small Circular track matlab files/']);
            filename = 'CellsID.SmallCircularTrack';
        end
        for j = [1,20,21]%1:35%35    % cells 1-35 in animals 1,2 only
            eval(['fname = ',filename,'(j);']);
            if fname == ""
                continue
            end
            disp(['cell = ',num2str(j)]);
            tID = CellsID.tetrode(j);
            cID = CellsID.cell(j);
            fname = char(fname);
            if fname(1) == 'M'
                if dp == 1
                    fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];          
                else
                    fname = [fname(1:11),'_t',num2str(tID),'_c',num2str(cID)];
                end
            else
                fname = [fname(1:16),'_t',num2str(tID),'_c',num2str(cID)];
            end
            aid = find(strcmp(fname(1:4),an)==1);
            [trackpos,trackf,~] = getdata_sargolini(fname,tID,cID,1,pall(j,:)); % pall stores the fitted parameters
            trackpos_radius = sqrt(trackpos(:,1).^2+trackpos(:,2).^2); rm = min([78 ceil(max(trackpos_radius))]);
            mask = ones(2*rm+1); [ycoor,xcoor] = meshgrid(-rm:rm,-rm:rm); % coordinates of the grid, y by x
            mask(xcoor.^2+ycoor.^2>rm^2) = 0;
            if dp > 1
                rmin = max([57 floor(min(trackpos_radius))]);
                mask(xcoor.^2+ycoor.^2<rmin^2) = 0;
            end
            seed = 105*(s-1)+3*(j-1)+dp;
            [ac0,ac30,ac60,ac90,ac120,ac150,rmap] = data2ac_shuffled(trackpos,trackf,sig,mask,seed);
            for k = 0:5
                eval(['ac.A',num2str(aid),'.E',num2str(dp),'.R',num2str(k*30),'= ac',num2str(k*30),';']);
                %eval(['ac.A',num2str(aid),'.E',num2str(dp),'(j).R',num2str(k*30),'= ac',num2str(k*30),';']);
            end
            eval(['rmaps.A',num2str(aid),'().E',num2str(dp),'= rmap;']);
            if toplot
                %figure(100); imagesc_env(rmap'); axis image;
                %colorbar; colormap(jet(256)); caxis([0 cscale*max(rmap,[],'all')]);
                if s == 1
                    figure(j); subplot(6,4,(dp-1)*8+1); hold on; axis image;
                    plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
                    plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2);
                    subplot(6,4,(dp-1)*8+3); hold on; axis image;
                    r = (size(rmap,2)-1)/2; imagesc_env(rmap',-r:r,-r:r); 
                    colorbar; colormap(jet(256)); caxis([0 cscale*max(rmap,[],'all')]);
                    set(gca,'color',[1 1 1]); set(gca,'YDir','normal'); set(gca,'visible','off');
                    subplot(6,4,(dp-1)*8+7); hold on; axis image;
                    imagesc_env(ac0',-150:150,-150:150);
                    colorbar; colormap(jet(256)); caxis([0 cscale*max(ac0,[],'all')]);
                    subplot(6,4,(dp-1)*8+2); hold on; axis image;
                    [rmap,~,~] = smoothratemap(trackpos,trackf,sig);
                    eval(['rmaps0.A',num2str(aid),'.E',num2str(dp),'= rmap;']);
                    [ac0,ac30,ac60,ac90,ac120,ac150] = data2ac(trackpos,trackf,sig,300,0);
                    imagesc_env(rmap',-r:r,-r:r);
                    colorbar; colormap(jet(256)); caxis([0 cscale*max(rmap,[],'all')]);
                    set(gca,'color',[1 1 1]); set(gca,'YDir','normal'); set(gca,'visible','off');
                    subplot(6,4,(dp-1)*8+6); hold on; axis image;
                    imagesc_env(ac0',-150:150,-150:150);
                    colorbar; colormap(jet(256)); caxis([0 cscale*max(ac0,[],'all')]);
                elseif s == 2
                    figure(j); subplot(6,4,(dp-1)*8+4); hold on; axis image;
                    r = (size(rmap,2)-1)/2; imagesc_env(rmap',-r:r,-r:r); 
                    colorbar; colormap(jet(256)); caxis([0 cscale*max(rmap,[],'all')]);
                    set(gca,'color',[1 1 1]); set(gca,'YDir','normal'); set(gca,'visible','off');
                    subplot(6,4,(dp-1)*8+8); hold on; axis image;
                    imagesc_env(ac0',-150:150,-150:150);
                    colorbar; colormap(jet(256)); caxis([0 cscale*max(ac0,[],'all')]);
                end
            end
        end
    end
    save([figpath,'ac_struct_s',num2str(s),'.mat'],'ac','rmap');
end

if toplot
    for j = [1,20,21]
        cid = j; aid = 1;
        if j >= 20
            aid = 2; cid = j - 19;
        end
        saveas(j,[figpath,'gridness_generate_ac_struct_shuffled_a',num2str(aid),'cell',num2str(cid),'.png']);
        saveas(j,[figpath,'gridness_generate_ac_struct_shuffled_a',num2str(aid),'cell',num2str(cid),'.pdf']);
    end
end