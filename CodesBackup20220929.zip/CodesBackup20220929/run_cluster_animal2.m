clear all; close all;
figpath = './figures/Jacob_Sargolini_orientations/';
if ~exist(figpath)
    mkdir(figpath);
end
addpath(figpath);

load('sargolini_gridcells_radius_orientation.mat');

% animal 1
% x1 = zscore(a1_rads,0,1); 
% x2 = zscore(a1_orientations,0,1);
% X = horzcat(x1,x2);
% Y = pdist(X);
% Z = linkage(Y,'average');
% figure(1); set(gcf,'Position',[0 0 1100 500]);
% subplot(121); imagesc(squareform(Y)); axis image; colormap(jet(256)); colorbar;
% title('distance'); xticks(1:18); yticks(1:18); xlabel('cell ID'); ylabel('cell ID');
% subplot(122); h = dendrogram(Z); %h = dendrogram(Z,'ColorThreshold',2.5);
% title('dendrogram'); xlabel('cell ID'); ylabel('distance'); yticks(0:6);
% sgtitle('animal 1: hierarchical clustering based on z-scores of spacings & orientations');
% saveas(1,[figpath,'cluster_animal1.png']);

% animal 2
a2_orientations(a2_orientations<20) = a2_orientations(a2_orientations<20) + 180;
[a2_orientations,idx] = sort(a2_orientations,2);
for j = 1:16
    a2_rads(j,:) = a2_rads(j,idx(j,:));
end
a2_orientations = a2_orientations([1:7,9:16],:);
a2_rads = mean(a2_rads([1:7,9:16],:),2);
if 1 % 4 features
    a2_rads = mean(a2_rads,2);
end
x1 = zscore(a2_rads,0,1); 
x2 = zscore(a2_orientations,0,1);
X = horzcat(x1,x2);
Y = pdist(X);
Z = linkage(Y,'average');
figure(2); set(gcf,'Position',[0 0 1100 500]);
subplot(121); imagesc(squareform(Y)); axis image; colormap(jet(256)); colorbar;
title('distance'); xticks(1:15); yticks(1:15); xlabel('cell ID'); ylabel('cell ID');
subplot(122); h = dendrogram(Z,'ColorThreshold',2.5); 
title('dendrogram'); xlabel('cell ID'); ylabel('distance'); yticks(0:4);
for j = [1:4,7,9,10,12]
    h(j).Color = '#1f77b4';   % #1f77b4
end
for j = [5,6,8,11]
    h(j).Color = '#ff7f0e';    % #ff7f0e
end
%sgtitle('animal 2: hierarchical clustering based on z-scores of spacings & orientations');
sgtitle('animal 2: hierarchical clustering based on z-scores of spacing & orientations');
saveas(2,[figpath,'cluster_animal2.png']);