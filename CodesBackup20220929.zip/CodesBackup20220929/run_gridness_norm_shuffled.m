%close all; clear all;
norm = 2; % 0: no normalization; 1: overall peak; 2: peak within donut
r = 150;
%rmesh = -2*lmesh:2*lmesh;
[ycoor,xcoor] = meshgrid(-r:r,-r:r);

% animal
a = 1;
if a == 1
    idx = [1:5,7:19];  % animal 1 
    v = [1.4447,0.49488,0.63461,0.82604];
elseif a == 2
    split = 1;
    idx = [20:26,28:35]; % animal 2
    if split == 1
        v = [0.89352,-0.037425,0.28376,0.17494];
    else
        v = [1.2333,0.84242,0.1818,-0.0025795];
    end
end
if a == 1
    gcID = 1:size(idx,2);
else
    if split == 1
        gcID = [1,3,4,5,6,7,10,13,14];
    else
        gcID = [2,9,11,12,15];
    end
end

figpath = './figures/Jacob_Sargolini_shuffled/';
if ~exist(figpath)
    mkdir(figpath);
end
addpath(figpath);

deriv_listE1 = []; deriv_listE2 = []; deriv_listE3 = []; deriv_listE23 = [];
score_listE1 = []; score_listE2 = []; score_listE3 = []; score_listE23 = [];
for s = 1:1
    load(['ac_struct_s',num2str(s),'.mat']);
    figure(1); set(gcf,'Position',[0 0 1100 600]);
    figure(2); set(gcf,'Position',[0 0 1100 600]);
    figure(3); set(gcf,'Position',[0 0 1100 600]);
    figure(4); set(gcf,'Position',[0 0 1100 600]);

    aE0 = zeros(2*r+1,2*r+1); aE30 = zeros(2*r+1,2*r+1); aE60 = zeros(2*r+1,2*r+1); 
    aE90 = zeros(2*r+1,2*r+1); aE120 = zeros(2*r+1,2*r+1); aE150 = zeros(2*r+1,2*r+1);
    for e = 1:3 % environment
        a0 = zeros(2*r+1,2*r+1); a30 = zeros(2*r+1,2*r+1); a60 = zeros(2*r+1,2*r+1); 
        a90 = zeros(2*r+1,2*r+1); a120 = zeros(2*r+1,2*r+1); a150 = zeros(2*r+1,2*r+1);
        for i = gcID    % cell ID
            ac0 = ac_A(a).E(e).GC(idx(i)).ac;
            [ac30,ac60,ac90,ac120,ac150,~,~] = gridscore_interp2(ac0);
            for k = 0:5 % rotation out of 6
                eval(['ac = ac',num2str(k*30),';']);
                si = size(ac,1); 
                if si < 2*r+1    % zero-padding when size of ac is smaller than r
                    temp = zeros(2*r+1,2*r+1);
                    temp((2*r+1-si)/2+1:2*r+1-(2*r+1-si)/2,(2*r+1-si)/2+1:2*r+1-(2*r+1-si)/2) = ac;
                    ac = temp;
                else
                    ac = ac((si+1)/2-r:(si+1)/2+r,(si+1)/2-r:(si+1)/2+r);   % reshape ac
                end
                eval(['t',num2str(k*30),'= ac;']);
            end
            [rad,frad,~,deriv] = max_activity_ring(t0);
            [score,~] = gridness(t0,t30,t60,t90,t120,t150,rad,frad);
            ori = gridorientation(t0,rad,frad);
            acplot = t0; 
            ringplot = t0; ringplot(xcoor.^2+ycoor.^2<frad^2) = 0; ringplot(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0; % extract the ring
            if norm == 0
                acmax = 1;
            elseif norm == 1
                acmax = max(max(acplot));
            elseif norm == 2
                acmax = max(max(ringplot));
            end
            if acmax ~= 0
                acplot = acplot/acmax; ringplot = ringplot/acmax;
                for k = 0:5
                  eval(['a',num2str(k*30),' = a',num2str(k*30),' + t',num2str(k*30),'/acmax;']);
                end 
            end       
            figure(e); subplot(4,5,i); hold on;
            imagesc_env(acplot,-r:r,-r:r); axis image; colormap(jet(256)); colorbar; 
            if acmax ~= 0
                caxis([0 max(max(ringplot))]);
            end
            title([num2str(deriv),': \color{blue}',num2str(frad),'; \color{red}',num2str(rad),'\color{black}; ',num2str(round(ori)),'^{\circ}; g:',num2str(score,2)]);
            plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
            plot(frad*cos(0:0.01:2*pi+0.01),frad*sin(0:0.01:2*pi+0.01),'w');
            plot((2*rad-frad)*cos(0:0.01:2*pi+0.01),(2*rad-frad)*sin(0:0.01:2*pi+0.01),'w');
        end
        sgtitle(['Animal ',num2str(a),'; Environment ',num2str(e)]);
        if e >= 2
            [rad,frad,a0r,deriv] = max_activity_ring(a0,30,90);
        else
            [rad,frad,a0r,deriv] = max_activity_ring(a0);
        end    
        [score,cor] = gridness(a0,a30,a60,a90,a120,a150,rad,frad);
        if score > 0.1
            disp([num2str(s),' ',num2str(e),' ',num2str(score),' ',num2str(deriv)]);
        end
        ori = gridorientation(a0,rad,frad);
        if e == 1
            deriv_listE1 = [deriv_listE1, deriv];
            score_listE1 = [score_listE1, score];
        elseif e == 2
            deriv_listE2 = [deriv_listE2, deriv];
            score_listE2 = [score_listE2, score];            
        elseif e == 3
            deriv_listE3 = [deriv_listE3, deriv];
            score_listE3 = [score_listE3, score];            
        end
        % combine E2 & E3
        if e == 2 || e == 3
            for k = 0:5 % rotation out of 6
                eval(['aE',num2str(k*30),' = aE',num2str(k*30),' + a',num2str(k*30),';']);                
            end
        end
        a0psd = ac2psd(a0); a30psd = ac2psd(a30); a60psd = ac2psd(a60); a90psd = ac2psd(a90); a120psd = ac2psd(a120); a150psd = ac2psd(a150); 
        figure(4); subplot(4,4,4*(e-1)+1); hold on; 
        plot([0,r],[0,0],'k:'); plot(a0r,'k');
        plot(rad*ones(1,2),[0,a0r(rad)],'r'); plot(frad*ones(1,2),[0,a0r(frad)],'b');
        xlabel('radius'); ylabel('mean autocorr'); xlim([0 r]); ylim([0 2*a0r(rad)]);
        title([num2str(deriv),': \color{blue}',num2str(frad),'; \color{red}',num2str(rad),'\color{black}; ',num2str(round(ori)),'^{\circ}']);
        subplot(4,4,4*(e-1)+2); hold on;
        imagesc_env(a0,-r:r,-r:r); axis image; colormap(jet(256)); colorbar; 
        a0(xcoor.^2+ycoor.^2<frad^2) = 0; a0(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0; % extract the ring
        caxis([0 max(max(a0))]); title(['autocorr in E',num2str(e)]);
        plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
        plot(frad*cos(0:0.01:2*pi+0.01),frad*sin(0:0.01:2*pi+0.01),'w');
        plot((2*rad-frad)*cos(0:0.01:2*pi+0.01),(2*rad-frad)*sin(0:0.01:2*pi+0.01),'w');
        subplot(4,4,4*(e-1)+3); hold on;    
        imagesc_env(a0,-r:r,-r:r); axis image; colormap(jet(256)); colorbar; 
        caxis([0 max(max(a0))]); title(['autocorr in E',num2str(e)]);
        plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
        plot(frad*cos(0:0.01:2*pi+0.01),frad*sin(0:0.01:2*pi+0.01),'w');
        plot((2*rad-frad)*cos(0:0.01:2*pi+0.01),(2*rad-frad)*sin(0:0.01:2*pi+0.01),'w');
        subplot(4,4,4*e); hold on;
        plot(0:30:150,cor,'ko-'); title(['gridness = ',num2str(score)]);
    end % e
    [rad,frad,ac0r,deriv] = max_activity_ring(aE0,30,90);
    [score,cor] = gridness(aE0,aE30,aE60,aE90,aE120,aE150,rad,frad);
    ori = gridorientation(aE0,rad,frad);
    deriv_listE23 = [deriv_listE23, deriv];
    score_listE23 = [score_listE23, score];
    figure(4); subplot(4,4,13); hold on; 
    plot([0,r],[0,0],'k:'); plot(ac0r,'k');
    plot(rad*ones(1,2),[0,ac0r(rad)],'r'); plot(frad*ones(1,2),[0,ac0r(frad)],'b');
    xlabel('radius'); ylabel('mean autocorr'); xlim([0 r]); ylim([0 2*ac0r(rad)]);
    title([num2str(deriv),': \color{blue}',num2str(frad),'; \color{red}',num2str(rad),'\color{black}; ',num2str(round(ori)),'^{\circ}']);
    subplot(4,4,14); hold on;
    imagesc_env(aE0,-r:r,-r:r); axis image; colormap(jet(256)); colorbar; 
    aE0(xcoor.^2+ycoor.^2<frad^2) = 0; aE0(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0;
    caxis([0 max(max(aE0))]); title(['autocorr in E2 & 3']);
    plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
    plot(frad*cos(0:0.01:2*pi+0.01),frad*sin(0:0.01:2*pi+0.01),'w');
    plot((2*rad-frad)*cos(0:0.01:2*pi+0.01),(2*rad-frad)*sin(0:0.01:2*pi+0.01),'w');
    subplot(4,4,15); hold on;
    imagesc_env(aE0,-r:r,-r:r); axis image; colormap(jet(256)); colorbar; 
    caxis([0 max(max(aE0))]); title(['autocorr in E2 & 3']);
    plot(rad*cos(0:0.01:2*pi+0.01),rad*sin(0:0.01:2*pi+0.01),'w');
    plot(frad*cos(0:0.01:2*pi+0.01),frad*sin(0:0.01:2*pi+0.01),'w');
    plot((2*rad-frad)*cos(0:0.01:2*pi+0.01),(2*rad-frad)*sin(0:0.01:2*pi+0.01),'w');
    subplot(4,4,16); hold on;
    plot(0:30:150,cor,'ko-'); title(['gridness = ',num2str(score)]);
    saveas(1,[figpath,'gridness_a',num2str(a),'e1norm',num2str(norm),'s',num2str(s),'.png']);
    saveas(2,[figpath,'gridness_a',num2str(a),'e2norm',num2str(norm),'s',num2str(s),'.png']);
    saveas(3,[figpath,'gridness_a',num2str(a),'e3norm',num2str(norm),'s',num2str(s),'.png']);
    saveas(4,[figpath,'gridness_a',num2str(a),'allnorm',num2str(norm),'s',num2str(s),'.png']);
    close all;
end

figure; set(gcf,'Position',[0 0 1000 1200]);
subplot(431); histogram(deriv_listE1,-0.5:3.5,'FaceColor','k'); 
xticks(0:3); title('E1'); xlabel('stability');
subplot(434); histogram(deriv_listE2,-0.5:3.5,'FaceColor','k'); 
xticks(0:3); title('E2'); xlabel('stability');
subplot(437); histogram(deriv_listE3,-0.5:3.5,'FaceColor','k'); 
xticks(0:3); title('E3'); xlabel('stability');
subplot(4,3,10); histogram(deriv_listE23,-0.5:3.5,'FaceColor','k'); 
xticks(0:3); title('E2&3'); xlabel('stability');

subplot(432); hold on; h = histogram(score_listE1,-1.05:0.1:2.05,'FaceColor','k'); 
plot(v(1)*ones(1,2),[0 max(h.Values)],'r'); title('E1'); xlabel('score');
subplot(435); hold on; h = histogram(score_listE2,-1.05:0.1:2.05,'FaceColor','k'); 
plot(v(2)*ones(1,2),[0 max(h.Values)],'r'); title('E2'); xlabel('score');
subplot(438); hold on; h = histogram(score_listE3,-1.05:0.1:2.05,'FaceColor','k'); 
plot(v(3)*ones(1,2),[0 max(h.Values)],'r'); title('E3'); xlabel('score');
subplot(4,3,11); hold on; h = histogram(score_listE23,-1.05:0.1:2.05,'FaceColor','k'); 
plot(v(4)*ones(1,2),[0 max(h.Values)],'r'); title('E2&3'); xlabel('score');

subplot(433); hold on; h = histogram(score_listE1(deriv_listE1>0),-1.05:0.1:2.05,'FaceColor','k'); 
plot(v(1)*ones(1,2),[0 max(h.Values)],'r'); title('E1'); xlabel('valid score');
subplot(436); hold on; h = histogram(score_listE2(deriv_listE2>0),-1.05:0.1:2.05,'FaceColor','k'); 
plot(v(2)*ones(1,2),[0 max(h.Values)],'r'); title('E2'); xlabel('valid score');
subplot(439); hold on; h = histogram(score_listE3(deriv_listE3>0),-1.05:0.1:2.05,'FaceColor','k'); 
plot(v(3)*ones(1,2),[0 max(h.Values)],'r'); title('E3'); xlabel('valid score');
subplot(4,3,12); hold on; h = histogram(score_listE23(deriv_listE23>0),-1.05:0.1:2.05,'FaceColor','k'); 
plot(v(4)*ones(1,2),[0 max(h.Values)],'r'); title('E2&3'); xlabel('valid score');

if a == 1
    saveas(1,[figpath,'gridness_a',num2str(a),'_shuffled_summary.png']);
    save([figpath,'gridness_a',num2str(a),'_shuffled_summary.mat'],'deriv_listE1','deriv_listE2','deriv_listE3','deriv_listE23','score_listE1','score_listE2','score_listE3','score_listE23');
else
    saveas(1,[figpath,'gridness_a',num2str(a),'_split',num2str(split),'_shuffled_summary.png']);
    save([figpath,'gridness_a',num2str(a),'_split',num2str(split),'_shuffled_summary.mat'],'deriv_listE1','deriv_listE2','deriv_listE3','deriv_listE23','score_listE1','score_listE2','score_listE3','score_listE23');    
end