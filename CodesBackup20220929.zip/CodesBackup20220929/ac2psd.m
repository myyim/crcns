function sd = ac2psd(ac)
x = ac;
% zero-padding
%x = vertcat(zeros(1,size(x,2)),x);
%x = horzcat(zeros(size(x,1),1),x);
sd0 = abs(fft2(x));
n1 = floor(size(sd0,1)/2);
n2 = floor(size(sd0,2)/2);
sd = zeros(size(sd0));
if n1 ~= n2
    error('Square matrix only!')
end
if mod(size(sd0,1),2) == 0
    sd(n1+1:end,n2+1:end) = sd0(1:n1,1:n2);
    sd(1:n1,n2+1:end) = sd0(n1+1:end,1:n2);
    sd(n1+1:end,1:n2) = sd0(1:n1,n2+1:end);
    sd(1:n1,1:n2) = sd0(n1+1:end,n2+1:end);
    sd(n1+1,n2+1) = 0;
else
    sd(n1+1:end,n2+1:end) = sd0(1:n1+1,1:n2+1);
    sd(1:n1,n2+1:end) = sd0(n1+2:end,1:n2+1);
    sd(n1+1:end,1:n2) = sd0(1:n1+1,n2+2:end);
    sd(1:n1,1:n2) = sd0(n1+2:end,n2+2:end);
    sd(n1+1,n2+1) = 0;
end
end