datapath = './Jacob_Sargolini_All_Environments/'; % update your path here!
allpath = genpath(datapath); addpath(allpath);
load('./CellsID.mat');
figure; set(gcf,'Position',[0 0 1200 1200]);

j = 40;
filename = 'CellsID.Arena'; % large arena
eval(['fname = ',filename,'(j);']);
tID = CellsID.tetrode(j);
cID = CellsID.cell(j);
fname = char(fname); 
if fname(1) == 'M'
    fname = [fname(1:11),'_t',num2str(tID),'_c',num2str(cID)];
else
    fname = [fname(1:16),'_t',num2str(tID),'_c',num2str(cID)];
end
disp(fname);
[trackpos,trackf,~] = getdata_sargolini(fname,tID,cID,0);
subplot(221); hold on; plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); axis equal; axis off; title('E1');
disp(max(max(trackpos)));

filename = 'CellsID.CircularTrackLight'; % large circular track
eval(['fname = ',filename,'(j);']);
tID = CellsID.tetrode(j);
cID = CellsID.cell(j);
fname = char(fname);
if fname(1) == 'M'
    fname = [fname(1:11),'_t',num2str(tID),'_c',num2str(cID)];
else
    fname = [fname(1:16),'_t',num2str(tID),'_c',num2str(cID)];
end
disp(fname);
[trackpos,trackf,~] = getdata_sargolini(fname,tID,cID,0);
subplot(222); hold on; plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); axis equal; axis off; title('E2');
disp(max(max(trackpos)));

filename = 'CellsID.SmallArena'; % small arena
eval(['fname = ',filename,'(j);']);
tID = CellsID.tetrode(j);
cID = CellsID.cell(j);
fname = char(fname);
if fname(1) == 'M'
    fname = [fname(1:11),'_t',num2str(tID),'_c',num2str(cID)];
else
    fname = [fname(1:16),'_t',num2str(tID),'_c',num2str(cID)];
end
disp(fname);
[trackpos,trackf,~] = getdata_sargolini(fname,tID,cID,0);
subplot(223); hold on; plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); axis equal; axis off; title('E4');
disp(max(max(trackpos)));

filename = 'CellsID.SmallCircularTrack';    % small circular track
eval(['fname = ',filename,'(j);']);
tID = CellsID.tetrode(j);
cID = CellsID.cell(j);
fname = char(fname);
if fname(1) == 'M'
    fname = [fname(1:11),'_t',num2str(tID),'_c',num2str(cID)];
else
    fname = [fname(1:16),'_t',num2str(tID),'_c',num2str(cID)];
end
disp(fname);
[trackpos,trackf,~] = getdata_sargolini(fname,tID,cID,0);
subplot(224); hold on; plot(trackpos(:,1),trackpos(:,2),'Color', [17 17 17]/20);
plot(trackf(:,1),trackf(:,2),'r.','MarkerSize',2); axis equal; axis off; title('E5');
disp(max(max(trackpos)));

sgtitle(['cell ',num2str(j)]);
saveas(1,['./figures/check_traj_spk',num2str(j),'.png']);