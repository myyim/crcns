close all; clear all;
norm = 1; % 0: no normalization; 1: overall peak
rad = 75-15/2; xl = ceil(2*pi*rad); % length of linearized track
ts = 0.04;
sd_range = 0.05; % max spatial frequency in PSD
load('./CellsID.mat');
load('./fitcirculartrack.mat'); % load data pall (fitted parameters)
% animal
a = 1;
if a == 1
    idx = [1:5,7:19];  % animal 1 
elseif a == 2
    idx = 20:35; % animal 2
end

figpath = './figures/Jacob_Sargolini_1d/';
if ~exist(figpath)
    mkdir(figpath);
end
addpath(figpath);

figure(1); set(gcf,'Position',[0 0 1100 600]);
figure(2); set(gcf,'Position',[0 0 1100 600]);
figure(3); set(gcf,'Position',[0 0 1100 600]);
figure(4); set(gcf,'Position',[0 0 1100 600]);
figure(5); set(gcf,'Position',[0 0 1100 600]);
figure(6); set(gcf,'Position',[0 0 1100 600]);
figure(7); set(gcf,'Position',[0 0 1100 600]);
figure(8); set(gcf,'Position',[0 0 1100 600]);
figure(9); set(gcf,'Position',[0 0 1100 600]);
figure(10); set(gcf,'Position',[0 0 1100 600]);
figure(11); set(gcf,'Position',[0 0 1100 600]);
figure(12); set(gcf,'Position',[0 0 1100 600]);
figure(13); set(gcf,'Position',[0 0 1100 600]);

acsum = zeros(3,2*xl-1); xsum = zeros(3,xl);
for e = 1:3 % environment
    if e == 1
        filename = 'CellsID.Arena';
    elseif e == 2
        filename = 'CellsID.CircularTrackLight';
    elseif e == 3
        filename = 'CellsID.CiruclarTrackDark';
    elseif e == 4
        filename = 'CellsID.SmallArena';
    elseif e == 5
        filename = 'CellsID.SmallCircularTrack';
    end
    for i = 1:size(idx,2)    % cell ID
        eval(['fname = ',filename,'(idx(i));']);
        if fname == ""
            continue
        end
        tID = CellsID.tetrode(idx(i));
        cID = CellsID.cell(idx(i));
        fname = char(fname);
        if fname(1) == 'M'
            if e == 1
                fname = [fname(1:10),'l_t',num2str(tID),'_c',num2str(cID)];          
            else
                fname = [fname(1:11),'_t',num2str(tID),'_c',num2str(cID)];
            end
        else
            fname = [fname(1:16),'_t',num2str(tID),'_c',num2str(cID)];
        end
        if e == 1
            [trackpos,trackf,~] = getdata_sargolini(fname,tID,cID,4,pall(idx(i),:),15);
            trackpos_l = rad*mod(atan2(trackpos(:,2),trackpos(:,1)),2*pi);
            trackf_l = rad*mod(atan2(trackf(:,2),trackf(:,1)),2*pi);
        else
            [trackpos_l,trackf_l,~] = getdata_sargolini(fname,tID,cID,3,pall(idx(i),:));
        end
        tb_l = histcounts(trackpos_l,0:1:xl);    % time spent on each bin
        tb_l = tb_l*ts; % amount of time on each bin
        spkb_l = histcounts(trackf_l,0:1:xl); % spike count on each bin
        ratemap_l = spkb_l./tb_l;   % ratemap
        ratemap_l(isnan(ratemap_l)) = 0;    % remove nan when not explored
        figure(e); subplot(4,5,i); plot(ratemap_l); xlim([0,xl+1]);
        figure(e+3); subplot(4,5,i); ac = xcorr(ratemap_l); 
        plot(0:xl-1,ac(xl:end)); xlim([0,xl]);  
        figure(e+6); subplot(4,5,i);
        plot((0:2*xl-1)/(2*xl-1),ac2psd1d(ac)); xlim([0,sd_range]);
        figure(e+9); subplot(4,5,i);
        semilogy((0:2*xl-1)/(2*xl-1),ac2psd1d(ac)); xlim([0,sd_range]);
        if max(ratemap_l) ~= 0
            if norm == 0
                xsum(e,:) = xsum(e,:) + ratemap_l/max(ratemap_l);
                acsum(e,:) = acsum(e,:) + ac/max(ac);
            elseif norm == 1
                xsum(e,:) = xsum(e,:) + ratemap_l/max(ratemap_l);
                acsum(e,:) = acsum(e,:) + ac/max(ac);
            end
        end
    end    
    figure(e); sgtitle(['Rate: Animal ',num2str(a),'; Environment ',num2str(e)]); 
    if i == size(idx,2)
        xlabel('location (cm)');
    end
    figure(3+e); sgtitle(['Autocorr: Animal ',num2str(a),'; Environment ',num2str(e)]); 
    if i == size(idx,2)
        xlabel('lag (cm)');
    end   
    figure(6+e); sgtitle(['PSD: Animal ',num2str(a),'; Environment ',num2str(e)]); 
    if i == size(idx,2)
        xlabel('spatial frequency (cm^{-1})');
    end
    figure(9+e); sgtitle(['PSD: Animal ',num2str(a),'; Environment ',num2str(e)]); 
    if i == size(idx,2)
        xlabel('spatial frequency (cm^{-1})');
    end
end
figure(13); 
for e = 1:3
    subplot(4,4,4*(e-1)+1); plot(xsum(e,:)); xlim([0,xl+1]);
    xlabel('location (cm)'); ylabel('rate'); title(['E',num2str(e)]);
    subplot(4,4,4*(e-1)+2); plot(0:xl-1,acsum(e,xl:end)); xlim([0,xl]); 
    xlabel('lag (cm)'); ylabel('autocorr (norm)');
    subplot(4,4,4*(e-1)+3); plot((0:2*xl-1)/(2*xl-1),ac2psd1d(acsum(e,:))); xlim([0,sd_range]);
    xlabel('spatial frequency (cm^{-1})'); ylabel('PSD');
    subplot(4,4,4*(e-1)+4); semilogy((0:2*xl-1)/(2*xl-1),ac2psd1d(acsum(e,:))); xlim([0,sd_range]);
    xlabel('spatial frequency (cm^{-1})'); ylabel('PSD');
end
subplot(4,4,13); plot(xsum(2,:)+xsum(3,:)); xlim([0,xl+1]);
xlabel('location (cm)'); title(['E2 & 3']);
subplot(4,4,14); plot(0:xl-1,acsum(2,xl:end)+acsum(3,xl:end)); xlim([0,xl]);
xlabel('lag (cm)');
subplot(4,4,15); plot((0:2*xl-1)/(2*xl-1),ac2psd1d(acsum(2,:)+acsum(3,:))); xlim([0,sd_range]);
xlabel('spatial frequency (cm^{-1})');
subplot(4,4,16); semilogy((0:2*xl-1)/(2*xl-1),ac2psd1d(acsum(2,:)+acsum(3,:))); xlim([0,sd_range]);
xlabel('spatial frequency (cm^{-1})');
sgtitle(['Sum over population: Animal ',num2str(a)]); 
saveas(1,[figpath,'gridness1d_rate_a',num2str(a),'e1.png']);
saveas(2,[figpath,'gridness1d_rate_a',num2str(a),'e2.png']);
saveas(3,[figpath,'gridness1d_rate_a',num2str(a),'e3.png']);
saveas(4,[figpath,'gridness1d_ac_a',num2str(a),'e1.png']);
saveas(5,[figpath,'gridness1d_ac_a',num2str(a),'e2.png']);
saveas(6,[figpath,'gridness1d_ac_a',num2str(a),'e3.png']);
saveas(7,[figpath,'gridness1d_psd_a',num2str(a),'e1.png']);
saveas(8,[figpath,'gridness1d_psd_a',num2str(a),'e2.png']);
saveas(9,[figpath,'gridness1d_psd_a',num2str(a),'e3.png']);
saveas(10,[figpath,'gridness1d_logpsd_a',num2str(a),'e1.png']);
saveas(11,[figpath,'gridness1d_logpsd_a',num2str(a),'e2.png']);
saveas(12,[figpath,'gridness1d_logpsd_a',num2str(a),'e3.png']);
saveas(13,[figpath,'gridness1d_summary_a',num2str(a),'.png']);
    