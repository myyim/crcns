function [ac0,ac30,ac60,ac90,ac120,ac150] = ac_struct(an,en,idx)
r = 150;
f = load('./ac_struct.mat');
ac0 = zeros(2*r+1,2*r+1); ac30 = zeros(2*r+1,2*r+1); ac60 = zeros(2*r+1,2*r+1); ac90 = zeros(2*r+1,2*r+1); ac120 = zeros(2*r+1,2*r+1); ac150 = zeros(2*r+1,2*r+1);
for a = an
    for e = en
        for i = idx
            for k = 0:5
                eval(['ac = f.ac.A',num2str(a),'.E',num2str(e),'(i).R',num2str(k*30),';']);
                s = size(ac,1);
                ac = ac((s+1)/2-r:(s+1)/2+r,(s+1)/2-r:(s+1)/2+r);
                eval(['ac',num2str(k*30),' = ac',num2str(k*30),' + ac;']);
            end
        end
    end
end
figure; set(gcf,'Position',[0 0 1000 600]);
for k = 0:5
    subplot(2,3,k+1); hold on; eval(['imagesc_env(ac',num2str(k*30),',-r:r,-r:r);']); 
    axis image; colormap(jet(256)); colorbar; caxis([0 max(max(ac0))]); title(['autocorr at ',num2str(k*30),'^{\circ}']);
end
end