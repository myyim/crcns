close all; clear all;

%% parameters
norm = 2; % 0: no normalization; 1: overall peak; 2: peak within donut
r = 150;
halfw = 5;
[ycoor,xcoor] = meshgrid(-r:r,-r:r);
load('./ac_struct.mat');
% animal
a = 1;
if a == 1
    idx = [1:5,7:19];  % animal 1 
elseif a == 2
    idx = [20:26,28:35]; % animal 2
end

%% codes needed
codepath = './codes/'; % update your path here!
allpath = genpath(codepath); addpath(allpath);

%% figure
datapath = './Jacob_Sargolini_All_Environments/'; % update your path here!
allpath = genpath(datapath); addpath(allpath);
codepath = './codes/'; % update your path here!
allpath = genpath(codepath); addpath(allpath);
datapath = './data/'; % update your path here!
allpath = genpath(datapath); addpath(allpath);

figure(1); set(gcf,'Position',[0 0 1100 900]);
figure(2); set(gcf,'Position',[0 0 1100 900]);
figure(3); set(gcf,'Position',[0 0 1100 900]);
figure(4); set(gcf,'Position',[0 0 1100 900]);

for e = 1:4 % environment 1-3, 4 is E2+E3 together
    a0 = zeros(2*r+1,2*r+1);
    for i = 1:size(idx,2)    % cell ID
        if e == 4
            ac = ac_A(a).E(2).GC(idx(i)).ac;
        else
            ac = ac_A(a).E(e).GC(idx(i)).ac;
        end
        s = size(ac,1); 
        if s < 2*r+1    % zero-padding when size of ac is smaller than r
            temp = zeros(2*r+1,2*r+1);
            temp((2*r+1-s)/2+1:2*r+1-(2*r+1-s)/2,(2*r+1-s)/2+1:2*r+1-(2*r+1-s)/2) = ac;
            ac = temp;
        else
            ac = ac((s+1)/2-r:(s+1)/2+r,(s+1)/2-r:(s+1)/2+r);   % reshape ac
        end
        if e == 4
            actemp = ac;
            ac = ac_A(a).E(3).GC(idx(i)).ac;
            s = size(ac,1); 
            if s < 2*r+1    % zero-padding when size of ac is smaller than r
                temp = zeros(2*r+1,2*r+1);
                temp((2*r+1-s)/2+1:2*r+1-(2*r+1-s)/2,(2*r+1-s)/2+1:2*r+1-(2*r+1-s)/2) = ac;
                ac = temp;
            else
                ac = ac((s+1)/2-r:(s+1)/2+r,(s+1)/2-r:(s+1)/2+r);   % reshape ac
            end
            ac = ac + actemp;
        end
        [rad,frad,ac0r,deriv] = max_activity_ring(ac,30);
        if a == 2 && e == 1 && (idx(i) == 21 || idx(i) == 34)
            [rad,frad,ac0r,deriv] = max_activity_ring(ac,40);
        end
        if a == 1 && e == 1 && idx(i) == 18
            rad = 48;
        end
        if a == 2 && e == 1 && (idx(i) == 29 || idx(i) == 32)
            rad = 60;
        end
        if norm == 0
            acmax = 1;
        elseif norm == 1
            acmax = max(max(ac));
        elseif norm == 2
            ringplot = ac; ringplot(xcoor.^2+ycoor.^2<frad^2) = 0; ringplot(xcoor.^2+ycoor.^2>(2*rad-frad)^2) = 0; % extract the ring
            acmax = max(max(ringplot));
        end
        if acmax ~= 0
            a0 = a0 + ac/acmax;
        end   
        figure(e); subplot(4,5,i); hold on;
        [oris,xs,ys,ath] = grid3orientations(ac,rad,rad-halfw);
        [~,~,~,~,~,score,~] = gridscore_interp2(ac,rad,frad);
        imagesc_env(ac/acmax,-r:r,-r:r); 
        if e == 1 || e == 4
            plot(xs,ys,'w+','MarkerSize',8);
            %plot(frad*cos(0:0.01:2*pi+0.01),frad*sin(0:0.01:2*pi+0.01),'w');
            plot((rad-halfw)*cos(0:0.01:2*pi+0.01),(rad-halfw)*sin(0:0.01:2*pi+0.01),'w');
            %plot((2*rad-frad)*cos(0:0.01:2*pi+0.01),(2*rad-frad)*sin(0:0.01:2*pi+0.01),'w');
            plot((rad+halfw)*cos(0:0.01:2*pi+0.01),(rad+halfw)*sin(0:0.01:2*pi+0.01),'w');
            gridstring = eval(['"gridness: ',num2str(score,2),'";']);
            titlestring = ['\color{orange}',num2str(round(mean(sqrt(xs.^2+ys.^2)))),'; ']; 
            for j = 1:size(oris,2)
                titlestring = [titlestring,'\color{blue}',num2str(oris(j)),'^{\circ} ']; 
            end
            title([gridstring,titlestring]); 
        end
        axis image; colormap(jet(256)); caxis([0 1]);% colorbar;
        xlim([-80 80]); ylim([-80 80]); 

    end
end

figure(1);
set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,...
    'PaperPosition',[0 0 screenposition(3:4)],...
    'PaperSize',[screenposition(3:4)]);
print -dpdf supp_autocorr_rat1_env1

figure(2);
set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,...
    'PaperPosition',[0 0 screenposition(3:4)],...
    'PaperSize',[screenposition(3:4)]);
print -dpdf supp_autocorr_rat1_env2

figure(3);
set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,...
    'PaperPosition',[0 0 screenposition(3:4)],...
    'PaperSize',[screenposition(3:4)]);
print -dpdf supp_autocorr_rat1_env3

figure(4);
set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,...
    'PaperPosition',[0 0 screenposition(3:4)],...
    'PaperSize',[screenposition(3:4)]);
print -dpdf supp_autocorr_rat1_env23