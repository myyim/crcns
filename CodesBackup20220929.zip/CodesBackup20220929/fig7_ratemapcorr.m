close all; clear all;

% parameters
% ID1 = 20; ID2 = 21; % ID of the two examples
% cscale = 0.25; cscale2 = 0.07; % fraction of max as the upper limit of colorbar
% rm = 75; % the square size is 2rm X 2rm
% idx = [20:26,28:35];  % animal 3
% [y,x] = meshgrid(-rm:rm,-rm:rm);
idx1 = [1:5,7:19];  % animal 1
idx2 = [20:26,28:35]; % animal 2
rmap_cscale1 = 0.2; rmap_cscale2 = 0.12; % fraction of max as the upper limit of colorbar
rm = 75; rad = rm-15/2;
w = 15;   % should be <= 15

% functions
% imagesc_env

% data
datapath = './Jacob_Sargolini_All_Environments/'; % update your path here!
allpath = genpath(datapath); addpath(allpath);
codepath = './codes/'; % update your path here!
allpath = genpath(codepath); addpath(allpath);
datapath = './data/'; % update your path here!
allpath = genpath(datapath); addpath(allpath);
load('CellsID.mat');
load('fitcirculartrack.mat'); % pall (fitted parameters)
load('ac_struct_s3c6.mat');

figure(1); set(gcf,'Position',[0 0 400 700]); colormap(jet(256));
figure(2); set(gcf,'Position',[0 0 400 350]); colormap(jet(256));
figure(3); set(gcf,'Position',[0 0 400 350]); colormap(jet(256));
figure(4); set(gcf,'Position',[0 0 400 350]); colormap(jet(256));
figure(5); set(gcf,'Position',[0 0 400 350]); colormap(jet(256));

figure(1);
for j = 1:2
    for dp = 1:3
        subplot(3,2,(dp-1)*2+j); hold on;
        rmap = rmap_A(1).E(dp).GC(j+1).rmap;
        r = floor(size(rmap,1)/2);
        [ycoor,xcoor] = meshgrid(-r:r,-r:r); % coordinates of the grid, y by x
        imagesc_env(rmap,-r:r,-r:r,1);
        plot((rad-w/2)*cos(0:0.01:2*pi+0.01),(rad-w/2)*sin(0:0.01:2*pi+0.01),'w');
        plot((rad+w/2)*cos(0:0.01:2*pi+0.01),(rad+w/2)*sin(0:0.01:2*pi+0.01),'w');
        if dp == 1
            rmap_cscale = rmap_cscale1;
        else
            rmap_cscale = rmap_cscale2;
        end
        axis image; caxis([0 rmap_cscale*max(max(rmap))]); 
        xlim([-rm-5,rm+5]); ylim([-rm-5,rm+5]);
        if j == 1
            ylabel(['E',num2str(dp)]);
        end
        if dp == 1
            title(['Example cell ',num2str(j)]);
        end
    end
end

load('ac_struct.mat');
for a = 1:2
    eval(['idx = idx',num2str(a),';']);
    count = size(idx,2);
    if isfile([datapath,'ratemapcorr_a',num2str(a),'.mat'])
        load([datapath,'ratemapcorr_a',num2str(a),'.mat']);
    else
        rmap1 = []; rmap2 = []; rmap3 = [];
        for j = 1:count
            for dp = 1:3
                rmap = rmap_A(a).E(dp).GC(idx(j)).rmap;
                r = floor(size(rmap,1)/2);
                [ycoor,xcoor] = meshgrid(-r:r,-r:r); % coordinates of the grid, y by x
                rmap = rmap((xcoor.^2+ycoor.^2<=(rad+w/2)^2).*(xcoor.^2+ycoor.^2>=(rad-w/2)^2)==1);
                rmap = rmap - mean(rmap(~isnan(rmap)),"all"); rmap(isnan(rmap)) = 0;
                if dp == 1
                    rmap1 = [rmap1; rmap'];
                    title(['cell ',num2str(j)]);
                elseif dp == 2
                    rmap2 = [rmap2; rmap'];
                else
                    rmap3 = [rmap3; rmap'];
                end
            end
        end
    
        xc12 = zeros(count); xc31 = zeros(count); xc23 = zeros(count); 
        for j = 1:count
            for k = 1:count
                cc = corrcoef(rmap1(j,:),rmap2(k,:)); xc12(j,k) = cc(1,2);
                cc = corrcoef(rmap3(j,:),rmap1(k,:)); xc31(j,k) = cc(1,2);
                cc = corrcoef(rmap2(j,:),rmap3(k,:)); xc23(j,k) = cc(1,2);
            end
        end
        save([datapath,'ratemapcorr_a',num2str(a),'.mat'],'xc12','xc31','xc23');
    end

    figure(a+1); hold on; plot([0.5 3.5],[0 0],'k--');
    plot(ones(count*(count-1)),xc12(eye(count)==0),'o','Color',[13 13 13]/20);
    plot(2*ones(count*(count-1)),xc31(eye(count)==0),'s','Color',[13 13 13]/20);
    plot(3*ones(count*(count-1)),xc23(eye(count)==0),'v','Color',[13 13 13]/20);
    plot(ones(count),diag(xc12),'bo'); plot(2*ones(count),diag(xc31),'gs'); plot(3*ones(count),diag(xc23),'rv');
    title(['Rat ',num2str(a)]); xlim([0,4]); ylim([-0.2 0.32]); xticks([]);
    %xticks(1:3); xticklabels({'E_1 & E_2','E_1 & E_3','E_2 & E_3'});
    if a == 1
        ylabel('Rate map correlation');
    else
        ylabel('');
    end

    figure(a+3); hold on; plot([0.5 3.5],[0 0],'k--');
    g1 = repmat({'E_1 & E_2'},count*(count-1),1); g2 = repmat({'E_1 & E_3'},count*(count-1),1);
    g3 = repmat({'E_2 & E_3'},count*(count-1),1); g = [g1; g2; g3];
    boxplot([xc12(eye(count)==0); xc31(eye(count)==0); xc23(eye(count)==0)],g,'Colors',[13 13 13]/20,'position',(1:3)+0.15,'widths',0.2);
    b1 = findobj(gcf,'tag','Outliers'); set(b1,'Marker','none');
    g1 = repmat({'E_1 & E_2'},count,1); g2 = repmat({'E_1 & E_3'},count,1); g3 = repmat({'E_2 & E_3'},count,1); 
    g = [g1; g2; g3];
    boxplot([diag(xc12);diag(xc31);diag(xc23)],g,'Colors','k','position',(1:3)-0.15,'widths',0.2);
    b2 = findobj(gcf,'tag','Outliers'); set(b2,'Marker','none');
    ylim([-0.2 0.32]); xlim([0,4]);
    [p12,h12,stats12] = ranksum(diag(xc12),xc12(eye(count)==0),'tail','right');
    [p31,h31,stats31] = ranksum(diag(xc31),xc31(eye(count)==0),'tail','right');
    [p23,h23,stats23] = ranksum(diag(xc23),xc23(eye(count)==0),'tail','right');
    text(0.7,0.3,['p=',num2str(p12,'%.2f')]);
    text(1.7,0.3,['p=',num2str(p31,'%.2f')]);
    text(2.7,0.3,['p=',num2str(p23,'%.3f')]);
    [p12_23,~,~] = ranksum(diag(xc23),diag(xc12),'tail','right');
    [p31_23,~,~] = ranksum(diag(xc23),diag(xc31),'tail','right');
    text(1.2,-0.15,['p=',num2str(p12_23,'%.2f')]);
    text(2.2,-0.15,['p=',num2str(p31_23,'%.2f')]);
    [c12_23,~,~] = ranksum(xc23(eye(count)==0),xc12(eye(count)==0),'tail','right');
    [c31_23,~,~] = ranksum(xc23(eye(count)==0),xc31(eye(count)==0),'tail','right');
    text(1.2,-0.18,['p=',num2str(c12_23,'%.2f')]);
    text(2.2,-0.18,['p=',num2str(c31_23,'%.2f')]);
end

figure(1); set(findall(gcf,'-property','FontSize'),'FontSize',12);
set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,...
    'PaperPosition',[0 0 screenposition(3:4)],...
    'PaperSize',[screenposition(3:4)]);
print -dpdf fig7_ratemapcorr_A

figure(2); set(findall(gcf,'-property','FontSize'),'FontSize',12);
set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,...
    'PaperPosition',[0 0 screenposition(3:4)],...
    'PaperSize',[screenposition(3:4)]);
print -dpdf fig7_ratemapcorr_B

figure(3); set(findall(gcf,'-property','FontSize'),'FontSize',12);
set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,...
    'PaperPosition',[0 0 screenposition(3:4)],...
    'PaperSize',[screenposition(3:4)]);
print -dpdf fig7_ratemapcorr_C

figure(4); set(findall(gcf,'-property','FontSize'),'FontSize',12);
set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,...
    'PaperPosition',[0 0 screenposition(3:4)],...
    'PaperSize',[screenposition(3:4)]);
print -dpdf fig7_ratemapcorr_D

figure(5); set(findall(gcf,'-property','FontSize'),'FontSize',12);
set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,...
    'PaperPosition',[0 0 screenposition(3:4)],...
    'PaperSize',[screenposition(3:4)]);
print -dpdf fig7_ratemapcorr_E